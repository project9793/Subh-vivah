# Kaam karne ke niyam (mere liye — har build se pehle padhna)

1. **Sirf wahi file chhuo** jo user ne naam le kar kaha ho. Ek bhi extra file nahi.
2. **Ek build = ek kaam.** Do kaam bologe to do alag zip.
3. **Zip se pehle** badli files ki list banao (`check_scope.py` se) aur user ko dikhao.
4. **Agar list me koi file extra hai** jo user ne nahi kahi — us build ko bhejo hi na, pehle wapas karo.
5. **Design/reference diya ho to** point-by-point milao, phir bhejo. Bhejne ke baad layout apni marzi se na badlo.
6. **Naya Hindi/English text** sirf `Lang.t("हिंदी","English")` me likho — seedha kabhi nahi.
7. **Jo bas ka nahi** wo saaf bol do, adhura bana kar "ho gaya" na kaho.
8. **User ke screenshot ke bina** koi design badlav nahi.
