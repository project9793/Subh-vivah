plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

// Fixed signing key: agar keystore/release.jks maujood hai to har build usi key se sign hoga,
// jisse naye APK purane ke upar seedhe install ho jayein (uninstall ki zaroorat nahi).
val fixedKs = rootProject.file("keystore/release.jks")

android {
    namespace = "com.shubh.vivah"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shubh.vivah"
        minSdk = 24
        targetSdk = 35
        versionCode = 167
        versionName = "2.67"
    }

    signingConfigs {
        if (fixedKs.exists()) {
            create("fixed") {
                storeFile = fixedKs
                storePassword = "svivah123"
                keyAlias = "shubhvivah"
                keyPassword = "svivah123"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            if (fixedKs.exists()) signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (fixedKs.exists()) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.print:print:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.navigation:navigation-fragment-ktx:2.8.5")
    implementation("androidx.navigation:navigation-ui-ktx:2.8.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")

    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-database-ktx")
    implementation("com.google.firebase:firebase-storage-ktx")
    implementation("com.google.firebase:firebase-messaging-ktx")
    implementation("com.google.firebase:firebase-crashlytics-ktx")
}

// ---- APK ka naam version ke saath (debug naam se chhutkara) ----
val apkVersionName = "2.67"

tasks.register("renameApk") {
    doLast {
        val dir = layout.buildDirectory.dir("outputs/apk/debug").get().asFile
        dir.listFiles()?.filter { it.isFile && it.name.endsWith(".apk") }?.forEach { f ->
            if (!f.name.startsWith("SubhVivah-v")) {
                val target = File(dir, "SubhVivah-v$apkVersionName.apk")
                if (target.exists()) target.delete()
                f.renameTo(target)
            }
        }
    }
}

tasks.matching { it.name == "assembleDebug" }.configureEach {
    finalizedBy("renameApk")
}
