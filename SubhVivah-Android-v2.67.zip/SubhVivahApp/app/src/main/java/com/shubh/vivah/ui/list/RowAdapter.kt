package com.shubh.vivah.ui.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.shubh.vivah.databinding.ItemRowBinding

data class Row(
    val icon: String,
    val title: String,
    val chip: String = "",
    val meta: CharSequence = "",
    val showWa: Boolean = false,
    val showPay: Boolean = false,
    val color: String = ""          // chip ka rang (khaali = default)
)

class RowAdapter(
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit,
    private val onWa: (Int) -> Unit = {},
    private val onChip: (Int) -> Unit = {},
    private val onRow: ((Int) -> Unit)? = null,
    private val onPay: (Int) -> Unit = {}
) : RecyclerView.Adapter<RowAdapter.VH>() {

    private val items = ArrayList<Row>()

    fun setItems(list: List<Row>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemRowBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        h.b.tvIcon.text = r.icon
        h.b.tvTitle.text = r.title
        h.b.tvChip.text = r.chip
        h.b.tvChip.visibility = if (r.chip.isBlank()) View.GONE else View.VISIBLE
        if (r.color.isNotBlank()) {
            h.b.tvChip.backgroundTintList = com.shubh.vivah.ui.FormDialog.chipColor(r.color)
            h.b.tvChip.setTextColor(android.graphics.Color.WHITE)
        } else {
            h.b.tvChip.backgroundTintList = null
        }
        h.b.tvMeta.text = r.meta
        h.b.tvMeta.visibility = if (r.meta.isEmpty()) View.GONE else View.VISIBLE
        h.b.btnWa.visibility = if (r.showWa) View.VISIBLE else View.GONE
        h.b.btnPay.visibility = if (r.showPay) View.VISIBLE else View.GONE
        h.b.btnPay.setOnClickListener { onPay(h.bindingAdapterPosition) }
        val show = com.shubh.vivah.util.Prefs.showActions
        h.b.btnEdit.visibility = if (show) View.VISIBLE else View.GONE
        h.b.btnDel.visibility = if (show) View.VISIBLE else View.GONE
        h.b.btnEdit.setOnClickListener { val p = h.bindingAdapterPosition; if (p != androidx.recyclerview.widget.RecyclerView.NO_POSITION) onEdit(p) }
        h.b.btnDel.setOnClickListener { val p = h.bindingAdapterPosition; if (p != androidx.recyclerview.widget.RecyclerView.NO_POSITION) onDelete(p) }
        h.b.btnWa.setOnClickListener { val p = h.bindingAdapterPosition; if (p != androidx.recyclerview.widget.RecyclerView.NO_POSITION) onWa(p) }
        h.b.tvChip.setOnClickListener { onChip(h.bindingAdapterPosition) }
        if (onRow != null) {
            h.itemView.setOnClickListener { val p = h.bindingAdapterPosition; if (p != androidx.recyclerview.widget.RecyclerView.NO_POSITION) onRow.invoke(p) }
        }
    }
}
