package com.shubh.vivah.ui.card

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.shubh.vivah.R
import com.shubh.vivah.data.CardData
import com.shubh.vivah.data.EvEvent
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import com.shubh.vivah.util.Lang

/**
 * Traditional 3-page invitation card (template 4) — A4 portrait 595 x 842 pt.
 * Page 1 cover, page 2 inner-left (couple + ceremonies), page 3 inner-right (name lists).
 */
object TraditionalCard {

    const val PW = 595
    const val PH = 842

    private const val PAPER = 0xFFFBE7DB.toInt()
    private const val INK = 0xFF7A1F1F.toInt()
    private const val MAROON = 0xFF7B1113.toInt()
    private const val GOLD = 0xFFB8860B.toInt()
    private const val MARGIN = 28f

    // ---- artwork / font (loaded once from the activity) ----
    @Volatile private var face: Typeface? = null
    private var ganeshBmp: Bitmap? = null
    private var stripBmp: Bitmap? = null
    private var dholakBmp: Bitmap? = null
    private var kalashBmp: Bitmap? = null
    private var horseBmp: Bitmap? = null
    private var emblemBmp: Bitmap? = null

    fun init(ctx: Context) {
        if (stripBmp == null) {
            ganeshBmp = decode(ctx, R.drawable.ganesh_art)
            stripBmp = decode(ctx, R.drawable.border_strip)
            dholakBmp = decode(ctx, R.drawable.dholak_shehnai)
            kalashBmp = decode(ctx, R.drawable.kalash)
            horseBmp = decode(ctx, R.drawable.horse_baraat)
            emblemBmp = decode(ctx, R.drawable.emblem_ganesh)
        }
        if (face == null) {
            face = try {
                androidx.core.content.res.ResourcesCompat.getFont(ctx, R.font.yatra_one)
            } catch (e: Exception) { null }
        }
    }

    private fun decode(ctx: Context, id: Int): Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, id)
    } catch (e: Exception) { null }

    private fun drawImg(c: Canvas, bmp: Bitmap?, left: Float, top: Float, w: Float, h: Float) {
        if (bmp == null) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
        c.drawBitmap(bmp, null, RectF(left, top, left + w, top + h), p)
    }

    private fun strips(c: Canvas, w: Float, h: Float) {
        drawImg(c, stripBmp, MARGIN + 8, MARGIN + 8, w - 2 * (MARGIN + 8), 24f)
        drawImg(c, stripBmp, MARGIN + 8, h - MARGIN - 32, w - 2 * (MARGIN + 8), 24f)
    }

    private val hiWeek = arrayOf("रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार")

    fun hindiWeekday(dateIso: String): String {
        if (dateIso.isBlank()) return ""
        return try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateIso) ?: return ""
            val c = Calendar.getInstance().apply { time = d }
            hiWeek[c.get(Calendar.DAY_OF_WEEK) - 1]
        } catch (e: Exception) { "" }
    }

    fun dotted(dateIso: String): String {
        if (dateIso.isBlank()) return ""
        val p = dateIso.split("-")
        return if (p.size == 3) "${p[2]}.${p[1]}.${p[0]}" else dateIso
    }

    // ---------- drawing helpers ----------

    private fun paint(size: Float, color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.CENTER): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            textAlign = align
            typeface = face ?: if (bold) Typeface.create(Typeface.SERIF, Typeface.BOLD)
            else Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }

    private fun line(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        bold: Boolean = false, align: Paint.Align = Paint.Align.CENTER
    ) {
        if (s.isBlank()) return
        c.drawText(s, x, y, paint(size, color, bold, align))
    }

    /** dil (heart) ke andar "संग" — purane card jaisa */
    private fun heart(c: Canvas, cx: Float, cy: Float, size: Float, fill: Int, label: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill; style = Paint.Style.FILL }
        val r = size / 2f
        val path = android.graphics.Path()
        path.moveTo(cx, cy + r * 0.8f)
        path.cubicTo(cx - r * 1.45f, cy - r * 0.15f, cx - r * 0.5f, cy - r * 1.15f, cx, cy - r * 0.42f)
        path.cubicTo(cx + r * 0.5f, cy - r * 1.15f, cx + r * 1.45f, cy - r * 0.15f, cx, cy + r * 0.8f)
        path.close()
        c.drawPath(path, p)
        line(c, label, cx, cy + r * 0.22f, size * 0.34f, Color.WHITE, true)
    }

    /** draws a wrapped paragraph and returns the height used */
    private fun para(c: Canvas, s: String, left: Float, top: Float, width: Float, size: Float, color: Int, bold: Boolean = false): Float {
        if (s.isBlank()) return 0f
        val tp = TextPaint().apply {
            this.color = color
            textSize = size
            isAntiAlias = true
            typeface = face ?: if (bold) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }
        val sl = StaticLayout.Builder.obtain(s, 0, s.length, tp, width.toInt())
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.12f)
            .build()
        c.save()
        c.translate(left, top)
        sl.draw(c)
        c.restore()
        return sl.height.toFloat()
    }

    private fun border(c: Canvas, w: Float, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = GOLD
        }
        c.drawRoundRect(RectF(MARGIN, MARGIN, w - MARGIN, h - MARGIN), 14f, 14f, p)
        val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = GOLD
        }
        c.drawRoundRect(RectF(MARGIN + 7, MARGIN + 7, w - MARGIN - 7, h - MARGIN - 7), 10f, 10f, inner)
        // corner ornaments
        val orn = paint(13f, GOLD)
        c.drawText("❁", MARGIN + 16, MARGIN + 26, orn)
        c.drawText("❁", w - MARGIN - 16, MARGIN + 26, orn)
        c.drawText("❁", MARGIN + 16, h - MARGIN - 12, orn)
        c.drawText("❁", w - MARGIN - 16, h - MARGIN - 12, orn)
    }

    private fun ganesh(c: Canvas, y: Float, w: Float) {
        line(c, "॥ श्री गणेशाय नमः ॥", w / 2, y, 13f, MAROON, true)
    }

    // ---------- pages ----------

    fun page1(c: Canvas, cd: CardData) {
        val w = PW.toFloat(); val h = PH.toFloat()
        c.drawColor(PAPER)
        border(c, w, h)
        strips(c, w, h)
        drawImg(c, ganeshBmp, MARGIN + 10, 92f, 118f, 148f)
        ganesh(c, 74f, w)

        // names
        line(c, "चि. ${cd.groom}".trim(), w / 2, 150f, 30f, INK, true)
        heart(c, w / 2, 186f, 52f, MAROON, "संग")
        line(c, "सौ.कां. ${cd.bride}".trim(), w / 2, 230f, 32f, INK, true)

        // date pill
        val pill = RectF(w / 2 - 150, 256f, w / 2 + 150, 288f)
        c.drawRoundRect(pill, 16f, 16f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = MAROON })
        val dateLine = buildString {
            append("दिनांक "); append(dotted(cd.date))
            val wd = hindiWeekday(cd.date); if (wd.isNotBlank()) { append(", "); append(wd) }
        }
        line(c, dateLine, w / 2, 279f, 13f, Color.WHITE, true)

        // venue box
        val box = RectF(MARGIN + 26, 312f, w - MARGIN - 26, 412f)
        c.drawRoundRect(box, 10f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.4f; color = GOLD
        })
        var y = 340f
        if (cd.venue.isNotBlank()) { line(c, "स्थान — ${cd.venue}", w / 2, y, 13f, INK, true); y += 26f }
        if (cd.time.isNotBlank()) { line(c, "समय — ${cd.time}", w / 2, y, 13f, INK); y += 26f }
        if (cd.addr.isNotBlank()) { y += para(c, "पता — ${cd.addr}", MARGIN + 40, y - 14f, w - 2 * (MARGIN + 40), 12f, INK); }

        val fam = if (cd.fam.isNotBlank()) "«${cd.fam}» परिवार" else ""
        line(c, fam, w / 2, 460f, 20f, MAROON, true)
        para(c, "का स्नेहिल आमंत्रण…", MARGIN + 30, 472f, w - 2 * (MARGIN + 30), 15f, INK)

        // sender block (bottom left)
        val left = MARGIN + 34
        line(c, "प्रेषक", left, 600f, 11f, GOLD, true)
        line(c, cd.sender, left, 620f, 14f, INK, true)
        if (cd.village.isNotBlank()) line(c, "ग्राम- ${cd.village}", left, 640f, 11f, INK)
        if (cd.dist.isNotBlank()) line(c, "जिला- ${cd.dist}", left, 656f, 11f, INK)
        if (cd.contact.isNotBlank()) line(c, "मो. ${cd.contact}", left, 672f, 11f, INK)

        drawImg(c, dholakBmp, w - MARGIN - 120, 604f, 96f, 76f)
        para(c, cd.msg, MARGIN + 30, 700f, w - 2 * (MARGIN + 30), 13f, INK, true)
        line(c, "❁", w / 2, 790f, 14f, GOLD)
    }

    fun page2(c: Canvas, cd: CardData, events: List<EvEvent>) {
        val w = PW.toFloat(); val h = PH.toFloat()
        c.drawColor(PAPER)
        border(c, w, h)
        strips(c, w, h)
        ganesh(c, 70f, w)
        line(c, "ॐ", MARGIN + 30, 112f, 24f, MAROON, true, Paint.Align.LEFT)
        para(c, "वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ।\nनिर्विघ्नं कुरुमे देव सर्वकार्येषु सर्वदा।।",
            MARGIN + 30, 84f, w - 2 * (MARGIN + 30), 11f, MAROON)

        line(c, "आत्मीय स्वजन,", w / 2, 146f, 14f, INK, true)
        para(c, "परमपिता परमेश्वर एवं पूर्वजों के आशीर्वाद से हमारे सुपुत्र एवं सुपुत्री का विवाह संस्कार सम्पन्न हो रहा है।",
            MARGIN + 34, 158f, w - 2 * (MARGIN + 34), 11f, INK)

        // two columns
        val colW = 200f
        val leftX = MARGIN + 34
        val rightX = w - MARGIN - 34 - colW
        var y1 = 220f
        line(c, "❋ आयुष्मान ❋", leftX + colW / 2, y1, 13f, MAROON, true); y1 += 22f
        line(c, "चि. ${cd.groom}".trim(), leftX + colW / 2, y1, 19f, INK, true); y1 += 20f
        if (cd.groomGF.isNotBlank()) { line(c, "सुपौत्र: ${cd.groomGF}", leftX + colW / 2, y1, 10.5f, INK); y1 += 17f }
        if (cd.groomF.isNotBlank()) { line(c, "सुपुत्र: ${cd.groomF}", leftX + colW / 2, y1, 10.5f, INK); y1 += 17f }
        if (cd.groomVill.isNotBlank()) {
            y1 += para(c, "ग्राम: ${cd.groomVill}, जिला- ${cd.groomDist}", leftX + 6, y1 - 12f, colW - 12, 10f, INK)
        }

        var y2 = 220f
        line(c, "❋ आयुष्मती ❋", rightX + colW / 2, y2, 13f, MAROON, true); y2 += 22f
        line(c, "सौ.कां. ${cd.bride}".trim(), rightX + colW / 2, y2, 19f, INK, true); y2 += 20f
        if (cd.brideGF.isNotBlank()) { line(c, "सुपौत्री: ${cd.brideGF}", rightX + colW / 2, y2, 10.5f, INK); y2 += 17f }
        if (cd.brideF.isNotBlank()) { line(c, "सुपुत्री: ${cd.brideF}", rightX + colW / 2, y2, 10.5f, INK); y2 += 17f }
        if (cd.brideVill.isNotBlank()) {
            y2 += para(c, "ग्राम: ${cd.brideVill}, जिला- ${cd.brideDist}", rightX + 6, y2 - 12f, colW - 12, 10f, INK)
        }
        drawImg(c, emblemBmp, w / 2 - 24, 244f, 48f, 48f)

        var y = maxOf(y1, y2) + 26f
        line(c, "के खूबसूरत पल", w / 2, y, 15f, MAROON, true); y += 20f
        y += para(c, "आपके सानिध्य में बिताना चाहते है, नवदम्पति को स्नेहिल आशीर्वाद दें,\nइसी चाहत के साथ…\nआपकी गरिमामयी उपस्थिति हेतु हमारा भावभरा आत्मीय आमंत्रण…",
            MARGIN + 34, y, w - 2 * (MARGIN + 34), 11f, INK)
        y += 16f

        // ceremonies
        val evs = events.filter { it.name.isNotBlank() && it.date.isNotBlank() }
        if (evs.isNotEmpty()) {
            line(c, "❁ मांगलिक कार्यक्रम ❁", w / 2, y, 14f, MAROON, true); y += 20f
            val start = cd.evStart.toIntOrNull() ?: 1
            evs.forEachIndexed { i, e ->
                val n = start + i
                val wd = hindiWeekday(e.date)
                val txt = "मा.सु.प. $n, दिनांक ${dotted(e.date)}" + (if (wd.isNotBlank()) ", $wd" else "") +
                    "- " + Lang.ev(e.name) + (if (e.venue.isNotBlank()) ", ${e.venue}" else "")
                line(c, txt, w / 2, y, 10.5f, INK)
                y += 17f
            }
            y += 8f
        }

        if (cd.venue.isNotBlank() || cd.addr.isNotBlank()) {
            line(c, "विवाह स्थल", w / 2, y, 13f, MAROON, true); y += 18f
            val place = listOf(cd.venue, cd.addr).filter { it.isNotBlank() }.joinToString(", ")
            y += para(c, place, MARGIN + 34, y - 12f, w - 2 * (MARGIN + 34), 11f, INK)
        }
        line(c, "❁", w / 2, h - MARGIN - 26, 14f, GOLD)
    }

    fun page3(c: Canvas, cd: CardData) {
        val w = PW.toFloat(); val h = PH.toFloat()
        c.drawColor(PAPER)
        border(c, w, h)
        strips(c, w, h)
        drawImg(c, kalashBmp, w - MARGIN - 74, 84f, 56f, 74f)
        ganesh(c, 70f, w)
        para(c, "मंगलम भगवान विष्णु, मंगलम गरुड़ध्वज।\nमंगलम पुंडरी कांक्षौ, मंगलाय तनो हरि।।",
            MARGIN + 30, 84f, w - 2 * (MARGIN + 30), 11f, MAROON)

        val colW = 235f
        val lx = MARGIN + 24
        val rx = w - MARGIN - 24 - colW
        var ly = 150f
        var ry = 150f

        ly = block(c, "✳ शुभेच्छुक ✳", cd.listShubh, lx, ly, colW)
        ly = block(c, "✳ दर्शनाभिलाषी ✳", cd.listDarshan, lx, ly + 6f, colW)

        ry = block(c, "✳ निहाती पलके ✳", cd.listNihati, rx, ry, colW)
        ry = block(c, "✳ स्वागताकांक्षी ✳", cd.listSwagat, rx, ry + 6f, colW)
        ry = block(c, "✳ विनीत ✳", cd.listVinit, rx, ry + 6f, colW)

        drawImg(c, dholakBmp, w - MARGIN - 90, 240f, 74f, 58f)
        drawImg(c, horseBmp, w / 2 - 80, h - MARGIN - 118, 160f, 82f)
        if (cd.contact.isNotBlank()) line(c, "मो. ${cd.contact}", w / 2, h - MARGIN - 56, 12f, INK, true)
        line(c, "❁", w / 2, h - MARGIN - 26, 14f, GOLD)
    }

    private fun block(c: Canvas, title: String, body: String, x: Float, y: Float, width: Float): Float {
        line(c, title, x + width / 2, y, 12.5f, MAROON, true)
        var yy = y + 16f
        if (body.isNotBlank()) yy += para(c, body, x, yy, width, 9.5f, INK)
        return yy
    }

    // ---------- output ----------

    /** Renders the three pages into bitmaps (for on-screen preview). */
    fun pages(cd: CardData, events: List<EvEvent>, scale: Float = 1.6f): List<android.graphics.Bitmap> {
        val out = ArrayList<android.graphics.Bitmap>()
        for (p in 1..3) {
            val bmp = android.graphics.Bitmap.createBitmap(
                (PW * scale).toInt(), (PH * scale).toInt(), android.graphics.Bitmap.Config.ARGB_8888
            )
            val c = Canvas(bmp)
            c.scale(scale, scale)
            when (p) {
                1 -> page1(c, cd)
                2 -> page2(c, cd, events)
                else -> page3(c, cd)
            }
            out.add(bmp)
        }
        return out
    }

    /** Writes the 3-page A4 PDF and returns the file. */
    fun pdf(file: File, cd: CardData, events: List<EvEvent>): File {
        val doc = PdfDocument()
        for (p in 1..3) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, p).create())
            when (p) {
                1 -> page1(page.canvas, cd)
                2 -> page2(page.canvas, cd, events)
                else -> page3(page.canvas, cd)
            }
            doc.finishPage(page)
        }
        check(doc.pages.size == 3) { "traditional card must be exactly 3 pages" }
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
