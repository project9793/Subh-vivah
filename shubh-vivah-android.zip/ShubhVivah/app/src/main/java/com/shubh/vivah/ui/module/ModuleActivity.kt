package com.shubh.vivah.ui.module

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.shubh.vivah.R

class ModuleActivity : AppCompatActivity() {

    companion object {
        fun start(ctx: Context, key: String) {
            ctx.startActivity(Intent(ctx, ModuleActivity::class.java).putExtra("key", key))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_module_host)
        val key = intent.getStringExtra("key") ?: "guests"
        supportFragmentManager.beginTransaction()
            .replace(R.id.host, ModuleFragment.newInstance(key))
            .commit()
    }
}
