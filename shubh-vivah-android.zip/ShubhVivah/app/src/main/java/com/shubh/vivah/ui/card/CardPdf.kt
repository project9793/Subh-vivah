package com.shubh.vivah.ui.card

import android.content.Context
import android.graphics.pdf.PdfDocument
import com.shubh.vivah.data.Wedding
import java.io.File
import java.io.FileOutputStream

object CardPdf {

    /** Builds the A4 PDF (3 pages for the traditional card) and returns the file. */
    fun build(ctx: Context, w: Wedding): File {
        val renderer = CardRenderer(ctx)
        val doc = PdfDocument()
        val pages = renderer.pageCount(w)
        for (i in 0 until pages) {
            val info = PdfDocument.PageInfo.Builder(
                CardRenderer.PW.toInt(), CardRenderer.PH.toInt(), i + 1
            ).create()
            val page = doc.startPage(info)
            renderer.renderPage(page.canvas, i, w)
            doc.finishPage(page)
        }
        val dir = File(ctx.cacheDir, "cards").apply { mkdirs() }
        val out = File(dir, "shubh-vivah-nimantan.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
        return out
    }
}
