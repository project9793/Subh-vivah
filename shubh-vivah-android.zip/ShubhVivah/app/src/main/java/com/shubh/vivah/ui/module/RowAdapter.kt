package com.shubh.vivah.ui.module

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.shubh.vivah.databinding.ItemRowBinding

data class Row(
    val id: String,
    val title: String,
    val line2: String,
    val amount: String
)

class RowAdapter(
    private val onClick: (Row) -> Unit,
    private val onDelete: (Row) -> Unit
) : ListAdapter<Row, RowAdapter.VH>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Row>() {
            override fun areItemsTheSame(a: Row, b: Row) = a.id == b.id
            override fun areContentsTheSame(a: Row, b: Row) = a == b
        }
    }

    inner class VH(val b: ItemRowBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = getItem(position)
        h.b.tvName.text = r.title
        h.b.tvLine2.text = r.line2
        h.b.tvAmount.text = r.amount
        h.b.root.setOnClickListener { onClick(r) }
        h.b.btnDelete.setOnClickListener { onDelete(r) }
    }
}
