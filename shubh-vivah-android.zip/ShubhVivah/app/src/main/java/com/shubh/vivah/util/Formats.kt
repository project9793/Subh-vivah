package com.shubh.vivah.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object Formats {

    private val WEEKDAYS = listOf("रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार")

    /** 125000.0 -> "₹1,25,000" */
    fun rupees(v: Double): String {
        val n = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.US, "%.2f", v)
        val neg = n.startsWith("-")
        val digits = if (neg) n.substring(1) else n
        val parts = digits.split(".")
        val intPart = parts[0]
        val sb = StringBuilder()
        if (intPart.length > 3) {
            val last3 = intPart.substring(intPart.length - 3)
            var rest = intPart.substring(0, intPart.length - 3)
            val groups = ArrayList<String>()
            while (rest.length > 2) {
                groups.add(0, rest.substring(rest.length - 2))
                rest = rest.substring(0, rest.length - 2)
            }
            if (rest.isNotEmpty()) groups.add(0, rest)
            sb.append(groups.joinToString(",")).append(",").append(last3)
        } else sb.append(intPart)
        if (parts.size > 1) sb.append(".").append(parts[1])
        return (if (neg) "-₹" else "₹") + sb.toString()
    }

    /** yyyy-MM-dd -> dd.MM.yyyy */
    fun dotDate(iso: String): String = try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso)!!
        SimpleDateFormat("dd.MM.yyyy", Locale.US).format(d)
    } catch (e: Exception) { iso }

    /** yyyy-MM-dd -> सोमवार */
    fun hindiWeekday(iso: String): String = try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso)!!
        val c = Calendar.getInstance(); c.time = d
        WEEKDAYS[c.get(Calendar.DAY_OF_WEEK) - 1]
    } catch (e: Exception) { "" }

    fun todayIso(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)

    fun uuid(): String = java.util.UUID.randomUUID().toString()
}
