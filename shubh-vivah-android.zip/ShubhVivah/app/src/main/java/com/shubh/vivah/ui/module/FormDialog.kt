package com.shubh.vivah.ui.module

import android.app.DatePickerDialog
import android.content.Context
import android.text.InputType
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.shubh.vivah.databinding.DialogFormBinding
import java.util.Calendar

/** Generic add/edit dialog built from a list of FieldSpec. */
object FormDialog {

    fun show(
        ctx: Context,
        title: String,
        fields: List<FieldSpec>,
        initial: Map<String, String> = emptyMap(),
        onSave: (Map<String, String>) -> Unit
    ) {
        val b = DialogFormBinding.inflate(LayoutInflater.from(ctx))
        val inputs = HashMap<String, TextInputEditText>()
        val choices = HashMap<String, AutoCompleteTextView>()

        fields.forEach { f ->
            val til = TextInputLayout(ctx).apply {
                hint = f.label
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (12 * ctx.resources.displayMetrics.density).toInt() }
                setPadding(0, 0, 0, 0)
            }
            when (f.type) {
                FieldType.CHOICE -> {
                    val ac = AutoCompleteTextView(ctx).apply {
                        setText(initial[f.key] ?: f.choices.firstOrNull().orEmpty(), false)
                        inputType = InputType.TYPE_NULL
                        adapter = ArrayAdapter(ctx, android.R.layout.simple_list_item_1, f.choices)
                        setOnClickListener { showDropDown() }
                    }
                    til.addView(ac)
                    choices[f.key] = ac
                }
                FieldType.DATE -> {
                    val et = TextInputEditText(ctx).apply {
                        isFocusable = false
                        setText(initial[f.key].orEmpty())
                        setOnClickListener {
                            val c = Calendar.getInstance()
                            DatePickerDialog(ctx, { _, y, m, d ->
                                setText(String.format("%04d-%02d-%02d", y, m + 1, d))
                            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                        }
                    }
                    til.addView(et)
                    inputs[f.key] = et
                }
                FieldType.NUMBER -> {
                    val et = TextInputEditText(ctx).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        setText(initial[f.key].orEmpty())
                        textSize = 16f
                    }
                    til.addView(et)
                    inputs[f.key] = et
                }
                FieldType.TEXT -> {
                    val et = TextInputEditText(ctx).apply {
                        inputType = InputType.TYPE_CLASS_TEXT
                        setText(initial[f.key].orEmpty())
                        textSize = 16f
                    }
                    til.addView(et)
                    inputs[f.key] = et
                }
            }
            b.formContainer.addView(til)
        }

        MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(b.root)
            .setPositiveButton("सेव करें") { _, _ ->
                val out = HashMap<String, String>()
                fields.forEach { f ->
                    out[f.key] = if (f.type == FieldType.CHOICE)
                        choices[f.key]?.text?.toString().orEmpty()
                    else inputs[f.key]?.text?.toString()?.trim().orEmpty()
                    if (f.required && out[f.key].isNullOrBlank()) {
                        Toast.makeText(ctx, "❌ ${f.label} भरना ज़रूरी है", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                }
                onSave(out)
            }
            .setNegativeButton("रद्द करें", null)
            .show()
    }
}
