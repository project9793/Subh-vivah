package com.shubh.vivah.ui.settings

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import com.shubh.vivah.R
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.Wedding
import com.shubh.vivah.databinding.FragmentSettingsBinding
import com.shubh.vivah.ui.auth.LoginActivity
import kotlinx.coroutines.launch
import java.io.File

class SettingsFragment : Fragment() {

    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!
    private var wedding = Wedding()

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@registerForActivityResult
        try {
            val json = requireContext().contentResolver.openInputStream(uri)!!
                .bufferedReader().readText()
            val w = Gson().fromJson(json, Wedding::class.java)
            lifecycleScope.launch {
                Repo.saveWedding(w)
                toast("✅ डेटा वापस आ गया")
            }
        } catch (e: Exception) { toast("❌ फाइल पढ़ी नहीं जा सकी") }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSettingsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)

        lifecycleScope.launch {
            Repo.loadProfile()?.let {
                b.tvProfileName.text = it.fullName.ifBlank { "—" }
                b.tvProfileInfo.text = "${it.mobile} • ${it.email} • ${it.city}"
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            Repo.weddingFlow().collect { wedding = it }
        }

        b.langHi.setOnClickListener { setLang("hi") }
        b.langEn.setOnClickListener { setLang("en") }

        b.tvCloud.text = getString(R.string.cloud_on)
        b.tvCloud.setOnClickListener { toast("डेटा Firestore में सुरक्षित है") }

        b.btnExport.setOnClickListener { exportJson() }
        b.btnImport.setOnClickListener { importLauncher.launch(arrayOf("application/json")) }

        b.btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finishAffinity()
        }
    }

    private fun setLang(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    private fun exportJson() {
        try {
            val dir = File(requireContext().filesDir, "backups").apply { mkdirs() }
            val f = File(dir, "shubh-vivah-backup.json")
            f.writeText(Gson().toJson(wedding))
            val uri = androidx.core.content.FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", f
            )
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "बैकअप शेयर करें"))
        } catch (e: Exception) { toast("❌ बैकअप नहीं बन पाया") }
    }

    private fun toast(m: String) = Toast.makeText(requireContext(), m, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
