package com.shubh.vivah.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.shubh.vivah.R
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.Wedding
import com.shubh.vivah.databinding.FragmentHomeBinding
import com.shubh.vivah.databinding.ItemHomeCardBinding
import com.shubh.vivah.ui.card.CardActivity
import com.shubh.vivah.ui.module.ModuleActivity
import com.shubh.vivah.util.Formats
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private var wedding = Wedding()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        b.tvUserName.text = Repo.auth.currentUser?.email?.substringBefore("@") ?: "—"
        lifecycleScope.launch {
            Repo.loadProfile()?.let {
                b.tvUserName.text = it.fullName.ifBlank { it.email.substringBefore("@") }
                b.tvUserCity.text = it.city
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            Repo.weddingFlow().collect { w ->
                wedding = w
                b.tvCouple.text = if (w.card.groom.isBlank() && w.card.bride.isBlank()) "शादी सेट करें"
                                  else "${w.card.groom} ❤ ${w.card.bride}"
                buildCards()
            }
        }
    }

    private data class CardDef(
        val key: String, val icon: String, val title: String,
        val value: String, val sub: String
    )

    private fun cards(): List<CardDef> {
        val w = wedding
        return listOf(
            CardDef("guests", "👥", "मेहमान", "${w.live.size}", "कुल मेहमान"),
            CardDef("events", "📅", "कार्यक्रम", "${w.liveEvents.size}", "इवेंट"),
            CardDef("items", "📦", "सामान", "${w.liveItems.size}", "सामान"),
            CardDef("dwr", "💰", "द्वारदारी", Formats.rupees(w.totalDwardari), "कुल द्वारदारी"),
            CardDef("halwai", "🍽️", "हलवाई", Formats.rupees(w.liveExps.filter { it.category == "हलवाई" }.sumOf { it.amount }), "कुल खर्च"),
            CardDef("decor", "✨", "सजावट", Formats.rupees(w.liveExps.filter { it.category == "सजावट" }.sumOf { it.amount }), "कुल खर्च"),
            CardDef("total", "💵", "कुल राशि", Formats.rupees(w.totalExpense), "कुल खर्च"),
            CardDef("varP", "👨‍👩‍👦", "वर पक्ष", "${w.live.count { it.side == "VAR" }}", "सदस्य"),
            CardDef("kanyaP", "👰", "कन्या पक्ष", "${w.live.count { it.side == "KANYA" }}", "सदस्य"),
            CardDef("baraat", "🚗", "बारात Live", "•", "लोकेशन"),
            CardDef("gharati", "🏠", "घरात/घराती", "•", "लोकेशन"),
            CardDef("card", "💌", "डिजिटल कार्ड", "${w.cardCount}", "बनाए गए"),
            CardDef("vehi", "🚙", "वाहन बुकिंग", "${w.liveVehi.size}", "गाड़ियाँ")
        )
    }

    private fun buildCards() {
        b.grid.removeAllViews()
        val m = resources.displayMetrics
        val w = (m.widthPixels - dp(40)) / 2
        cards().forEach { c ->
            val cb = ItemHomeCardBinding.inflate(layoutInflater, b.grid, false)
            cb.tvIcon.text = c.icon
            cb.tvTitle.text = c.title
            cb.tvValue.text = c.value
            cb.tvSub.text = c.sub
            val lp = android.widget.GridLayout.LayoutParams()
            lp.width = w
            lp.setMargins(dp(5), dp(5), dp(5), dp(5))
            cb.root.layoutParams = lp
            cb.root.setOnClickListener { open(c.key) }
            b.grid.addView(cb.root)
        }
    }

    private fun open(key: String) {
        when (key) {
            "baraat", "gharati" -> {
                // bottom nav ka location tab
                activity?.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNav)
                    ?.selectedItemId = R.id.nav_track
            }
            "card" -> startActivity(Intent(requireContext(), CardActivity::class.java))
            "total" -> ModuleActivity.start(requireContext(), "total")
            else -> ModuleActivity.start(requireContext(), key)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
