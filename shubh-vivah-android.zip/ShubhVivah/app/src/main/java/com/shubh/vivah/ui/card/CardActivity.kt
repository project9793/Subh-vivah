package com.shubh.vivah.ui.card

import android.content.Intent
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.shubh.vivah.data.CardInfo
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.Wedding
import com.shubh.vivah.databinding.ActivityCardBinding
import com.shubh.vivah.util.Formats
import kotlinx.coroutines.launch

class CardActivity : AppCompatActivity() {

    private lateinit var b: ActivityCardBinding
    private var wedding = Wedding()
    private val inputs = HashMap<String, TextInputEditText>()

    private data class F(val key: String, val label: String, val multiline: Boolean = false)

    private val fields = listOf(
        F("groom", "वर का नाम *"), F("bride", "कन्या का नाम *"),
        F("groomFather", "वर के पिता का नाम"), F("brideFather", "कन्या के पिता का नाम"),
        F("groomGrandfather", "वर के दादा जी (सुपौत्र)"), F("brideGrandfather", "कन्या के दादा जी (सुपौत्री)"),
        F("groomVillage", "वर का गाँव"), F("groomDist", "वर का जिला"),
        F("brideVillage", "कन्या का गाँव"), F("brideDist", "कन्या का जिला"),
        F("familyName", "परिवार / उपनाम"), F("sender", "प्रेषक"),
        F("village", "गाँव"), F("dist", "जिला"),
        F("contact", "मोबाइल नंबर"), F("date", "विवाह तारीख (yyyy-mm-dd)"),
        F("time", "समय"), F("venue", "स्थान"), F("addr", "पता"),
        F("eventStartNo", "कार्यक्रम शुरुआती संख्या (मा.सु.प.)"),
        F("listShubh", "शुभेच्छुक (एक नाम प्रति पंक्ति)", true),
        F("listNihati", "निहाती पलके", true),
        F("listDarshan", "दर्शनाभिलाषी", true),
        F("listSwagat", "स्वागताकांक्षी", true),
        F("listVinit", "विनीत", true)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityCardBinding.inflate(layoutInflater)
        setContentView(b.root)
        buildForm()

        lifecycleScope.launch {
            Repo.weddingFlow().collect {
                wedding = it
                fillForm(it.card)
            }
        }

        b.btnSaveCard.setOnClickListener { saveCard() }
        b.btnSample.setOnClickListener { fillForm(CardInfo()); toast("✨ नमूना भर दिया") }
        b.btnPreview.setOnClickListener { showPreview() }
        b.btnPdf.setOnClickListener { makePdf(share = false) }
        b.btnWa.setOnClickListener { makePdf(share = true) }
        b.btnPrint.setOnClickListener { printCard() }
    }

    private fun buildForm() {
        fields.forEach { f ->
            val til = TextInputLayout(this).apply {
                hint = f.label
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (10 * resources.displayMetrics.density).toInt() }
            }
            val et = TextInputEditText(this).apply {
                textSize = 15f
                if (f.multiline) {
                    inputType = android.text.InputType.TYPE_CLASS_TEXT or
                            android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    minLines = 2
                }
            }
            til.addView(et)
            inputs[f.key] = et
            b.formContainer.addView(til)
        }
    }

    private fun fillForm(cd: CardInfo) {
        fun set(k: String, v: String) { inputs[k]?.setText(v) }
        set("groom", cd.groom); set("bride", cd.bride)
        set("groomFather", cd.groomFather); set("brideFather", cd.brideFather)
        set("groomGrandfather", cd.groomGrandfather); set("brideGrandfather", cd.brideGrandfather)
        set("groomVillage", cd.groomVillage); set("groomDist", cd.groomDist)
        set("brideVillage", cd.brideVillage); set("brideDist", cd.brideDist)
        set("familyName", cd.familyName); set("sender", cd.sender)
        set("village", cd.village); set("dist", cd.dist); set("contact", cd.contact)
        set("date", cd.date); set("time", cd.time)
        set("venue", cd.venue); set("addr", cd.addr)
        set("eventStartNo", cd.eventStartNo.toString())
        set("listShubh", cd.listShubh); set("listNihati", cd.listNihati)
        set("listDarshan", cd.listDarshan); set("listSwagat", cd.listSwagat)
        set("listVinit", cd.listVinit)
    }

    private fun collect(): CardInfo {
        fun v(k: String) = inputs[k]?.text?.toString()?.trim().orEmpty()
        return wedding.card.copy(
            groom = v("groom"), bride = v("bride"),
            groomFather = v("groomFather"), brideFather = v("brideFather"),
            groomGrandfather = v("groomGrandfather"), brideGrandfather = v("brideGrandfather"),
            groomVillage = v("groomVillage"), groomDist = v("groomDist"),
            brideVillage = v("brideVillage"), brideDist = v("brideDist"),
            familyName = v("familyName"), sender = v("sender"),
            village = v("village"), dist = v("dist"), contact = v("contact"),
            date = v("date").ifBlank { Formats.todayIso() }, time = v("time"),
            venue = v("venue"), addr = v("addr"),
            eventStartNo = v("eventStartNo").toIntOrNull() ?: 1,
            listShubh = v("listShubh"), listNihati = v("listNihati"),
            listDarshan = v("listDarshan"), listSwagat = v("listSwagat"),
            listVinit = v("listVinit")
        )
    }

    private fun saveCard() {
        val w = wedding.copy(card = collect())
        lifecycleScope.launch {
            Repo.saveWedding(w)
            wedding = w
            toast("✅ कार्ड सेव हो गया")
        }
    }

    private fun showPreview() {
        val w = wedding.copy(card = collect())
        val bmp = CardRenderer(this).previewBitmap(w, 0, 1.3f)
        val iv = android.widget.ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setPadding(8, 8, 8, 8)
        }
        val sv = android.widget.ScrollView(this).apply { addView(iv) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Preview — पेज 1")
            .setView(sv)
            .setPositiveButton("ठीक है", null)
            .show()
    }

    private fun makePdf(share: Boolean) {
        val w = wedding.copy(card = collect())
        lifecycleScope.launch {
            try {
                Repo.saveWedding(w.copy(cardCount = w.cardCount + 1))
                val file = CardPdf.build(this@CardActivity, w)
                val uri = FileProvider.getUriForFile(
                    this@CardActivity, "$packageName.fileprovider", file
                )
                if (share) {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, "शुभ विवाह — निमंत्रण पत्र")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(i, "WhatsApp में भेजें"))
                } else {
                    val i = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(i)
                }
                toast("📄 PDF तैयार")
            } catch (e: Exception) {
                toast("कार्ड बन नहीं पाया — दोबारा कोशिश करें")
            }
        }
    }

    private fun printCard() {
        val w = wedding.copy(card = collect())
        lifecycleScope.launch {
            val file = CardPdf.build(this@CardActivity, w)
            val pm = getSystemService(PRINT_SERVICE) as PrintManager
            pm.print("शुभ विवाह कार्ड", PdfPrintAdapter(this@CardActivity, file),
                PrintAttributes.Builder().build())
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
