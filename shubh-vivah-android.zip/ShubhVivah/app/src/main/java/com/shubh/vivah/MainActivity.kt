package com.shubh.vivah

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.shubh.vivah.databinding.ActivityMainBinding
import com.shubh.vivah.ui.card.CardFragment
import com.shubh.vivah.ui.home.HomeFragment
import com.shubh.vivah.ui.module.ModuleFragment
import com.shubh.vivah.ui.settings.SettingsFragment
import com.shubh.vivah.ui.track.TrackFragment

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> show(HomeFragment())
                R.id.nav_events -> show(ModuleFragment.newInstance("events"))
                R.id.nav_card -> show(CardFragment())
                R.id.nav_track -> show(TrackFragment())
                R.id.nav_settings -> show(SettingsFragment())
                else -> return@setOnItemSelectedListener false
            }
            true
        }
        if (savedInstanceState == null) b.bottomNav.selectedItemId = R.id.nav_home
    }

    private fun show(f: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .commit()
    }
}
