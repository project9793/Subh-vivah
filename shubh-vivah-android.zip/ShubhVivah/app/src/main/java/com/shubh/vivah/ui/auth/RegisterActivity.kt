package com.shubh.vivah.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.shubh.vivah.MainActivity
import com.shubh.vivah.data.Profile
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var b: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnCreate.setOnClickListener {
            val name = b.etName.text?.toString()?.trim().orEmpty()
            val mobile = b.etMobile.text?.toString()?.trim().orEmpty()
            val email = b.etEmail.text?.toString()?.trim().orEmpty()
            val city = b.etCity.text?.toString()?.trim().orEmpty()
            val p1 = b.etPassword.text?.toString().orEmpty()
            val p2 = b.etPassword2.text?.toString().orEmpty()

            if (name.isBlank()) { toast("❌ नाम भरना ज़रूरी है"); return@setOnClickListener }
            if (mobile.length != 10) { toast("❌ मोबाइल नंबर 10 अंकों का होना चाहिए"); return@setOnClickListener }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                toast("❌ ईमेल सही नहीं है"); return@setOnClickListener
            }
            if (p1.length < 6) { toast("❌ पासवर्ड कम से कम 6 अक्षर"); return@setOnClickListener }
            if (p1 != p2) { toast("❌ दोनों पासवर्ड एक जैसे नहीं हैं"); return@setOnClickListener }

            b.btnCreate.isEnabled = false
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, p1)
                .addOnSuccessListener {
                    lifecycleScope.launch {
                        try {
                            Repo.createProfile(Profile(fullName = name, mobile = mobile,
                                email = email, city = city))
                        } catch (_: Exception) { }
                        startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                        finishAffinity()
                    }
                }
                .addOnFailureListener {
                    b.btnCreate.isEnabled = true
                    toast("❌ " + (it.message ?: "रजिस्टर नहीं हो पाया"))
                }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
