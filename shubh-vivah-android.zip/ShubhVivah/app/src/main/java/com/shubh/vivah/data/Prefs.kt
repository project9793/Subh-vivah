package com.shubh.vivah.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("sv_prefs")

object Prefs {
    private val LANG = stringPreferencesKey("lang")

    suspend fun setLang(ctx: Context, lang: String) {
        ctx.store.edit { it[LANG] = lang }
    }

    suspend fun lang(ctx: Context): String =
        ctx.store.data.map { it[LANG] ?: "hi" }.first()
}
