package com.shubh.vivah.ui.module

enum class FieldType { TEXT, NUMBER, DATE, CHOICE }

data class FieldSpec(
    val key: String,
    val label: String,
    val type: FieldType = FieldType.TEXT,
    val required: Boolean = false,
    val choices: List<String> = emptyList()
)

data class ModuleConfig(
    val key: String,
    val title: String,
    val fields: List<FieldSpec>,
    val nameField: String,
    val secondField: String? = null,
    val amountField: String? = null
)

object Modules {

    val guests = ModuleConfig(
        key = "guests", title = "मेहमान",
        nameField = "name", secondField = "relation", amountField = null,
        fields = listOf(
            FieldSpec("name", "नाम", required = true),
            FieldSpec("mobile", "मोबाइल"),
            FieldSpec("side", "पक्ष", FieldType.CHOICE, choices = listOf("VAR", "KANYA")),
            FieldSpec("relation", "रिश्ता"),
            FieldSpec("village", "गाँव/शहर")
        )
    )

    val events = ModuleConfig(
        key = "events", title = "कार्यक्रम",
        nameField = "name", secondField = "venue", amountField = null,
        fields = listOf(
            FieldSpec("date", "तारीख", FieldType.DATE, required = true),
            FieldSpec("name", "कार्यक्रम का नाम", required = true),
            FieldSpec("venue", "स्थान"),
            FieldSpec("time", "समय")
        )
    )

    val items = ModuleConfig(
        key = "items", title = "सामान",
        nameField = "name", secondField = "vendor", amountField = "total",
        fields = listOf(
            FieldSpec("name", "सामान का नाम", required = true),
            FieldSpec("qty", "मात्रा", FieldType.NUMBER),
            FieldSpec("rate", "दर", FieldType.NUMBER),
            FieldSpec("vendor", "दुकानदार")
        )
    )

    val exps = ModuleConfig(
        key = "exps", title = "खर्च",
        nameField = "title", secondField = "category", amountField = "amount",
        fields = listOf(
            FieldSpec("title", "शीर्षक", required = true),
            FieldSpec("category", "श्रेणी", FieldType.CHOICE,
                choices = listOf("खाना", "कपड़े", "गहने", "सजावट", "वाहन", "इतर")),
            FieldSpec("amount", "राशि", FieldType.NUMBER),
            FieldSpec("date", "तारीख", FieldType.DATE)
        )
    )

    val dwr = ModuleConfig(
        key = "dwr", title = "द्वारदारी",
        nameField = "guestName", secondField = "village", amountField = "cash",
        fields = listOf(
            FieldSpec("guestName", "मेहमान का नाम", required = true),
            FieldSpec("village", "गाँव"),
            FieldSpec("category", "श्रेणी", FieldType.CHOICE,
                choices = listOf("पाँवपूजा", "आँगन", "द्वारदारी")),
            FieldSpec("cash", "नगद (₹)", FieldType.NUMBER),
            FieldSpec("gift", "उपहार"),
            FieldSpec("date", "तारीख", FieldType.DATE)
        )
    )

    val vehi = ModuleConfig(
        key = "vehi", title = "वाहन बुकिंग",
        nameField = "name", secondField = "contact", amountField = "total",
        fields = listOf(
            FieldSpec("name", "वाहन / नाम", required = true),
            FieldSpec("count", "संख्या", FieldType.NUMBER),
            FieldSpec("rate", "दर", FieldType.NUMBER),
            FieldSpec("contact", "संपर्क")
        )
    )

    fun of(key: String): ModuleConfig = when (key) {
        "events" -> events
        "items" -> items
        "exps", "halwai", "decor" -> exps
        "dwr" -> dwr
        "vehi" -> vehi
        else -> guests
    }
}
