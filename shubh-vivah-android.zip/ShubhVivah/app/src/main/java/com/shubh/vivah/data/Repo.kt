package com.shubh.vivah.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

object Repo {

    private val db by lazy { FirebaseFirestore.getInstance() }
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    val uid: String get() = auth.currentUser?.uid ?: ""

    private fun weddingDoc() =
        db.collection("users").document(uid).collection("wedding").document("main")

    private fun userDoc() = db.collection("users").document(uid)

    /** Live wedding document — works offline from Firestore cache. */
    fun weddingFlow(): Flow<Wedding> = callbackFlow {
        val reg = weddingDoc().addSnapshotListener { snap, err ->
            if (err != null) { close(err); return@addSnapshotListener }
            val w = snap?.toObject(Wedding::class.java) ?: Wedding()
            trySend(w)
        }
        awaitClose { reg.remove() }
    }

    suspend fun saveWedding(w: Wedding) {
        weddingDoc().set(w.copy(updatedAt = System.currentTimeMillis())).await()
    }

    suspend fun createProfile(p: Profile) {
        userDoc().set(p).await()
        weddingDoc().set(Wedding()).await()
    }

    suspend fun loadProfile(): Profile? =
        userDoc().get().await().toObject(Profile::class.java)

    suspend fun saveProfile(p: Profile) {
        userDoc().set(p.copy(updatedAt = System.currentTimeMillis()), SetOptions.merge()).await()
    }

    // ---------------- tracking ----------------
    suspend fun createTracking(t: TrackingSession) {
        db.collection("tracking").document(t.id).set(t).await()
    }

    suspend fun pushPosition(id: String, lat: Double, lng: Double) {
        db.collection("tracking").document(id).update(
            mapOf("lat" to lat, "lng" to lng, "ts" to System.currentTimeMillis(),
                  "updatedAt" to System.currentTimeMillis())
        ).await()
    }

    suspend fun stopTracking(id: String) {
        db.collection("tracking").document(id).update(
            mapOf("active" to false, "updatedAt" to System.currentTimeMillis())
        ).await()
    }

    fun trackingFlow(id: String): Flow<TrackingSession?> = callbackFlow {
        val reg = db.collection("tracking").document(id)
            .addSnapshotListener { snap, err ->
                if (err != null) { close(err); return@addSnapshotListener }
                trySend(snap?.toObject(TrackingSession::class.java))
            }
        awaitClose { reg.remove() }
    }

    suspend fun getTracking(id: String): TrackingSession? =
        db.collection("tracking").document(id).get().await()
            .toObject(TrackingSession::class.java)

    fun newTrackingId(type: String): String {
        val pfx = if (type == "BARAAT") "VM" else "GHR"
        val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        return pfx + year + (1000..9999).random()
    }
}
