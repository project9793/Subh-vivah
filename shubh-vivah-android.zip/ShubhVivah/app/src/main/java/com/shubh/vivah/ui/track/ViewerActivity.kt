package com.shubh.vivah.ui.track

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.ActivityViewerBinding
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker

class ViewerActivity : AppCompatActivity() {

    private lateinit var b: ActivityViewerBinding
    private var marker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.map.setTileSource(TileSourceFactory.MAPNIK)
        b.map.setMultiTouchControls(true)
        b.map.controller.setZoom(15.0)
        b.map.controller.setCenter(GeoPoint(26.8467, 80.9462))

        askId()
    }

    private fun askId() {
        val et = TextInputEditText(this).apply { hint = "जैसे GHR20264812"; textSize = 16f }
        MaterialAlertDialogBuilder(this)
            .setTitle("ट्रैकिंग ID डालें")
            .setView(et)
            .setPositiveButton("देखें") { _, _ ->
                val id = et.text?.toString()?.trim().orEmpty()
                if (id.isBlank()) { finish(); return@setPositiveButton }
                watch(id)
            }
            .setNegativeButton("रद्द करें") { _, _ -> finish() }
            .show()
    }

    private fun watch(id: String) {
        lifecycleScope.launch {
            Repo.trackingFlow(id).collect { t ->
                if (t == null) { b.tvInfo.text = "❌ यह ID नहीं मिली"; return@collect }
                val gp = GeoPoint(t.lat, t.lng)
                if (marker == null) {
                    marker = Marker(b.map).apply {
                        position = gp; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        title = t.destName
                    }
                    b.map.overlays.add(marker)
                } else marker?.position = gp
                b.map.controller.animateTo(gp)
                b.map.invalidate()
                val when_ = if (t.ts > 0) java.text.SimpleDateFormat("hh:mm:ss", java.util.Locale.US)
                    .format(java.util.Date(t.ts)) else "—"
                b.tvInfo.text = if (!t.active) "🔴 ट्रैकिंग बंद — अंतिम स्थान: ${t.destName}"
                else "🟢 ${t.destName} • अंतिम अपडेट: $when_"
            }
        }
    }
}
