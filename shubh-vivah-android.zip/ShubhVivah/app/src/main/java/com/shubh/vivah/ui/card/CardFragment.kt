package com.shubh.vivah.ui.card

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentCardBinding
import kotlinx.coroutines.launch

class CardFragment : Fragment() {

    private var _b: FragmentCardBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentCardBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        b.btnOpenCard.setOnClickListener {
            startActivity(Intent(requireContext(), CardActivity::class.java))
        }
        b.btnCardPdf.setOnClickListener {
            startActivity(Intent(requireContext(), CardActivity::class.java))
        }
        viewLifecycleOwner.lifecycleScope.launch {
            Repo.weddingFlow().collect { w ->
                b.tvCardInfo.text = if (w.card.groom.isBlank()) "कार्ड अभी खाली है"
                else "${w.card.groom} ❤ ${w.card.bride}\n${w.cardCount} कार्ड बनाए गए"
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
