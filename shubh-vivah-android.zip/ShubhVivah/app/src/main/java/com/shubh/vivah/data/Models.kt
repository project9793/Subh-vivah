package com.shubh.vivah.data

data class Profile(
    var fullName: String = "",
    var mobile: String = "",
    var email: String = "",
    var addr: String = "",
    var city: String = "",
    var dist: String = "",
    var state: String = "",
    var pin: String = "",
    var isAdmin: Boolean = false,
    var blocked: Boolean = false,
    var updatedAt: Long = 0L
)

data class Guest(
    var id: String = "",
    var name: String = "",
    var mobile: String = "",
    var side: String = "VAR",          // VAR | KANYA
    var relation: String = "",
    var village: String = "",
    var invited: Boolean = true,
    var confirmed: Boolean = false,
    var note: String = "",
    var updatedAt: Long = 0L,
    var deleted: Boolean = false
)

data class Event(
    var id: String = "",
    var date: String = "",             // yyyy-MM-dd
    var name: String = "",
    var venue: String = "",
    var time: String = "",
    var updatedAt: Long = 0L,
    var deleted: Boolean = false
)

data class Item(
    var id: String = "",
    var name: String = "",
    var qty: Double = 0.0,
    var rate: Double = 0.0,
    var vendor: String = "",
    var bought: Boolean = false,
    var note: String = "",
    var updatedAt: Long = 0L,
    var deleted: Boolean = false
) { val total get() = qty * rate }

data class Expense(
    var id: String = "",
    var title: String = "",
    var category: String = "इतर",
    var amount: Double = 0.0,
    var date: String = "",
    var note: String = "",
    var updatedAt: Long = 0L,
    var deleted: Boolean = false
)

data class Dwardari(
    var id: String = "",
    var guestName: String = "",
    var village: String = "",
    var category: String = "द्वारदारी",   // पाँवपूजा | आँगन | द्वारदारी
    var cash: Double = 0.0,
    var gift: String = "",
    var date: String = "",
    var note: String = "",
    var updatedAt: Long = 0L,
    var deleted: Boolean = false
)

data class Vehicle(
    var id: String = "",
    var name: String = "",
    var count: Int = 1,
    var rate: Double = 0.0,
    var contact: String = "",
    var note: String = "",
    var updatedAt: Long = 0L,
    var deleted: Boolean = false
) { val total get() = count * rate }

data class CardInfo(
    var template: Int = 4,
    var lang: String = "hi",
    var groom: String = "गुंधेलाल",
    var bride: String = "शिवकुमारी",
    var groomPrefix: String = "चि.",
    var bridePrefix: String = "सौ.कां.",
    var groomFather: String = "ललक प्रजापति",
    var brideFather: String = "राम दुलारे चक्रधारी",
    var groomGrandfather: String = "गुलपत प्रजापति",
    var brideGrandfather: String = "सुकलाल चक्रधारी",
    var groomVillage: String = "अछोली",
    var groomDist: String = "बालोद",
    var brideVillage: String = "अछोटा",
    var brideDist: String = "धमतरी",
    var familyName: String = "प्रजापति",
    var sender: String = "गुलपत प्रजापति",
    var village: String = "अछोली",
    var dist: String = "बालोद (छ.ग.)",
    var contact: String = "1234567890",
    var date: String = "2022-11-28",
    var time: String = "रात 8:00 बजे",
    var venue: String = "ग्राम-अछोली",
    var addr: String = "जिला-बालोद (छ.ग.)",
    var message: String = "",
    var eventStartNo: Int = 1,
    var listShubh: String = "शलेन्द्र, अनिल, जगदीस,\nमालेन्द्र, राजेन्द्र, राज बिहारी",
    var listNihati: String = "कुणाल, भावेश, उत्तम,\nखुसील, लक्ष, पुष्पा, रिंकी",
    var listDarshan: String = "शिवकुमार- चौरसिया (फूफा-बुआ)\nमुन्ना- फूली (फूफा-बुआ)\nराजकुमार- रेखा (मामा-मामी)",
    var listSwagat: String = "राम सजीवन- रजनी (बड़ेपापा-मां)\nअरविन्द- उर्मिला (भैया-भाभी)",
    var listVinit: String = "ललऊराम - पार्वती (दादा-दादी)\nगुलपत - कुसुम (पिताजी-मां)"
)

data class Wedding(
    var groom: String = "",
    var bride: String = "",
    var date: String = "",
    var place: String = "",
    var guests: List<Guest> = emptyList(),
    var events: List<Event> = emptyList(),
    var items: List<Item> = emptyList(),
    var exps: List<Expense> = emptyList(),
    var dwr: List<Dwardari> = emptyList(),
    var vehi: List<Vehicle> = emptyList(),
    var card: CardInfo = CardInfo(),
    var cardCount: Int = 0,
    var updatedAt: Long = 0L
) {
    val live get() = guests.filter { !it.deleted }
    val liveEvents get() = events.filter { !it.deleted }.sortedBy { it.date }
    val liveItems get() = items.filter { !it.deleted }
    val liveExps get() = exps.filter { !it.deleted }
    val liveDwr get() = dwr.filter { !it.deleted }
    val liveVehi get() = vehi.filter { !it.deleted }

    val totalExpense: Double
        get() = liveExps.sumOf { it.amount } + liveItems.sumOf { it.total } + liveVehi.sumOf { it.total }
    val totalDwardari: Double get() = liveDwr.sumOf { it.cash }
}

data class TrackingSession(
    var id: String = "",
    var uid: String = "",
    var type: String = "BARAAT",
    var destName: String = "",
    var destAddr: String = "",
    var active: Boolean = true,
    var lat: Double = 0.0,
    var lng: Double = 0.0,
    var ts: Long = 0L,
    var updatedAt: Long = 0L
)
