package com.shubh.vivah.ui.card

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.shubh.vivah.R
import com.shubh.vivah.data.CardInfo
import com.shubh.vivah.data.Wedding
import com.shubh.vivah.util.Formats

/** Draws the invitation card. Same renderer is used for preview and PDF. */
class CardRenderer(private val ctx: Context) {

    companion object {
        const val PW = 595f
        const val PH = 842f
        const val PAGES = 3
    }

    private val ink = Color.parseColor("#7A1F1F")
    private val paper = Color.parseColor("#FBE7DB")

    private val deco: Typeface? by lazy { ResourcesCompat.getFont(ctx, R.font.yatra_one) }
    private val body: Typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)

    private fun paint(size: Float, color: Int = ink, t: Typeface? = body, bold: Boolean = false) =
        TextPaint().apply {
            this.color = color
            textSize = size
            typeface = if (bold) Typeface.create(t ?: body, Typeface.BOLD) else (t ?: body)
            isAntiAlias = true
        }

    private fun drawText(
        c: Canvas, text: String, p: TextPaint, y: Float, margin: Float = 26f,
        align: Layout.Alignment = Layout.Alignment.ALIGN_CENTER
    ): Float {
        if (text.isBlank()) return y
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, p, (PW - 2 * margin).toInt())
            .setAlignment(align)
            .setLineSpacing(4f, 1f)
            .setIncludePad(false)
            .build()
        c.save()
        c.translate(margin, y)
        layout.draw(c)
        c.restore()
        return y + layout.height
    }

    private fun img(id: Int): Bitmap? =
        BitmapFactory.decodeResource(ctx.resources, id)

    private fun drawPaper(c: Canvas) {
        c.drawColor(paper)
        c.drawRect(0f, 0f, PW, PH, Paint().apply { color = Color.parseColor("#FFF6EF") })
    }

    private fun drawStrip(c: Canvas, top: Boolean) {
        img(R.drawable.border_strip)?.let { bmp ->
            val h = PW * bmp.height / bmp.width
            val dst = if (top) RectF(0f, 0f, PW, h) else RectF(0f, PH - h, PW, PH)
            c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        }
    }

    /** Render page index (0..2 for template 4, 0 for others) into the canvas. */
    fun renderPage(c: Canvas, page: Int, w: Wedding) {
        val cd = w.card
        drawPaper(c)
        if (cd.template != 4) { renderSimple(c, w); return }
        drawStrip(c, true)
        when (page) {
            0 -> pageCover(c, cd)
            1 -> pageLeft(c, w)
            else -> pageRight(c, cd)
        }
        drawStrip(c, false)
    }

    // ---------------- page 1 : cover ----------------
    private fun pageCover(c: Canvas, cd: CardInfo) {
        var y = 62f
        y = drawText(c, "|| श्री गणेशाय नमः ||", paint(15f, ink, deco), y)
        y += 6f

        img(R.drawable.ganesh_art)?.let { bmp ->
            val h = 240f
            val wd = h * bmp.width / bmp.height
            c.drawBitmap(bmp, null, RectF(28f, y, 28f + wd, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
        }

        val rightX = 250f
        val p1 = paint(38f, ink, deco, true)
        val l1 = StaticLayout.Builder.obtain(cd.groom, 0, cd.groom.length, p1, (PW - rightX - 30).toInt())
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        c.save(); c.translate(rightX, y + 30f); l1.draw(c); c.restore()

        // heart with संग
        val hy = y + 30f + l1.height + 6f
        val hp = Paint().apply { color = ink; isAntiAlias = true }
        c.drawCircle(rightX + 70f, hy + 16f, 22f, hp)
        c.drawCircle(rightX + 100f, hy + 16f, 22f, hp)
        c.drawPath(Path().apply {
            moveTo(rightX + 50f, hy + 22f); lineTo(rightX + 120f, hy + 22f)
            lineTo(rightX + 85f, hy + 62f); close()
        }, hp)
        drawText(c, "संग", paint(20f, Color.WHITE, deco), hy + 4f, rightX + 8f)

        val p2 = paint(40f, ink, deco, true)
        val l2 = StaticLayout.Builder.obtain(cd.bride, 0, cd.bride.length, p2, (PW - rightX - 30).toInt())
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        c.save(); c.translate(rightX, hy + 70f); l2.draw(c); c.restore()

        y = 340f
        // date pill
        val dateTxt = "दिनांक ${Formats.dotDate(cd.date)}, ${Formats.hindiWeekday(cd.date)}"
        val dp = paint(15f, Color.WHITE, deco)
        val dw = dp.measureText(dateTxt) + 44f
        val r = RectF((PW - dw) / 2f, y, (PW + dw) / 2f, y + 34f)
        c.drawRoundRect(r, 17f, 17f, Paint().apply { color = ink; isAntiAlias = true })
        c.drawText(dateTxt, (PW - dp.measureText(dateTxt)) / 2f, y + 24f, dp)
        y += 46f

        // dotted box
        val boxPaint = Paint().apply {
            color = ink; style = Paint.Style.STROKE; strokeWidth = 1.2f
            pathEffect = DashPathEffect(floatArrayOf(5f, 5f), 0f); isAntiAlias = true
        }
        val lines = listOfNotNull(
            cd.venue.ifBlank { null },
            cd.time.ifBlank { null },
            cd.addr.ifBlank { null }
        )
        lines.forEach { line ->
            c.drawLine(60f, y + 14f, PW - 60f, y + 14f, boxPaint)
            drawText(c, line, paint(13f), y - 2f, 60f)
            y += 34f
        }
        y += 18f

        y = drawText(c, "${cd.familyName} परिवार", paint(28f, ink, deco), y)
        y = drawText(c, "का स्नेहिल आमंत्रण...", paint(23f, ink, deco), y + 4f)

        // sender block + dholak
        val sy = PH - 210f
        var sx = 40f
        val sp = paint(13f, ink)
        c.drawText("प्रेषक", sx, sy, paint(15f, ink, body, true))
        var yy = sy + 24f
        listOf(cd.sender, "ग्राम- ${cd.village}", "जिला - ${cd.dist}", "मो. ${cd.contact}").forEach {
            if (it.isNotBlank()) { c.drawText(it, sx, yy, sp); yy += 21f }
        }
        img(R.drawable.dholak_shehnai)?.let { bmp ->
            val h = 120f; val wd = h * bmp.width / bmp.height
            c.drawBitmap(bmp, null, RectF(PW - wd - 40f, PH - 190f, PW - 40f, PH - 70f),
                Paint(Paint.FILTER_BITMAP_FLAG))
        }
    }

    // ---------------- page 2 : inner left ----------------
    private fun pageLeft(c: Canvas, w: Wedding) {
        val cd = w.card
        var y = 54f
        y = drawText(c, "|| श्री गणेशाय नमः ||", paint(14f, ink, deco), y)
        y = drawText(c, "वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ।", paint(12f), y + 4f)
        y = drawText(c, "निर्विघ्नं कुरुमे देव सर्वकार्येषु सर्वदा।।", paint(12f), y)
        y += 14f
        y = drawText(c, "आत्मीय स्वजन,", paint(13f), y)
        y = drawText(c, "परमपिता परमेश्वर एवं पूर्वजों के आशीर्वाद से हमारे सुपुत्र ...", paint(12f), y + 2f)
        y += 16f

        // two columns
        val colW = (PW - 70f) / 2f
        val leftTop = y
        drawText(c, "* आयुष्मान *", paint(14f, ink, body, true), y, 30f)
        var ly = y + 26f
        val nm = paint(19f, ink, deco, true)
        c.drawText("${cd.groomPrefix} ${cd.groom}", 34f, ly + 14f, nm)
        ly += 30f
        listOf("सुपौत्र: ${cd.groomGrandfather}", "सुपुत्र: ${cd.groomFather}",
               "ग्राम: ${cd.groomVillage}, जिला- ${cd.groomDist}").forEach {
            ly = drawText(c, it, paint(11.5f), ly, 30f) + 2f
        }

        val rx = 40f + colW + 10f
        drawText(c, "* आयुष्मति *", paint(14f, ink, body, true), leftTop, rx)
        var ry = leftTop + 26f
        c.drawText("${cd.bridePrefix} ${cd.bride}", rx + 4f, ry + 14f, nm)
        ry += 30f
        listOf("सुपौत्री: ${cd.brideGrandfather}", "सुपुत्री: ${cd.brideFather}",
               "ग्राम: ${cd.brideVillage}, जिला- ${cd.brideDist}").forEach {
            ry = drawText(c, it, paint(11.5f), ry, rx) + 2f
        }

        img(R.drawable.emblem_ganesh)?.let { bmp ->
            val h = 70f; val wd = h * bmp.width / bmp.height
            c.drawBitmap(bmp, null, RectF((PW - wd) / 2f, leftTop + 20f, (PW + wd) / 2f, leftTop + 20f + h),
                Paint(Paint.FILTER_BITMAP_FLAG))
        }

        y = maxOf(ly, ry) + 18f
        c.drawLine(60f, y, PW - 60f, y, Paint().apply { color = ink; strokeWidth = 1f })
        y += 14f

        y = drawText(c, "के खुबसुरत पल", paint(17f, ink, deco), y)
        y = drawText(c, "आपके सानिध्य में बिताना चाहते है, नवदम्पति को स्नेहिल आशीर्वाद दें,", paint(11.5f), y + 2f)
        y = drawText(c, "इसी चाहत के साथ...", paint(11.5f), y)
        y = drawText(c, "आपकी गरिमामयी उपस्थिति हेतु हमारा भावभरा आत्मीय आमंत्रण...", paint(11.5f), y)
        y += 14f

        val evs = w.liveEvents
        if (evs.isNotEmpty()) {
            y = drawText(c, "❁ मांगलिक कार्यक्रम ❁", paint(17f, ink, deco), y)
            y += 2f
            evs.forEachIndexed { i, e ->
                val n = cd.eventStartNo + i
                val line = "मा.सु.प. $n, दिनांक ${Formats.dotDate(e.date)}, " +
                        "${Formats.hindiWeekday(e.date)}- ${e.name}" +
                        (if (e.venue.isNotBlank()) ", ${e.venue}" else "")
                y = drawText(c, line, paint(11.5f), y) + 1f
            }
            y += 12f
        }

        y = drawText(c, "विवाह स्थल", paint(17f, ink, deco), y)
        drawText(c, "${cd.venue}${if (cd.addr.isNotBlank()) ", ${cd.addr}" else ""}", paint(12.5f), y)
    }

    // ---------------- page 3 : inner right ----------------
    private fun pageRight(c: Canvas, cd: CardInfo) {
        var y = 54f
        img(R.drawable.kalash)?.let { bmp ->
            val h = 62f; val wd = h * bmp.width / bmp.height
            c.drawBitmap(bmp, null, RectF(PW - wd - 34f, 40f, PW - 34f, 40f + h),
                Paint(Paint.FILTER_BITMAP_FLAG))
        }
        y = drawText(c, "|| श्री गणेशाय नमः ||", paint(14f, ink, deco), y)
        y = drawText(c, "मंगलम भगवान विष्णु, मंगलम गरुड़ध्वज।", paint(12f), y + 4f)
        y = drawText(c, "मंगलम पुंडरी कांक्षौ, मंगलाय तनो हरि।।", paint(12f), y)
        y += 18f

        val leftLists = listOf("✳ शुभेच्छुक ✳" to cd.listShubh,
                               "✳ दर्शनाभिलाषी ✳" to cd.listDarshan)
        val rightLists = listOf("✳ निहाती पलके ✳" to cd.listNihati,
                                "✳ स्वागताकांक्षी ✳" to cd.listSwagat,
                                "✳ विनीत ✳" to cd.listVinit)

        val colW = (PW - 70f) / 2f
        var ly = y
        leftLists.forEach { (h, body) ->
            ly = drawText(c, h, paint(13f, ink, body2(), true), ly, 30f) + 2f
            ly = drawText(c, body, paint(11f), ly, 30f) + 10f
        }
        var ry = y
        val rx = 40f + colW + 10f
        rightLists.forEach { (h, body) ->
            ry = drawText(c, h, paint(13f, ink, body2(), true), ry, rx) + 2f
            ry = drawText(c, body, paint(11f), ry, rx) + 10f
        }

        img(R.drawable.dholak_shehnai)?.let { bmp ->
            val h = 90f; val wd = h * bmp.width / bmp.height
            c.drawBitmap(bmp, null, RectF(PW - wd - 40f, maxOf(ly, ry) + 6f, PW - 40f, maxOf(ly, ry) + 6f + h),
                Paint(Paint.FILTER_BITMAP_FLAG))
        }
        img(R.drawable.horse_baraat)?.let { bmp ->
            val h = 190f; val wd = h * bmp.width / bmp.height
            val top = PH - h - 70f
            c.drawBitmap(bmp, null, RectF((PW - wd) / 2f, top, (PW + wd) / 2f, top + h),
                Paint(Paint.FILTER_BITMAP_FLAG))
        }
        if (cd.contact.isNotBlank())
            drawText(c, "मो. ${cd.contact}", paint(13f), PH - 58f)
    }

    private fun body2(): Typeface = body

    // ---------------- simple templates 1-3 ----------------
    private fun renderSimple(c: Canvas, w: Wedding) {
        val cd = w.card
        val bg = when (cd.template) {
            1 -> Color.parseColor("#6D28D9")
            2 -> Color.parseColor("#FDF6EE")
            else -> Color.parseColor("#FBE7DB")
        }
        c.drawColor(bg)
        val fg = if (cd.template == 1) Color.WHITE else ink
        var y = 150f
        y = drawText(c, "|| श्री गणेशाय नमः ||", paint(15f, fg, deco), y)
        y += 30f
        y = drawText(c, cd.groom, paint(42f, fg, deco, true), y)
        y = drawText(c, "❤ संग ❤", paint(20f, fg, deco), y + 6f)
        y = drawText(c, cd.bride, paint(42f, fg, deco, true), y + 6f)
        y += 40f
        y = drawText(c, "दिनांक ${Formats.dotDate(cd.date)}, ${Formats.hindiWeekday(cd.date)}",
            paint(17f, fg, deco), y)
        y = drawText(c, "${cd.time}  •  ${cd.venue}", paint(14f, fg), y + 8f)
        y = drawText(c, "${cd.familyName} परिवार का स्नेहिल आमंत्रण...", paint(20f, fg, deco), y + 26f)
        if (w.liveEvents.isNotEmpty()) {
            y += 10f
            w.liveEvents.forEachIndexed { i, e ->
                y = drawText(c, "मा.सु.प. ${cd.eventStartNo + i}, ${Formats.dotDate(e.date)} - ${e.name}",
                    paint(12f, fg), y) + 1f
            }
        }
        var sy = PH - 150f
        c.drawText("प्रेषक", 50f, sy, paint(15f, fg, body, true))
        sy += 24f
        listOf(cd.sender, "ग्राम- ${cd.village}", "जिला - ${cd.dist}", "मो. ${cd.contact}").forEach {
            if (it.isNotBlank()) { c.drawText(it, 50f, sy, paint(12f, fg)); sy += 20f }
        }
    }

    /** Preview bitmap — identical drawing path as the PDF. */
    fun previewBitmap(w: Wedding, page: Int, scale: Float = 1.6f): Bitmap {
        val bmp = Bitmap.createBitmap((PW * scale).toInt(), (PH * scale).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(scale, scale)
        renderPage(c, page, w)
        return bmp
    }

    fun pageCount(w: Wedding) = if (w.card.template == 4) PAGES else 1
}
