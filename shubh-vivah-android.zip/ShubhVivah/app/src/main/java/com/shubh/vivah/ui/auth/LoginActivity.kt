package com.shubh.vivah.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.shubh.vivah.MainActivity
import com.shubh.vivah.R
import com.shubh.vivah.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var b: ActivityLoginBinding
    private val auth get() = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (auth.currentUser != null) { goHome(); return }
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnLogin.setOnClickListener { login() }
        b.btnRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        b.btnForgot.setOnClickListener {
            val email = b.etEmail.text?.toString()?.trim().orEmpty()
            if (email.isBlank()) { toast("ईमेल भरें"); return@setOnClickListener }
            auth.sendPasswordResetEmail(email)
                .addOnSuccessListener { toast("रीसेट लिंक भेजा गया") }
                .addOnFailureListener { toast("❌ " + (it.message ?: "नहीं भेजा जा सका")) }
        }
    }

    private fun login() {
        val email = b.etEmail.text?.toString()?.trim().orEmpty()
        val pass = b.etPassword.text?.toString().orEmpty()
        if (email.isBlank() || pass.isBlank()) { toast("ईमेल और पासवर्ड भरें"); return }
        b.btnLogin.isEnabled = false
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener { goHome() }
            .addOnFailureListener {
                b.btnLogin.isEnabled = true
                toast("❌ मोबाइल/ईमेल या पासवर्ड गलत है")
            }
    }

    private fun goHome() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
