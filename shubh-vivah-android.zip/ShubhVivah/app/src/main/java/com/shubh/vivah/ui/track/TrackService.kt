package com.shubh.vivah.ui.track

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.shubh.vivah.R
import com.shubh.vivah.data.Repo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TrackService : Service() {

    companion object {
        const val CH_ID = "sv_track"
        const val EXTRA_ID = "track_id"
        const val EXTRA_TYPE = "track_type"

        fun start(ctx: Context, id: String, type: String) {
            val i = Intent(ctx, TrackService::class.java)
                .putExtra(EXTRA_ID, id).putExtra(EXTRA_TYPE, type)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TrackService::class.java))
        }
    }

    private lateinit var fused: FusedLocationProviderClient
    private var trackId = ""
    private var lastPush = 0L
    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        trackId = intent?.getStringExtra(EXTRA_ID).orEmpty()
        val type = intent?.getStringExtra(EXTRA_TYPE) ?: "BARAAT"
        startForeground(1001, notification(type))
        startUpdates()
        return START_STICKY
    }

    private fun createChannel() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_ID, "Live Location", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(type: String): Notification {
        val title = if (type == "BARAAT") "📍 बारात लोकेशन चालू है" else "📍 घराती लोकेशन चालू है"
        return NotificationCompat.Builder(this, CH_ID)
            .setContentTitle(title)
            .setContentText(getString(R.string.tracking_on))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
    }

    @Suppress("MissingPermission")
    private fun startUpdates() {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000L)
            .setMinUpdateDistanceMeters(10f)
            .build()
        fused.requestLocationUpdates(req, object : LocationCallback() {
            override fun onLocationResult(r: LocationResult) {
                val loc: Location = r.lastLocation ?: return
                val now = System.currentTimeMillis()
                if (now - lastPush < 15_000L) return       // throttle: 1 write / 15 s
                lastPush = now
                scope.launch {
                    try { Repo.pushPosition(trackId, loc.latitude, loc.longitude) } catch (_: Exception) {}
                }
            }
        }, mainLooper)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.launch { try { Repo.stopTracking(trackId) } catch (_: Exception) {} }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
