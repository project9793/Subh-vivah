package com.shubh.vivah.ui.module

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.data.*
import com.shubh.vivah.databinding.FragmentModuleBinding
import com.shubh.vivah.util.Formats
import kotlinx.coroutines.launch

class ModuleFragment : Fragment() {

    companion object {
        fun newInstance(key: String) = ModuleFragment().apply {
            arguments = Bundle().apply { putString("key", key) }
        }
    }

    private var _b: FragmentModuleBinding? = null
    private val b get() = _b!!
    private var wedding = Wedding()
    private lateinit var adapter: RowAdapter
    private var key = "guests"

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentModuleBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        key = arguments?.getString("key") ?: "guests"

        adapter = RowAdapter(
            onClick = { row -> openEditor(row.id) },
            onDelete = { row -> confirmDelete(row.id) }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter

        b.fab.setOnClickListener { openEditor(null) }

        viewLifecycleOwner.lifecycleScope.launch {
            Repo.weddingFlow().collect { w ->
                wedding = w
                refresh()
            }
        }
    }

    private fun refresh() {
        val cfg = Modules.of(key)
        val rows = buildList {
            when (key) {
                "guests" -> wedding.live.forEach {
                    add(Row(it.id, it.name, listOf(it.relation, it.village, it.mobile)
                        .filter { s -> s.isNotBlank() }.joinToString(" • "),
                        if (it.side == "VAR") "वर पक्ष" else "कन्या पक्ष"))
                }
                "varP" -> wedding.live.filter { it.side == "VAR" }.forEach {
                    add(Row(it.id, it.name, it.relation, "वर पक्ष"))
                }
                "kanyaP" -> wedding.live.filter { it.side == "KANYA" }.forEach {
                    add(Row(it.id, it.name, it.relation, "कन्या पक्ष"))
                }
                "events" -> wedding.liveEvents.forEach {
                    add(Row(it.id, it.name, "${Formats.dotDate(it.date)} • ${Formats.hindiWeekday(it.date)}",
                        it.venue))
                }
                "items" -> wedding.liveItems.forEach {
                    add(Row(it.id, it.name, "${it.qty} × ${Formats.rupees(it.rate)}", Formats.rupees(it.total)))
                }
                "exps" -> wedding.liveExps.forEach {
                    add(Row(it.id, it.title, "${it.category} • ${Formats.dotDate(it.date)}", Formats.rupees(it.amount)))
                }
                "halwai", "decor" -> {
                    val cat = if (key == "halwai") "हलवाई" else "सजावट"
                    wedding.liveExps.filter { it.category == cat }.forEach {
                        add(Row(it.id, it.title, Formats.dotDate(it.date), Formats.rupees(it.amount)))
                    }
                }
                "dwr" -> wedding.liveDwr.forEach {
                    add(Row(it.id, it.guestName, "${it.category} • ${it.village} • ${it.gift}", Formats.rupees(it.cash)))
                }
                "vehi" -> wedding.liveVehi.forEach {
                    add(Row(it.id, it.name, "${it.count} × ${Formats.rupees(it.rate)}", Formats.rupees(it.total)))
                }
                "total" -> {
                    add(Row("t1", "कुल खर्च", "खर्च + सामान + वाहन", Formats.rupees(wedding.totalExpense)))
                    add(Row("t2", "कुल द्वारदारी", "मिली राशि", Formats.rupees(wedding.totalDwardari)))
                    add(Row("t3", "बाकी", "", Formats.rupees(wedding.totalExpense - wedding.totalDwardari)))
                }
            }
        }
        adapter.submitList(rows)
        b.tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        b.tvHeader.text = titleFor(key) + "  (${rows.size})"
        b.fab.visibility = if (key == "total") View.GONE else View.VISIBLE
    }

    private fun titleFor(k: String) = when (k) {
        "varP" -> "वर पक्ष"; "kanyaP" -> "कन्या पक्ष"; "dwr" -> "द्वारदारी"
        "vehi" -> "वाहन बुकिंग"; "items" -> "सामान"; "exps" -> "खर्च"
        "halwai" -> "हलवाई"; "decor" -> "सजावट"; "total" -> "कुल राशि"
        "events" -> "कार्यक्रम"; else -> "मेहमान"
    }

    private fun openEditor(id: String?) {
        if (key == "total") return
        val cfg = Modules.of(key)
        val initial = HashMap<String, String>()
        var existingId: String? = null

        when (key) {
            "guests", "varP", "kanyaP" -> wedding.live.firstOrNull { it.id == id }?.let {
                existingId = it.id
                initial["name"] = it.name; initial["mobile"] = it.mobile
                initial["side"] = if (key == "kanyaP") "KANYA" else if (key == "varP") "VAR" else it.side
                initial["relation"] = it.relation; initial["village"] = it.village
            }
            "events" -> wedding.liveEvents.firstOrNull { it.id == id }?.let {
                existingId = it.id
                initial["date"] = it.date; initial["name"] = it.name
                initial["venue"] = it.venue; initial["time"] = it.time
            }
            "items" -> wedding.liveItems.firstOrNull { it.id == id }?.let {
                existingId = it.id
                initial["name"] = it.name; initial["qty"] = it.qty.toString()
                initial["rate"] = it.rate.toString(); initial["vendor"] = it.vendor
            }
            "exps", "halwai", "decor" -> wedding.liveExps.firstOrNull { it.id == id }?.let {
                existingId = it.id
                initial["title"] = it.title; initial["category"] = it.category
                initial["amount"] = it.amount.toString(); initial["date"] = it.date
            }
            "dwr" -> wedding.liveDwr.firstOrNull { it.id == id }?.let {
                existingId = it.id
                initial["guestName"] = it.guestName; initial["village"] = it.village
                initial["category"] = it.category; initial["cash"] = it.cash.toString()
                initial["gift"] = it.gift; initial["date"] = it.date
            }
            "vehi" -> wedding.liveVehi.firstOrNull { it.id == id }?.let {
                existingId = it.id
                initial["name"] = it.name; initial["count"] = it.count.toString()
                initial["rate"] = it.rate.toString(); initial["contact"] = it.contact
            }
        }

        FormDialog.show(requireContext(), if (id == null) "नया जोड़ें" else "बदलें",
            cfg.fields, initial) { values ->
            viewLifecycleOwner.lifecycleScope.launch { save(existingId ?: Formats.uuid(), values) }
        }
    }

    private suspend fun save(id: String, v: Map<String, String>) {
        val now = System.currentTimeMillis()
        val w = wedding
        when (key) {
            "guests", "varP", "kanyaP" -> {
                val side = if (key == "kanyaP") "KANYA" else if (key == "varP") "VAR"
                           else v["side"]?.ifBlank { "VAR" } ?: "VAR"
                val g = Guest(id, v["name"].orEmpty(), v["mobile"].orEmpty(), side,
                    v["relation"].orEmpty(), v["village"].orEmpty(), updatedAt = now)
                w.guests = w.guests.filterNot { it.id == id } + g
            }
            "events" -> {
                val e = Event(id, v["date"].orEmpty(), v["name"].orEmpty(),
                    v["venue"].orEmpty(), v["time"].orEmpty(), now)
                w.events = w.events.filterNot { it.id == id } + e
            }
            "items" -> {
                val it0 = Item(id, v["name"].orEmpty(), v["qty"]?.toDoubleOrNull() ?: 0.0,
                    v["rate"]?.toDoubleOrNull() ?: 0.0, v["vendor"].orEmpty(), updatedAt = now)
                w.items = w.items.filterNot { it.id == id } + it0
            }
            "exps", "halwai", "decor" -> {
                val cat = if (key == "halwai") "हलवाई" else if (key == "decor") "सजावट"
                          else v["category"]?.ifBlank { "इतर" } ?: "इतर"
                val e = Expense(id, v["title"].orEmpty(), cat,
                    v["amount"]?.toDoubleOrNull() ?: 0.0, v["date"].orEmpty(), updatedAt = now)
                w.exps = w.exps.filterNot { it.id == id } + e
            }
            "dwr" -> {
                val d = Dwardari(id, v["guestName"].orEmpty(), v["village"].orEmpty(),
                    v["category"]?.ifBlank { "द्वारदारी" } ?: "द्वारदारी",
                    v["cash"]?.toDoubleOrNull() ?: 0.0, v["gift"].orEmpty(),
                    v["date"].orEmpty(), updatedAt = now)
                w.dwr = w.dwr.filterNot { it.id == id } + d
            }
            "vehi" -> {
                val ve = Vehicle(id, v["name"].orEmpty(), v["count"]?.toIntOrNull() ?: 1,
                    v["rate"]?.toDoubleOrNull() ?: 0.0, v["contact"].orEmpty(), updatedAt = now)
                w.vehi = w.vehi.filterNot { it.id == id } + ve
            }
        }
        Repo.saveWedding(w)
        Toast.makeText(requireContext(), "✅ सेव हो गया", Toast.LENGTH_SHORT).show()
    }

    private fun confirmDelete(id: String) {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("हटाएँ?")
            .setMessage("यह प्रविष्टि हट जाएगी।")
            .setPositiveButton("हाँ, हटाएँ") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    val w = wedding
                    when (key) {
                        "guests", "varP", "kanyaP" -> w.guests = w.guests.filterNot { it.id == id }
                        "events" -> w.events = w.events.filterNot { it.id == id }
                        "items" -> w.items = w.items.filterNot { it.id == id }
                        "exps", "halwai", "decor" -> w.exps = w.exps.filterNot { it.id == id }
                        "dwr" -> w.dwr = w.dwr.filterNot { it.id == id }
                        "vehi" -> w.vehi = w.vehi.filterNot { it.id == id }
                    }
                    Repo.saveWedding(w)
                }
            }
            .setNegativeButton("नहीं", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
