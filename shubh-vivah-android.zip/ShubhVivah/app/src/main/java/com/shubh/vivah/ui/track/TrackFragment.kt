package com.shubh.vivah.ui.track

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.TrackingSession
import com.shubh.vivah.databinding.DialogStartTrackBinding
import com.shubh.vivah.databinding.FragmentTrackBinding
import kotlinx.coroutines.launch

class TrackFragment : Fragment() {

    private var _b: FragmentTrackBinding? = null
    private val b get() = _b!!
    private var baraat: TrackingSession? = null
    private var gharati: TrackingSession? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentTrackBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        ensurePerms()

        b.btnBaraat.setOnClickListener {
            if (baraat?.active == true) stop(baraat!!) else start("BARAAT")
        }
        b.btnGharati.setOnClickListener {
            if (gharati?.active == true) stop(gharati!!) else start("GHARATI")
        }
        b.btnViewer.setOnClickListener {
            startActivity(Intent(requireContext(), ViewerActivity::class.java))
        }
    }

    private fun ensurePerms() {
        val need = listOf(Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION)
            .filter { ContextCompat.checkSelfPermission(requireContext(), it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    private fun start(type: String) {
        val dlg = DialogStartTrackBinding.inflate(layoutInflater)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("🎯 गंतव्य सेट करें")
            .setView(dlg.root)
            .setPositiveButton("शुरू करें") { _, _ ->
                val name = dlg.etDest.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) { toast("गंतव्य का नाम भरें"); return@setPositiveButton }
                val id = Repo.newTrackingId(type)
                val t = TrackingSession(
                    id = id, uid = Repo.uid, type = type, destName = name,
                    destAddr = dlg.etAddr.text?.toString()?.trim().orEmpty(), active = true
                )
                lifecycleScope.launch {
                    try { Repo.createTracking(t) } catch (_: Exception) {}
                    if (type == "BARAAT") baraat = t else gharati = t
                    refresh()
                    toast("🆔 आपकी ID: $id")
                    try {
                        TrackService.start(requireContext(), id, type)
                    } catch (e: Exception) {
                        toast("📍 GPS शुरू नहीं हो पाया — डेमो ट्रैकिंग आज़माएँ")
                    }
                }
            }
            .setNegativeButton("रद्द करें", null)
            .show()
    }

    private fun stop(t: TrackingSession) {
        lifecycleScope.launch {
            try { Repo.stopTracking(t.id) } catch (_: Exception) {}
            try { TrackService.stop(requireContext()) } catch (_: Exception) {}
            t.active = false
            refresh()
            toast("ट्रैकिंग बंद हो गई")
        }
    }

    private fun refresh() {
        b.btnBaraat.text = if (baraat?.active == true) "रोकें" else "Live Location शुरू करें"
        b.btnGharati.text = if (gharati?.active == true) "रोकें" else "Live Location शुरू करें"
        b.tvBaraatInfo.text = baraat?.let { "ID: ${it.id} • ${it.destName}" } ?: "अभी चालू नहीं"
        b.tvGharatiInfo.text = gharati?.let { "ID: ${it.id} • ${it.destName}" } ?: "अभी चालू नहीं"
    }

    private fun toast(m: String) = Toast.makeText(requireContext(), m, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
