# शुभ विवाह — Android App (Kotlin + XML + Firebase)

पूरा wedding management ऐप: मेहमान, कार्यक्रम, सामान, खर्च, द्वारदारी, वाहन,
डिजिटल कार्ड (4 टेम्पलेट + 3-पेज पारंपरिक), Live Location, Export/Import, हिंदी/English.

## खोलने का तरीका
1. **Android Studio** (Ladybug या नया) → *Open* → यह फोल्डर चुनें।
2. Gradle sync होने दें (पहली बार 3-5 मिनट)।
3. फोन में चलाएँ: *Run ▶*

## Firebase
- `app/google-services.json` पहले से रखी है (project `subh-vivah-a3875`, package `com.shubh.vivah`)।
- Console में करें:
  1. Authentication → Email/Password **Enable**
  2. Firestore Database → Create (region asia-south1) → **Rules** में `firestore.rules` फाइल का कंटेंट paste → Publish

## मुख्य फाइलें
```
app/src/main/java/com/shubh/vivah/
├── data/Models.kt          सारे डेटा मॉडल
├── data/Repo.kt            Firestore (offline cache के साथ)
├── ui/auth/                Login, Register
├── ui/home/HomeFragment   13 डैशबोर्ड कार्ड
├── ui/module/              मेहमान/कार्यक्रम/सामान/खर्च/द्वारदारी/वाहन (generic list + form)
├── ui/card/                कार्ड फॉर्म, CardRenderer (3 पेज), PDF, WhatsApp, प्रिंट
├── ui/track/               Live Location सेवा + OSMDroid नक्शा
└── ui/settings/            प्रोफाइल, भाषा, Export/Import, Logout
```

## APK बनाना
*Build → Build Bundle(s)/APK(s) → Build APK(s)*
रिलीज़ के लिए *Build → Generate Signed Bundle/APK*.

## ज़रूरी बातें
- पहली बार खोलने पर **Register** करें (ईमेल + पासवर्ड)।
- Live Location के लिए लोकेशन की अनुमति दें; न देने पर भी ID बनती है और demo से देख सकते हैं।
- कार्ड PDF: **डिजिटल कार्ड → PDF बनाएँ** — 3 पेज A4 बनते हैं (पारंपरिक टेम्पलेट पर)।
