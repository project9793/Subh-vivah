package com.shubh.vivah.ui.home

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.shubh.vivah.databinding.ItemHomeCardBinding

data class HomeCard(
    val icon: String,
    val title: String,
    val desc: String,
    val count: String,
    val tile: String,
    val live: Boolean = false,
    val route: Int,
    val tag: String = ""
)

class HomeCardAdapter(private val onClick: (HomeCard) -> Unit) :
    RecyclerView.Adapter<HomeCardAdapter.VH>() {

    private val items = ArrayList<HomeCard>()
    fun setItems(l: List<HomeCard>) { items.clear(); items.addAll(l); notifyDataSetChanged() }

    inner class VH(val b: ItemHomeCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemHomeCardBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val c = items[position]
        h.b.tvIcon.text = c.icon
        h.b.tvIcon.background.mutate().setTint(Color.parseColor(c.tile))
        h.b.tvTitle.text = c.title
        h.b.tvCount.text = c.count
        h.b.dot.visibility = if (c.live) android.view.View.VISIBLE else android.view.View.GONE
        h.b.root.setOnClickListener { onClick(c) }
    }
}
