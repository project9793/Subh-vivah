package com.shubh.vivah.ui.list

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.R
import com.shubh.vivah.data.*
import com.shubh.vivah.databinding.FragmentListPageBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.money
import com.shubh.vivah.util.showIf
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class ListFragment : Fragment() {

    private var _b: FragmentListPageBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var mode = "items"
    private var idx: List<String> = emptyList()
    private var filterProg: String? = null
    private var q = ""

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentListPageBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        mode = arguments?.getString("mode") ?: "items"
        b.btnBack.setOnClickListener { goBack() }
        b.btnSearch.visibility = if (mode == "dwardari") View.VISIBLE else View.GONE
        b.btnSearch.setOnClickListener {
            val open = b.etSearch.visibility != View.VISIBLE
            b.etSearch.visibility = if (open) View.VISIBLE else View.GONE
            if (open) b.etSearch.requestFocus() else { b.etSearch.setText(""); q = ""; render(vm.state.value) }
        }
        b.etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                q = s?.toString().orEmpty().trim()
                render(vm.state.value)
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
        })
        b.fab.setOnClickListener { edit(null) }
        // द्वारदारी me upar hi "Add dwardari entry" button hai — neeche ka + hata do
        b.fab.visibility = if (mode == "dwardari") View.GONE else View.VISIBLE
        b.btnExtra.showIf(mode == "dwardari")
        b.btnExtra.text = Lang.t("🧾 खर्च देखें / जोड़ें", "🧾 View / add expenses")
        b.btnExtra.setOnClickListener {
            findNavController().navigate(R.id.listFragment, bundleOf("mode" to "expenses"))
        }
        b.strip.showIf(mode != "none")

        adapter = RowAdapter(
            onEdit = { i ->
                if (mode == "dwardari") {
                    vm.state.value.dwr.firstOrNull { it.id == idx.getOrNull(i) }?.let { openProfile(it.name, it.village) }
                } else edit(idx.getOrNull(i))
            },
            // द्वारदारी me row par tap -> us mehmaan ki profile (entry confirm karne ke liye)
            onRow = if (mode == "dwardari") ({ i: Int ->
                val d = vm.state.value.dwr.firstOrNull { it.id == idx.getOrNull(i) }
                if (d != null) openProfile(d.name, d.village)
            }) else null,
            onDelete = { i ->
                if (mode == "dwardari") {
                    vm.state.value.dwr.firstOrNull { it.id == idx.getOrNull(i) }?.let { openProfile(it.name, it.village) }
                } else idx.getOrNull(i)?.let { id -> askDelete(id) }
            },
            onChip = { i ->
                if (mode == "items") {
                    idx.getOrNull(i)?.let { id ->
                        vm.state.value.items.firstOrNull { it.id == id }?.let { it0 ->
                            vm.saveItem(it0.copy(pay = if (it0.pay == "paid") "pend" else "paid"))
                        }
                    }
                }
            },
            onPay = { i ->
                val id = idx.getOrNull(i)
                val v = vm.state.value.vehi.firstOrNull { it.id == id }
                if (v != null) {
                    requireContext().confirm(
                        Lang.t("पूरा भुगतान?", "Full payment?"),
                        Lang.t(
                            "इस गाड़ी का पूरा किराया ${v.rate.money()} जमा दिखाया जाएगा।",
                            "This vehicle will be marked fully paid: ${v.rate.money()}."
                        )
                    ) {
                        vm.saveVehicle(v.copy(adv = v.rate))
                        requireContext().toast(Lang.t("✅ पूरा भुगतान दर्ज हो गया", "✅ Full payment recorded"))
                    }
                }
            }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        b.strip.showIf(mode != "dwardari")
        if (mode != "dwardari") b.extraBox.visibility = View.GONE
        when (mode) {
            "items" -> {
                b.tvTitle.text = Lang.t("📦 सामान", "📦 Items")
                setStrip(listOf(
                    c.itemsCount.toString() to Lang.t("कुल सामान", "Total items"),
                    c.itemsTotal.money() to Lang.t("कुल राशि", "Total amount"),
                    c.itemsPaid.money() to Lang.t("एडवांस", "Advance"),
                    (c.itemsTotal - c.itemsPaid).money() to Lang.t("बाकी", "Balance")
                ))
                idx = s.items.map { it.id }
                adapter.setItems(s.items.map { i ->
                    val paidAmt = if (i.adv > 0.0) i.adv else if (i.pay == "paid") i.rate else 0.0
                    val baki = i.rate - paidAmt
                    Row("📦", i.name,
                        if (baki <= 0.0) Lang.t("✅ भुगतान हो गया", "✅ Paid") else baki.money() + " " + Lang.t("बाकी", "due"),
                        "💵 " + Lang.t("दाम", "Price") + " " + i.rate.money() +
                            "\n💰 " + Lang.t("एडवांस", "Advance") + " " + paidAmt.money() +
                            (if (i.company.isNotBlank()) "\n🏬 " + i.company
                             else if (i.vendor.isNotBlank()) "\n🏬 " + i.vendor else ""),
                        color = if (baki <= 0.0) "#16A34A" else "#EA8C1B")
                })
            }
            "expenses" -> {
                b.tvTitle.text = Lang.t("🧾 खर्च", "🧾 Expenses")
                setStrip(listOf(
                    c.expTotal.money() to Lang.t("कुल खर्च","Total expense"),
                    s.exps.size.toString() to Lang.t("एंट्रीज","Entries")
                ))
                idx = s.exps.map { it.id }
                adapter.setItems(s.exps.map { e ->
                    Row("💰", e.name, e.date.dmy(), e.notes.ifBlank { e.amt.money() })
                })
            }
            "dwardari" -> {
                b.tvTitle.text = Lang.t("💰 द्वारदारी", "💰 Dwardari")
                hero(c)
                var list = if (filterProg == null) s.dwr else s.dwr.filter { it.prog == filterProg }
                fun nm2(t: String) = t.trim().lowercase().replace(Regex("\\s+"), " ")
                val serials = Calc.serialMap(s.guests)
                fun serialOf(name: String, vill: String): Int =
                    serials[Calc.keyOf(name, vill)]
                        ?: s.guests.firstOrNull { nm2(it.name) == nm2(name) && (nm2(vill).isBlank() || nm2(it.addr).isBlank() || nm2(it.addr) == nm2(vill)) }
                            ?.let { g -> serials[Calc.keyOf(g.name, g.addr)] } ?: 0
                if (q.isNotBlank()) {
                    val digits = q.all { it.isDigit() }
                    list = list.filter { d ->
                        if (digits) {
                            val ser = serialOf(d.name, d.village)
                            ser > 0 && (String.format("%03d", ser) == q.padStart(3, '0') || ser.toString() == q)
                        } else {
                            d.name.contains(q, true) || d.village.contains(q, true)
                        }
                    }
                }
                // ek mehmaan = ek row (teeno karyakram ki entries jud kar)
                val groups = list.groupBy { nm2(it.name) + "|" + nm2(it.village) }.values.toList()
                    .sortedBy { serialOf(it.first().name, it.first().village) }
                idx = groups.map { it.first().id }
                adapter.setItems(groups.map { grp ->
                    val d0 = grp.first()
                    val ser = serialOf(d0.name, d0.village)
                    val dwar = grp.filter { it.prog == "dwar" }.sumOf { it.cash }
                    val panv = grp.filter { it.prog == "panv" }.sumOf { it.cash }
                    val dahej = grp.filter { it.prog == "dahej" }.sumOf { it.cash }
                    val aangan = grp.filter { it.prog == "aangan" }.sumOf { it.cash }
                    val total = dwar + panv + dahej + aangan
                    val gifts = grp.mapNotNull { it.gift.trim().ifBlank { null } }
                    Row(
                        "🤝",
                        (if (ser > 0) String.format("%03d", ser) + "  " else "") + d0.name,
                        if (grp.size > 1) "${grp.size} एंट्री" else progLabel(d0.prog),
                        "🏠 ${d0.village.orDash()}\n💵 कुल नगद: ${total.money()}\n" +
                            "द्वारदारी ${dwar.money()} • पाँवपूजा ${panv.money()} • दहेज ${dahej.money()} • आँगन ${aangan.money()}" +
                            (if (gifts.isNotEmpty()) "\n🎁 " + gifts.joinToString(", ") else "")
                    )
                })
            }
            "vehicles" -> {
                b.tvTitle.text = Lang.t("🚗 वाहन बुकिंग", "🚗 Vehicles")
                val balance = c.vehiTotal - c.vehiAdv
                setStrip(listOf(
                    c.vehiCount.toString() to Lang.t("गाड़ियाँ", "Vehicles"),
                    c.vehiTotal.money() to Lang.t("कुल किराया", "Total fare"),
                    c.vehiAdv.money() to Lang.t("एडवांस", "Advance"),
                    balance.money() to Lang.t("बाकी देना है", "Balance")
                ))
                idx = s.vehi.map { it.id }
                adapter.setItems(s.vehi.map { v ->
                    val rem = v.rate - v.adv
                    Row("🚗", v.name,
                        v.rate.money(),
                        (if (v.number.isNotBlank()) "🔢 ${v.number}\n" else "") +
                            "🧑‍✈️ ${v.driver.orDash()} • 📱 ${v.mob.orDash()}\n" +
                            Lang.t("एडवांस", "Advance") + " ${v.adv.money()}" +
                            " • " + Lang.t("बाकी", "Balance") + " ${rem.money()}" +
                            (if (v.from.isNotBlank() || v.to.isNotBlank())
                                " • ${v.from.orDash()} → ${v.to.orDash()}" else ""),
                        showPay = rem > 0)
                })
            }
        }
    }

    private fun progLabel(p: String) = when (p) {
        "panv" -> "पाँवपूजा"; "dahej" -> "दहेज"; "aangan" -> "आँगन"; else -> "द्वारदारी"
    }

    private fun setStrip(tiles: List<Pair<String, String>>) {
        val views = listOf(b.t1 to b.k1, b.t2 to b.k2, b.t3 to b.k3, b.t4 to b.k4)
        views.forEachIndexed { i, (tv, kt) ->
            val item = tiles.getOrNull(i)
            tv.showIf(item != null); kt.showIf(item != null)
            if (item != null) {
                tv.text = item.first
                kt.text = item.second
                tv.textSize = if (item.first.length > 8) 11.5f else 13f
                // har tile ka apna rang
                val cols = intArrayOf(0xFFDB2777.toInt(), 0xFF2563EB.toInt(), 0xFF16A34A.toInt(), 0xFFEA8C1B.toInt())
                tv.setTextColor(cols[i % cols.size])
                kt.setTextColor(cols[i % cols.size])
            }
        }
    }

    private fun askDelete(id: String) {
        requireContext().confirm("हटाएँ?", "यह एंट्री हट जाएगी।") {
            when (mode) {
                "items" -> vm.delItem(id)
                "expenses" -> vm.delExpense(id)
                "dwardari" -> vm.delDwardari(id)
                "vehicles" -> vm.delVehicle(id)
            }
        }
    }

    /** mehmaan ki profile kholo (naam + gaon se) */
    private fun openProfile(name: String, vill: String) {
        try {
            val args = Bundle().apply { putString("gName", name); putString("gVill", vill) }
            findNavController().navigate(R.id.guestProfileFragment, args)
        } catch (e: Exception) {
            requireContext().toast("प्रोफ़ाइल नहीं खुल सकी")
        }
    }

    private fun edit(id: String?) {
        val s = vm.state.value
        when (mode) {
            "items" -> {
                val e = s.items.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", Lang.t("सामान का नाम *", "Item name *")),
                    Field("rate", Lang.t("सामान का दाम (₹) *", "Price (₹) *"), FType.NUM),
                    Field("adv", Lang.t("एडवांस दिया (₹)", "Advance paid (₹)"), FType.NUM),
                    Field("company", Lang.t("कंपनी / ब्रांड", "Company / brand")),
                    Field("pay", Lang.t("भुगतान", "Payment"), FType.SELECT,
                        listOf("paid" to Lang.t("✅ भुगतान हो गया", "✅ Paid"),
                               "pend" to Lang.t("⏳ बाकी", "⏳ Unpaid")))
                )
                FormDialog.show(requireContext(), Lang.t("📦 सामान", "📦 Item"), f, mapOf(
                    "name" to (e?.name ?: ""),
                    "rate" to (if (e == null) "" else e.rate.toString()),
                    "adv" to (if (e == null || e.adv <= 0.0) "" else e.adv.toString()),
                    "company" to (e?.company?.ifBlank { e.vendor } ?: ""),
                    "pay" to (e?.pay ?: "pend")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast(Lang.t("नाम ज़रूरी है", "Name is required")); return@show }
                    val amt = FormDialog.num(m, "rate")
                    if (amt <= 0.0) { requireContext().toast(Lang.t("दाम डालें", "Enter price")); return@show }
                    // गुणा नहीं — qty = 1 rakh kar seedha daam
                    vm.saveItem(Item(
                        id = id ?: "", name = n, qty = 1.0, rate = amt,
                        vendor = "", status = "done",
                        pay = if (FormDialog.num(m, "adv") >= amt) "paid" else "pend",
                        adv = FormDialog.num(m, "adv"),
                        company = FormDialog.str(m, "company")
                    ))
                    requireContext().toast(Lang.t("✅ सेव हो गया", "✅ Saved"))
                }
            }
            "expenses" -> {
                val e = s.exps.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "खर्च का नाम *"), Field("amt", "राशि (₹) *", FType.NUM),
                    Field("date", "तारीख", FType.DATE), Field("notes", "नोट्स", FType.MULTI)
                )
                FormDialog.show(requireContext(), "🧾 खर्च", f, mapOf(
                    "name" to (e?.name ?: ""), "amt" to (e?.amt ?: 0.0).toString(),
                    "date" to (e?.date ?: ""), "notes" to (e?.notes ?: "")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    vm.saveExpense(Expense(id ?: "", n, FormDialog.num(m, "amt"),
                        FormDialog.str(m, "date"), FormDialog.str(m, "notes")))
                    requireContext().toast("✅ सेव हो गया")
                }
            }
            "dwardari" -> {
                val e = s.dwr.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "मेहमान का नाम *"), Field("village", "गाँव / पता"),
                    Field("prog", "कार्यक्रम", FType.SELECT, listOf("dwar" to "द्वारदारी", "panv" to "पाँवपूजा", "dahej" to "दहेज", "aangan" to "आँगन")),
                    Field("cash", "नगद राशि (₹)", FType.NUM), Field("gift", "उपहार (विवरण)")
                )
                FormDialog.show(requireContext(), "💰 द्वारदारी", f, mapOf(
                    "name" to (e?.name ?: ""), "village" to (e?.village ?: ""),
                    "prog" to (e?.prog ?: "dwar"), "cash" to (e?.cash ?: 0.0).toString(),
                    "gift" to (e?.gift ?: "")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    val vil = FormDialog.str(m, "village")
                    val oldAt = vm.state.value.dwr.firstOrNull { it.id == id }?.at ?: 0L
                    vm.saveDwardari(Dwardari(id ?: "", n, vil,
                        FormDialog.str(m, "prog"), FormDialog.num(m, "cash"), FormDialog.str(m, "gift"),
                        at = if (oldAt > 0) oldAt else System.currentTimeMillis()))
                    // nimantran se mel: same naam + gaon. Na mile to nimantran me jod do (print card, aaya hua)
                    try {
                        fun nm(t: String) = t.trim().lowercase().replace(Regex("\\s+"), " ")
                        val gs = vm.state.value.guests
                        val hit = gs.firstOrNull { g ->
                            nm(g.name) == nm(n) &&
                                (nm(vil).isBlank() || nm(g.addr).isBlank() || nm(g.addr) == nm(vil))
                        }
                        if (hit == null) {
                            // pakka id — ek hi mehmaan dobara na jude
                            val gid = "g" + (nm(n) + "|" + nm(vil)).hashCode().toString().replace("-", "m")
                            vm.saveGuest(com.shubh.vivah.data.Guest(
                                id = gid, name = n, addr = vil, side = "kanya", sent = true, sendMode = "print"
                            ))
                        } else if (!hit.sent || hit.sendMode.isBlank()) {
                            vm.saveGuest(hit.copy(sent = true, sendMode = "print"))
                        }
                    } catch (ex: Exception) { }
                    requireContext().toast("✅ सेव हो गया")
                }
            }
            "vehicles" -> {
                val e = s.vehi.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "वाहन का नाम / प्रकार *"), Field("number", "वाहन नंबर"),
                    Field("driver", "वाहन मालिक का नाम"),
                    Field("mob", "मोबाइल"), Field("rate", "किराया (₹)", FType.NUM),
                    Field("adv", "एडवांस (₹)", FType.NUM), Field("from", "कहाँ से"), Field("to", "कहाँ तक")
                )
                FormDialog.show(requireContext(), "🚗 वाहन", f, mapOf(
                    "name" to (e?.name ?: ""), "number" to (e?.number ?: ""),
                    "driver" to (e?.driver ?: ""), "mob" to (e?.mob ?: ""),
                    "rate" to (e?.rate ?: 0.0).toString(), "adv" to (e?.adv ?: 0.0).toString(),
                    "from" to (e?.from ?: ""), "to" to (e?.to ?: "")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    vm.saveVehicle(Vehicle(id ?: "", n, FormDialog.str(m, "number"),
                        FormDialog.str(m, "driver"), FormDialog.str(m, "mob"),
                        FormDialog.num(m, "rate"), FormDialog.num(m, "adv"),
                        FormDialog.str(m, "from"), FormDialog.str(m, "to")))
                    requireContext().toast("✅ सेव हो गया")
                }
            }
        }
    }


    private data class Cat(val label: String, val prog: String, val amount: Double, val color: String)

    private fun hero(c: Calc.Totals) {
        val ctx = requireContext()
        val dp = resources.displayMetrics.density
        b.extraBox.removeAllViews()
        b.extraBox.visibility = View.VISIBLE

        val total = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            val tvAttr = android.util.TypedValue()
            requireContext().theme.resolveAttribute(R.attr.svTotalBg, tvAttr, true)
            setBackgroundResource(if (tvAttr.resourceId != 0) tvAttr.resourceId else R.drawable.bg_total_royal)
            setPadding(0, (18 * dp).toInt(), 0, (18 * dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (10 * dp).toInt() }
        }
        total.addView(TextView(ctx).apply {
            text = Lang.t("कुल द्वारदारी (नगद)", "Total Dwardari (cash)")
            setTextColor(Color.WHITE); textSize = 13f
            gravity = android.view.Gravity.CENTER
        })
        total.addView(TextView(ctx).apply {
            text = c.dwrTotal.money()
            setTextColor(Color.WHITE); textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = android.view.Gravity.CENTER
        })
        b.extraBox.addView(total)

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            Cat(Lang.t("द्वारदारी","Dwardari"), "dwar", c.dwrDwar, "#DB2777"),
            Cat(Lang.t("पाँवपूजा","Paw Puja"), "panv", c.dwrPanv, "#2563EB"),
            Cat(Lang.t("दहेज","Dahej"), "dahej", c.dwrDahej, "#0D9488"),
            Cat(Lang.t("आँगन","Aangan"), "aangan", c.dwrAangan, "#EA8C1B")
        ).forEach { cat ->
            val btn = com.google.android.material.button.MaterialButton(ctx).apply {
                text = cat.label + "\n" + cat.amount.money()
                textSize = 10.5f
                isAllCaps = false
                letterSpacing = 0f
                maxLines = 2
                setTextColor(Color.WHITE)
                backgroundTintList = com.shubh.vivah.ui.FormDialog.chipColor(cat.color)
                cornerRadius = (16 * dp).toInt()
                // 4 tile me jagah kam hoti hai — andar ki padding kam, text chhota
                setPadding((1 * dp).toInt(), (10 * dp).toInt(), (1 * dp).toInt(), (10 * dp).toInt())
                gravity = android.view.Gravity.CENTER
                alpha = if (filterProg == null || filterProg == cat.prog) 1f else 0.45f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { marginEnd = (5 * dp).toInt() }
                setOnClickListener {
                    filterProg = if (filterProg == cat.prog) null else cat.prog
                    render(vm.state.value)
                }
            }
            row.addView(btn)
        }
        b.extraBox.addView(row)

        val add = com.google.android.material.button.MaterialButton(ctx).apply {
            text = Lang.t("➕  द्वारदारी एंट्री जोड़ें", "➕  Add dwardari entry")
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = com.shubh.vivah.ui.FormDialog.chipColor("#7C3AED")
            cornerRadius = (18 * dp).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (52 * dp).toInt()
            ).apply { topMargin = (10 * dp).toInt() }
            setOnClickListener { edit(null) }
        }
        b.extraBox.addView(add)
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
