package com.shubh.vivah.ui.budget

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang
import com.shubh.vivah.util.Backup

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Calc
import com.shubh.vivah.databinding.FragmentBudgetBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.util.money
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class BudgetFragment : Fragment() {

    private var _b: FragmentBudgetBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private var pending = ""

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                requireContext().contentResolver.openOutputStream(uri)?.use { it.write(pending.toByteArray()) }
                requireContext().toast(Lang.t("✅ बैकअप सेव हो गया", "✅ Backup saved"))
            } catch (e: Exception) { requireContext().toast(Lang.t("⚠️ सेव नहीं हो सका", "⚠️ Could not save")) }
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentBudgetBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        try { b.tvTitle.text = Lang.t("💵 कुल राशि", "💵 Total expense") } catch (e: Exception) { }
        b.btnBack.setOnClickListener { goBack() }
        b.btnBudget.setOnClickListener {
            val w = vm.state.value.w
            FormDialog.show(requireContext(), Lang.t("💼 बजट बदलें", "💼 Change budget"),
                listOf(Field("budget", Lang.t("कुल बजट (₹)", "Total budget (₹)"), FType.NUM)),
                mapOf("budget" to w.budget.toString())
            ) { m ->
                vm.saveWedding(w.copy(budget = FormDialog.num(m, "budget")))
                requireContext().toast(Lang.t("✅ बजट सेव हो गया", "✅ Budget saved"))
            }
        }
        b.btnExport.setOnClickListener {
            requireContext().toast(Lang.t("⏳ बैकअप तैयार हो रहा है…", "⏳ Preparing backup…"))
            Backup.build(vm.uid) { json ->
                if (!isAdded) return@build
                if (json == null) { requireContext().toast(Lang.t("⚠️ बैकअप नहीं बन सका", "⚠️ Could not create backup")); return@build }
                pending = json
                createDoc.launch("shubh-vivah-backup.json")
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        b.chart.setBars(listOf(
            BarChartView.Bar(Lang.t("सामान", "Items"), c.itemsTotal),
            BarChartView.Bar(Lang.t("खर्च", "Expenses"), c.expTotal),
            BarChartView.Bar(Lang.t("हलवाई", "Halwai"), c.halwaiTotal),
            BarChartView.Bar(Lang.t("सजावट", "Decoration"), c.decorTotal),
            BarChartView.Bar(Lang.t("वाहन", "Vehicles"), c.vehiTotal)
        ))
        b.tvChartTitle.text = Lang.t("📊 खर्च विश्लेषण", "📊 Expense breakdown")
        b.tvKBudget.text = Lang.t("💼 कुल बजट", "💼 Total budget")
        b.tvKExp.text = Lang.t("💸 कुल खर्च", "💸 Total expense")
        b.tvKPaid.text = Lang.t("✅ कुल भुगतान", "✅ Total paid")
        b.tvKRem.text = Lang.t("⏳ बाकी राशि", "⏳ Remaining")
        // nakad, udhaar aur haath me bacha — saaf hisaab
        b.tvKCash.text = Lang.t("💰 नकद मिला", "💰 Cash received")
        b.tvKDue.text = Lang.t("🔴 बाकी देना है (उधार)", "🔴 Still to pay (credit)")
        b.tvKHand.text = Lang.t("👛 हाथ में बचा", "👛 Left in hand")
        b.tvCash.text = c.dwrNet.money()
        b.tvDue.text = (c.exp - c.paid).money()
        b.tvHand.text = (c.dwrNet - c.paid).money()
        b.btnBudget.text = Lang.t(Lang.t("💼 बजट बदलें", "💼 Change budget"), "💼 Change budget")
        b.btnExport.text = Lang.t("📤 डेटा export (बैकअप)", "📤 Export data (backup)")
        b.tvBudget.text = c.budget.money()
        b.tvExp.text = c.exp.money()
        b.tvPaid.text = c.paid.money()
        b.tvRem.text = Math.abs(c.rem).money() + if (c.rem < 0) Lang.t(" (बजट पार)", " (over budget)") else ""
        b.tvRem.setTextColor(
            if (c.rem < 0) 0xFFE11D48.toInt() else 0xFFC99A2E.toInt()
        )
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
