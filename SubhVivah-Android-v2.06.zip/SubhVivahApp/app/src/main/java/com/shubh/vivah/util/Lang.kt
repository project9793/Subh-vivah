package com.shubh.vivah.util

import android.content.Context

/**
 * Ek hi language switch poore app ke liye.
 * mode = "hi" (sab Hindi) | "en" (sab English) | "both" (Hindi + English)
 */
object Lang {

    @Volatile
    var mode: String = "en"

    fun load(ctx: Context) {
        mode = ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).getString("lang", "en") ?: "en"
    }

    fun save(ctx: Context, m: String) {
        mode = m
        ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).edit().putString("lang", m).apply()
    }

    /** hi / en / both ke hisaab se text chuno */
    fun t(hi: String, en: String): String = when (mode) {
        "en" -> en
        "both" -> if (en.isBlank()) hi else "$hi / $en"
        else -> hi
    }

    /** App ke default event naam — English mode me English */
    private val EV = mapOf(
        "हल्दी" to "Haldi", "मेहंदी" to "Mehndi", "तिलक" to "Tilak", "संगीत" to "Sangeet",
        "बारात" to "Baraat", "जयमाला" to "Jaimala", "विवाह" to "Wedding", "विदाई" to "Vidaai",
        "रिसेप्शन" to "Reception", "घुड़चढ़ी" to "Ghudchadhi", "मायरा" to "Mayra",
        "बन्ना बन्नी" to "Banna Banni", "हल्दी कार्यक्रम" to "Haldi"
    )

    fun ev(name: String): String = if (mode == "en") EV[name.trim()] ?: name else name

    fun isEn(): Boolean = mode == "en"
}
