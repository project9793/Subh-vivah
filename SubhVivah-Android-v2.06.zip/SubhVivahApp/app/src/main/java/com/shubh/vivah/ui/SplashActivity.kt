package com.shubh.vivah.ui

import android.animation.ValueAnimator
import androidx.appcompat.app.AlertDialog
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shubh.vivah.R
import com.shubh.vivah.data.Repo
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.Net
import com.shubh.vivah.util.Themes
import com.shubh.vivah.util.Lang

/** Shubh Vivah splash — internet check ke saath. */
class SplashActivity : AppCompatActivity() {

    private var offlineDialog: AlertDialog? = null
    private var went = false

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(Themes.currentStyle(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // internet wapas aate hi khud aage badh jao
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            cm?.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    runOnUiThread {
                        offlineDialog?.dismiss()
                        offlineDialog = null
                        go()
                    }
                }
            })
        } catch (ignored: Exception) { }

        // loading bar 0 → 100
        try {
            val pb = findViewById<ProgressBar>(R.id.pbSplash)
            ValueAnimator.ofInt(0, 100).apply {
                duration = 1250
                addUpdateListener { pb.progress = it.animatedValue as Int }
                start()
            }
        } catch (ignored: Exception) { }

        Handler(Looper.getMainLooper()).postDelayed({ go() }, 1300)
    }

    private fun go() {
        if (went) return
        if (!Net.isOnline(this)) {
            showOffline()
            return
        }
        went = true
        offlineDialog?.dismiss()
        val loggedIn = try { Repo.auth.currentUser != null } catch (e: Exception) { false }
        startActivity(Intent(this, if (loggedIn) MainActivity::class.java else AuthActivity::class.java))
        finish()
    }

    private fun showOffline() {
        if (isFinishing || offlineDialog?.isShowing == true) return
        offlineDialog = MaterialAlertDialogBuilder(this)
            .setTitle(Lang.t("📶 इंटरनेट बंद है", "📶 No internet"))
            .setMessage(
                Lang.t(
                    "शुभ विवाह को आपका डेटा खोलने के लिए इंटरनेट चाहिए।\n\n" +
                        "मोबाइल डेटा या Wi-Fi चालू करें — चालू होते ही ऐप खुद आगे बढ़ जाएगा।",
                    "Shubh Vivah needs internet to load your data.\n\n" +
                        "Turn on mobile data or Wi-Fi — the app will continue by itself."
                )
            )
            .setPositiveButton(Lang.t("फिर कोशिश करें", "Try again")) { _, _ -> offlineDialog = null; go() }
            .setNeutralButton(Lang.t("इंटरनेट खोलें", "Open internet settings")) { _, _ ->
                offlineDialog = null
                try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (ignored: Exception) { }
            }
            .setCancelable(false)
            .show()
    }
}
