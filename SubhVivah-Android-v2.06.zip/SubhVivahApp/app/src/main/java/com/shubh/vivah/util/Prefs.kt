package com.shubh.vivah.util

import android.content.Context

/** Chhoti settings jo phone me yaad rehti hain. */
object Prefs {

    @Volatile
    var showActions: Boolean = true      // list me ✏️ / 🗑 dikhein ya na dikhein

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("sv", Context.MODE_PRIVATE)
        showActions = p.getString("showActions", "on") != "off"
    }

    fun save(ctx: Context, v: Boolean) {
        showActions = v
        ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).edit()
            .putString("showActions", if (v) "on" else "off").apply()
    }
}
