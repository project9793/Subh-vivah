package com.shubh.vivah.ui.events

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.EvEvent
import com.shubh.vivah.databinding.FragmentListPageBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.ui.list.Row
import com.shubh.vivah.ui.list.RowAdapter
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch
import androidx.navigation.fragment.findNavController

class EventsFragment : Fragment() {

    private var _b: FragmentListPageBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var data: List<EvEvent> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentListPageBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.tvTitle.text = Lang.t("📋 कार्यक्रम", "📋 Events")
        b.btnBack.setOnClickListener { goBack() }
        b.strip.visibility = View.GONE
        b.btnExtra.visibility = View.GONE
        adapter = RowAdapter(
            onEdit = { i -> edit(data.getOrNull(i)) },
            onDelete = { i ->
                data.getOrNull(i)?.let { e ->
                    requireContext().confirm(Lang.t("हटाएँ?", "Delete?"), Lang.ev(e.name)) { remove(e) }
                }
            }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter
        b.fab.setOnClickListener { edit(null) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        data = s.w.events
        adapter.setItems(data.map { e ->
            Row(
                icon = e.icon.ifBlank { "🎉" },
                title = Lang.ev(e.name),
                chip = if (e.date.isBlank()) Lang.t("तारीख बाकी", "Date pending") else e.date.dmy(),
                meta = listOf(e.time, e.venue, e.addr, e.desc).filter { it.isNotBlank() }.joinToString(" • ")
            )
        })
    }

    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun edit(e: EvEvent?) {
        val fields = listOf(
            Field("name", "कार्यक्रम का नाम *"), Field("icon", "इमोजी (जैसे: 🔥)"),
            Field("date", "तारीख", FType.DATE),
            Field("time", "समय (जैसे: रात 8:00 बजे)"),
            Field("venue", "स्थान"),
            Field("addr", "पता"),
            Field("desc", "विवरण", FType.MULTI)
        )
        val vals = mapOf(
            "name" to (e?.name ?: ""), "icon" to (e?.icon ?: ""), "date" to (e?.date ?: ""), "time" to (e?.time ?: ""),
            "venue" to (e?.venue ?: ""), "addr" to (e?.addr ?: ""), "desc" to (e?.desc ?: "")
        )
        FormDialog.show(requireContext(), if (e == null) "कार्यक्रम जोड़ें" else "कार्यक्रम बदलें", fields, vals) { m ->
            val name = FormDialog.str(m, "name")
            if (name.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
            val icon = FormDialog.str(m, "icon").ifBlank {
                data.firstOrNull { it.name == name }?.icon
                    ?: com.shubh.vivah.data.Wedding.DEF.firstOrNull { it.first == name }?.second ?: "🎉"
            }
            val new = EvEvent(name, icon, FormDialog.str(m, "date"), FormDialog.str(m, "time"),
                FormDialog.str(m, "venue"), FormDialog.str(m, "addr"), FormDialog.str(m, "desc"))
            val list = data.toMutableList()
            if (e == null) list.add(new) else {
                val idx = data.indexOf(e); if (idx >= 0) list[idx] = new
            }
            vm.saveWedding(vm.state.value.w.copy(events = list))
            requireContext().toast("✅ सेव हो गया")
        }
    }

    private fun remove(e: EvEvent) {
        vm.saveWedding(vm.state.value.w.copy(events = data - e))
        requireContext().toast("🗑 हटा दिया")
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
