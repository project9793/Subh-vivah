package com.shubh.vivah.ui.budget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Simple horizontal bar chart — सामान / खर्च / हलवाई / सजावट / वाहन */
class BarChartView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    data class Bar(val label: String, val value: Double)

    private var bars: List<Bar> = emptyList()

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E1065"); textSize = 40f; isFakeBoldText = true
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#111827"); textSize = 38f; textAlign = Paint.Align.RIGHT
        isFakeBoldText = true
    }
    private val notePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6B7280"); textSize = 36f; textAlign = Paint.Align.CENTER
    }
    // har category ka apna rang (dwardari tiles jaisa)
    private val palette = intArrayOf(
        Color.parseColor("#DB2777"), // सामान
        Color.parseColor("#2563EB"), // खर्च
        Color.parseColor("#16A34A"), // हलवाई
        Color.parseColor("#7C3AED"), // सजावट
        Color.parseColor("#EA8C1B")  // वाहन
    )
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#A855F7") }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#EEE6F7") }

    fun setBars(list: List<Bar>) { bars = list; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val height = (bars.size.coerceAtLeast(1) * 120 + 20)
        setMeasuredDimension(MeasureSpec.getSize(w), height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (bars.isEmpty()) return
        val total = bars.sumOf { it.value }
        if (total <= 0.0) {
            canvas.drawText("कोई खर्च दर्ज नहीं", width / 2f, 60f, notePaint)
            return
        }
        val max = bars.maxOf { it.value }.coerceAtLeast(1.0)
        val labelW = 200f
        val valueW = 230f
        val barLeft = labelW
        val barRight = width - valueW
        var y = 10f
        bars.forEachIndexed { idx, b ->
            val col = palette[idx % palette.size]
            labelPaint.color = col
            valuePaint.color = col
            barPaint.color = col
            canvas.drawText(b.label, 0f, y + 44f, labelPaint)
            val r = RectF(barLeft, y + 16f, barRight, y + 56f)
            canvas.drawRoundRect(r, 20f, 20f, trackPaint)
            val w = ((barRight - barLeft) * (b.value / max)).toFloat()
            if (w > 0) canvas.drawRoundRect(RectF(barLeft, y + 16f, barLeft + w, y + 56f), 20f, 20f, barPaint)
            canvas.drawText(fmt(b.value), width.toFloat(), y + 44f, valuePaint)
            y += 120f
        }
    }

    private fun fmt(v: Double): String {
        val nf = java.text.NumberFormat.getInstance(java.util.Locale("en", "IN"))
        nf.maximumFractionDigits = 0
        return "₹" + nf.format(v)
    }
}
