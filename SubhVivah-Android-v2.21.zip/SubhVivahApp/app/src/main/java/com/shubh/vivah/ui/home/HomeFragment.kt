package com.shubh.vivah.ui.home

import com.shubh.vivah.util.*

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.shubh.vivah.R
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Calc
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentHomeBinding
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.money
import com.shubh.vivah.util.Lang
import com.shubh.vivah.util.showIf
import kotlinx.coroutines.launch
import androidx.core.os.bundleOf

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: HomeCardAdapter
    private var liveCount = 0
    private var liveListener: ValueEventListener? = null

    private data class NotifRow(val icon: String, val title: String, val sub: String)

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        adapter = HomeCardAdapter { card ->
            val args = Bundle()
            when (card.route) {
                R.id.listFragment -> args.putString("mode", card.tag)
                R.id.vendorFragment -> args.putString("kind", card.tag)
                R.id.familyFragment -> args.putString("side", card.tag)
                R.id.trackFragment -> args.putString("type", card.tag)
            }
            findNavController().navigate(card.route, args)
        }
        b.rvCards.layoutManager = GridLayoutManager(requireContext(), 2)
        b.rvCards.adapter = adapter

        b.btnProfile.setOnClickListener {
            findNavController().navigate(R.id.settingsFragment)
        }
        b.btnNotif.setOnClickListener { showNotifs() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
        watchLive()
    }

    private fun watchLive() {
        liveListener?.let { Repo.tracks().removeEventListener(it) }
        liveListener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                val uid = Repo.auth.currentUser?.uid ?: return
                liveCount = snap.children.count { c ->
                    c.child("ownerUid").getValue(String::class.java) == uid &&
                        c.child("active").getValue(Boolean::class.java) == true
                }
                vm.state.value.let { render(it) }
            }
            override fun onCancelled(error: DatabaseError) {}
        }.also { Repo.tracks().addValueEventListener(it) }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        val days = Calc.daysLeft(s.w.wdate)

        b.tvAva.text = s.user.fullName.trim().take(1).ifBlank { "?" }.uppercase()
        b.tvName.text = s.user.fullName.ifBlank { "—" }
        b.tvSub.text = "🏙 " + listOf(s.user.city, s.user.state).filter { it.isNotBlank() }.joinToString(", ").ifBlank { Lang.t("पता जोड़ें", "Add address") }
        b.tvCouple.text = if (s.w.groom.isNotBlank() || s.w.bride.isNotBlank())
            "💍 " + s.w.groom.ifBlank { "—" } + " ❤ " + s.w.bride.ifBlank { "—" }
        else Lang.t(getString(R.string.set_wedding), "Set up wedding")

        b.tvNames.text = when {
            s.w.groom.isNotBlank() && s.w.bride.isNotBlank() -> s.w.groom + " ❤ " + s.w.bride
            s.w.groom.isNotBlank() || s.w.bride.isNotBlank() -> s.w.groom.ifBlank { s.w.bride }
            else -> Lang.t("अपनी शादी सेट करें", "Set up your wedding")
        }
        b.tvKGuests.text = Lang.t("कुल मेहमान", "Total guests")
        b.tvKExp.text = Lang.t("कुल खर्च", "Total expense")
        b.tvGuests.text = c.guestTotal.toString()
        b.tvExp.text = if (c.exp >= 100000) c.exp.moneyShort() else c.exp.money()

        val list = listOf(
            HomeCard("💌", Lang.t("निमंत्रण","Invitations"), Lang.t("मेहमान व निमंत्रण प्रबंधन","Guests & invitations"), "${c.guestSent}/${c.guestTotal}", "#FCE7F3", false, R.id.guestsFragment, ""),
            HomeCard("📦", Lang.t("सामान","Items"), Lang.t("खरीदारी व वेंडर ट्रैकिंग","Shopping & vendors"), c.itemsCount.toString(), "#E0F2FE", false, R.id.listFragment, "items"),
            HomeCard("💰", Lang.t("द्वारदारी","Dwardari"), Lang.t("मेहमानों से मिली द्वारदारी","Cash gifts received"), c.dwrTotal.money(), "#FEF3C7", false, R.id.listFragment, "dwardari"),
            HomeCard("🍽️", Lang.t("हलवाई","Halwai"), Lang.t("खानपान व मेन्यू","Catering & menu"), c.halwaiTotal.money(), "#DCFCE7", false, R.id.vendorFragment, "halwai"),
            HomeCard("💌", Lang.t("डिजिटल कार्ड","Digital card"), Lang.t("न्योता पत्र बनाएँ व भेजें","Make & send invites"), s.w.cardCount.toString(), "#EDE9FE", false, R.id.cardFragment, ""),
            HomeCard("🚗", Lang.t("वाहन बुकिंग","Vehicles"), Lang.t("शादी की गाड़ियों का हिसाब","Wedding vehicles"), c.vehiCount.toString(), "#E0F2FE", false, R.id.listFragment, "vehicles"),
            HomeCard("✨", Lang.t("सजावट","Decoration"), Lang.t("टेंट, लाइट, स्टेज, फूल","Tent, lights, stage, flowers"), c.decorTotal.money(), "#EDE9FE", false, R.id.vendorFragment, "decor"),
            HomeCard("💵", Lang.t("कुल राशि","Total expense"), Lang.t("पूरा बजट व चार्ट","Budget & chart"), c.exp.money(), "#FFE4E6", false, R.id.budgetFragment, ""),
            HomeCard("👨‍👩‍👦", Lang.t("वर पक्ष","Groom side"), Lang.t("परिवार व मेहमान सूची","Family & guest list"), s.family.count { it.side == "var" }.toString(), "#E0F2FE", false, R.id.familyFragment, "var"),
            HomeCard("👰", Lang.t("कन्या पक्ष","Bride side"), Lang.t("परिवार व मेहमान सूची","Family & guest list"), s.family.count { it.side == "kanya" }.toString(), "#FCE7F3", false, R.id.familyFragment, "kanya"),
            HomeCard("🚗", Lang.t("बारात Live","Baraat live"), Lang.t("रियल-टाइम लोकेशन","Real-time location"), Lang.t("$liveCount लाइव","$liveCount live"), "#DCFCE7", liveCount > 0, R.id.trackFragment, "BARAAT"),
            HomeCard("🏠", Lang.t("घरात/घराती Live","Gharati live"), Lang.t("रियल-टाइम लोकेशन","Real-time location"), Lang.t("$liveCount लाइव","$liveCount live"), "#FEF3C7", liveCount > 0, R.id.trackFragment, "GHARATI"),
        )
        adapter.setItems(list)
        val notifOn = requireContext().getSharedPreferences("sv", Context.MODE_PRIVATE)
            .getString("notif", "on") != "off"
        b.dot.visibility = if (notifOn && notifCount(s, c) > 0) View.VISIBLE else View.GONE
    }

    private fun notifCount(s: AppState, c: com.shubh.vivah.data.Calc.Totals): Int {
        var n = 0
        val d = Calc.daysLeft(s.w.wdate)
        if (s.w.wdate.isNotBlank() && d in 0..30) n++
        n += s.w.events.count { e -> e.date.isNotBlank() && Calc.daysLeft(e.date) in 0..15 }
        if (c.guestPend > 0) n++
        if (c.guestTotal - c.guestConf - c.guestNo > 0) n++
        if (c.budget > 0 && c.exp > c.budget) n++
        return n
    }

    private fun showNotifs() {
        val s = vm.state.value
        val c = Calc.of(s)
        val list = ArrayList<NotifRow>()
        val d = Calc.daysLeft(s.w.wdate)
        if (s.w.wdate.isNotBlank() && d in 0..30)
            list.add(NotifRow("⏳", "विवाह में $d दिन बाकी!", "तैयारियाँ जोरों पर रखें"))
        s.w.events.forEach { e ->
            if (e.date.isNotBlank()) {
                val dd = Calc.daysLeft(e.date)
                if (dd in 0..15) list.add(NotifRow(e.icon.ifBlank { "🎉" }, "${Lang.ev(e.name)} — " + Lang.t("$dd दिन बाकी", "$dd days left"),
                    "${e.date.dmy()} ${e.time}" + (if (e.venue.isNotBlank()) " • ${e.venue}" else "")))
            }
        }
        if (c.guestPend > 0) list.add(NotifRow("💌", "${c.guestPend} निमंत्रण अभी नहीं भेजे गए", "निमंत्रण सेक्शन देखें"))
        if (c.guestTotal - c.guestConf - c.guestNo > 0)
            list.add(NotifRow("👥", "${c.guestTotal - c.guestConf - c.guestNo} मेहमानों का RSVP बाकी", "फॉलो-अप करें"))
        if (c.budget > 0 && c.exp > c.budget)
            list.add(NotifRow("⚠️", "बजट पार हो गया!", "खर्च ${c.exp.money()} / बजट ${c.budget.money()}"))

        val ctx = requireContext()
        val box = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(28, 24, 28, 8)
        }
        if (list.isEmpty()) {
            box.addView(android.widget.TextView(ctx).apply {
                text = "अभी कोई सूचना नहीं 🌸"; textSize = 13f
                setTextColor(android.graphics.Color.parseColor("#8B7AA6"))
            })
        } else {
            list.forEach { n ->
                val row = android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    setPadding(0, 14, 0, 14)
                }
                row.addView(android.widget.TextView(ctx).apply {
                    text = n.icon; textSize = 20f
                    setPadding(0, 0, 18, 0)
                })
                val col = android.widget.LinearLayout(ctx).apply { orientation = android.widget.LinearLayout.VERTICAL }
                col.addView(android.widget.TextView(ctx).apply {
                    text = n.title; textSize = 13.5f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(android.graphics.Color.parseColor("#3B2B52"))
                })
                if (n.sub.isNotBlank()) col.addView(android.widget.TextView(ctx).apply {
                    text = n.sub; textSize = 11.5f
                    setTextColor(android.graphics.Color.parseColor("#8B7AA6"))
                })
                row.addView(col)
                box.addView(row)
            }
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("🔔 सूचनाएँ")
            .setView(android.widget.ScrollView(ctx).apply { addView(box) })
            .setPositiveButton("ठीक है", null)
            .show()
    }

    override fun onDestroyView() {
        liveListener?.let { Repo.tracks().removeEventListener(it) }
        liveListener = null
        super.onDestroyView()
        _b = null
    }
}
