package com.shubh.vivah.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shubh.vivah.R
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.User
import com.shubh.vivah.databinding.FragmentSettingsBinding
import com.shubh.vivah.databinding.ItemSectionBinding
import com.shubh.vivah.databinding.ItemSettingBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang
import com.shubh.vivah.util.Themes
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class SettingsFragment : Fragment() {

    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()

    private var pendingExport: String = ""

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                requireContext().contentResolver.openOutputStream(uri)?.use { it.write(pendingExport.toByteArray()) }
                requireContext().toast("✅ बैकअप सेव हो गया")
            } catch (e: Exception) {
                requireContext().toast("⚠️ बैकअप सेव नहीं हो सका")
            }
        }
    }

    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importJson(uri)
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSettingsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { goBack() }
        try { b.tvTitle.text = Lang.t("⚙️ सेटिंग्स", "⚙️ Settings") } catch (e: Exception) { }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun section(title: String) {
        val row = ItemSectionBinding.inflate(layoutInflater, b.box, false)
        row.tvSection.text = title
        b.box.addView(row.root)
    }

    private fun row(
        icon: String, title: String, sub: String, arrow: String = "→",
        withSwitch: Boolean = false, switchOn: Boolean = false, click: () -> Unit
    ) {
        val r = ItemSettingBinding.inflate(layoutInflater, b.box, false)
        r.tvIcon.text = icon
        r.tvTitle.text = title
        r.tvSub.text = sub
        if (withSwitch) {
            r.sw.visibility = View.VISIBLE
            r.tvArrow.visibility = View.GONE
            r.sw.isChecked = switchOn
            r.sw.setOnCheckedChangeListener { _, checked ->
                requireContext().getSharedPreferences("sv", Context.MODE_PRIVATE)
                    .edit().putString("notif", if (checked) "on" else "off").apply()
                requireContext().toast(if (checked) "🔔 सूचनाएँ चालू" else "🔕 सूचनाएँ बंद")
            }
            r.root.setOnClickListener { r.sw.isChecked = !r.sw.isChecked }
        } else {
            r.root.setOnClickListener { click() }
        }
        b.box.addView(r.root)
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        b.box.removeAllViews()
        val u = s.user
        val notifOn = requireContext().getSharedPreferences("sv", Context.MODE_PRIVATE)
            .getString("notif", "on") != "off"

        // ---- खाता / Account ----
        section(Lang.t("खाता", "Account"))
        row("👤", u.fullName.ifBlank { "प्रोफ़ाइल" }, "${u.mobile} • ${u.email}", "✏️") { editProfile(u) }
        row("💍", Lang.t("विवाह डिटेल","Wedding details"),
            "${s.w.groom.ifBlank { "—" }} ❤ ${s.w.bride.ifBlank { "—" }} • ${s.w.wdate.dmy()}", "✏️") { editWedding(s) }
        row("🔐", Lang.t("पासवर्ड बदलें","Change password"), Lang.t("नया पासवर्ड बनाएँ","Change password")) { changePw() }
        if (u.admin) row("🛡️", Lang.t("Admin Panel","Admin panel"), Lang.t("यूज़र्स व आँकड़े देखें","Users & stats")) {
            findNavController().navigate(R.id.adminFragment)
        }

        // ---- प्राथमिकताएँ / Preferences ----
        section(Lang.t("प्राथमिकताएँ", "Preferences"))
        row("🔔", Lang.t("सूचनाएँ","Notifications"), Lang.t("कार्यक्रम व बजट अलर्ट","Event & budget alerts"), withSwitch = true, switchOn = notifOn) {}
        row("🌐", Lang.t("भाषा","Language"), langLabel(u.lang)) { pickLang(u) }
        row("🎨", Lang.t("थीम", "Theme"), Themes.label(requireContext(), Themes.currentKey(requireContext()))) {
            pickTheme()
        }
        row("💱", Lang.t("करेंसी","Currency"), Lang.t("₹ भारतीय रुपया","₹ Indian Rupee")) {
            info("💱 करेंसी", "करेंसी: ₹ INR (Indian Rupee)")
        }
        row("🔒", Lang.t("प्राइवेसी","Privacy"), Lang.t("डेटा आपके Firebase खाते में सुरक्षित","Data safe in your Firebase account")) {
            info("🔒 प्राइवेसी", "आपका डेटा सिर्फ़ आपके Firebase खाते में सुरक्षित रहता है — सिर्फ़ आप ही उसे देख सकते हैं।")
        }

        // ---- डेटा / Data ----
        section(Lang.t("डेटा", "Data"))
        row("☁️", Lang.t("क्लाउड सिंक (Firebase)","Cloud sync (Firebase)"),
            if (Repo.auth.currentUser != null) "चालू — डेटा क्लाउड में सुरक्षित" else "बंद — लॉगिन करें") {
            requireContext().toast("☁️ Firestore ऑटो-सिंक चालू है")
        }
        row("📤", Lang.t("एक्सपोर्ट / बैकअप","Export / Backup"), Lang.t("पूरा डेटा JSON में सेव करें","Save all data as JSON")) { exportJson() }
        row("📥", Lang.t("इम्पोर्ट","Import"), Lang.t("बैकअप से वापस लाएँ","Restore from backup")) {
            openDoc.launch(arrayOf("application/json", "text/plain", "*/*"))
        }

        // ---- और / More ----
        section(Lang.t("और", "More"))
        row("📖", Lang.t("उपयोग गाइड","User guide"), Lang.t("ऐप कैसे चलाएँ — पूरी जानकारी","How to use the app")) {
            findNavController().navigate(R.id.guideFragment)
        }
        row("🌸", Lang.t("ऐप के बारे में","About app"), "शुभ विवाह v" + com.shubh.vivah.BuildConfig.VERSION_NAME) {
            info("🌸 शुभ विवाह", "Vivah Management\nVersion " + com.shubh.vivah.BuildConfig.VERSION_NAME +
                " (build " + com.shubh.vivah.BuildConfig.VERSION_CODE + ")\nFirebase\n\nआपकी शादी का पूरा प्रबंधन, एक ही ऐप में।")
        }
        row("🏷️", Lang.t("ऐप वर्जन","App version"),
            "v" + com.shubh.vivah.BuildConfig.VERSION_NAME + " • build " + com.shubh.vivah.BuildConfig.VERSION_CODE) { }
        row("🚪", Lang.t("लॉगआउट","Logout"), Lang.t("Logout","Logout")) {
            requireContext().confirm("लॉगआउट?", "आप लॉगआउट हो जाएँगे।") { logout() }
        }

        b.tvVersion.text = "Version 1.0 • Firebase"
    }

    private fun pickTheme() {
        val ctx = requireContext()
        val cur = Themes.currentKey(ctx)
        val names = Themes.ALL.map { Lang.t(it.hi, it.en) }.toTypedArray()
        val idx = Themes.ALL.indexOfFirst { it.key == cur }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(ctx)
            .setTitle(Lang.t("🎨 थीम चुनें", "🎨 Choose theme"))
            .setSingleChoiceItems(names, idx) { d, which ->
                Themes.save(ctx, Themes.ALL[which].key)
                d.dismiss()
                requireContext().toast(Lang.t("✅ थीम बदल गई", "✅ Theme changed"))
                requireActivity().recreate()
            }
            .setNegativeButton(Lang.t("रद्द करें", "Cancel"), null)
            .show()
    }

    private fun info(title: String, msg: String) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(title).setMessage(msg).setPositiveButton("ठीक है", null).show()
    }

    private fun langLabel(l: String) = when (l) {
        "hi" -> "हिंदी"; "en" -> "English"; else -> "English"
    }

    private fun editProfile(u: User) {
        val f = listOf(
            Field("fullName", "पूरा नाम *"), Field("mobile", "मोबाइल नंबर *"),
            Field("email", "ईमेल *"), Field("addr", "पूरा पता", FType.MULTI),
            Field("city", "शहर"), Field("dist", "जिला"), Field("state", "राज्य"), Field("pin", "PIN कोड")
        )
        FormDialog.show(requireContext(), "👤 प्रोफ़ाइल", f, mapOf(
            "fullName" to u.fullName, "mobile" to u.mobile, "email" to u.email, "addr" to u.addr,
            "city" to u.city, "dist" to u.dist, "state" to u.state, "pin" to u.pin
        )) { m ->
            vm.saveProfile(u.copy(
                fullName = FormDialog.str(m, "fullName"), mobile = FormDialog.str(m, "mobile"),
                email = FormDialog.str(m, "email"), addr = FormDialog.str(m, "addr"),
                city = FormDialog.str(m, "city"), dist = FormDialog.str(m, "dist"),
                state = FormDialog.str(m, "state"), pin = FormDialog.str(m, "pin")
            ))
            requireContext().toast("✅ प्रोफ़ाइल सेव हो गई")
        }
    }

    private fun editWedding(s: AppState) {
        val f = listOf(
            Field("groom", "वर (दूल्हा) का नाम"), Field("bride", "कन्या (दुल्हन) का नाम"),
            Field("wdate", "विवाह तारीख", FType.DATE), Field("budget", "कुल बजट (₹)", FType.NUM)
        )
        FormDialog.show(requireContext(), "💍 विवाह डिटेल", f, mapOf(
            "groom" to s.w.groom, "bride" to s.w.bride, "wdate" to s.w.wdate, "budget" to s.w.budget.toString()
        )) { m ->
            vm.saveWedding(s.w.copy(
                groom = FormDialog.str(m, "groom"), bride = FormDialog.str(m, "bride"),
                wdate = FormDialog.str(m, "wdate"), budget = FormDialog.num(m, "budget")
            ))
            requireContext().toast("✅ सेव हो गया")
        }
    }

    private fun changePw() {
        FormDialog.show(requireContext(), "🔐 पासवर्ड बदलें",
            listOf(Field("old", "वर्तमान पासवर्ड *"), Field("pw", "नया पासवर्ड (6+ अक्षर) *"))
        ) { m ->
            val old = FormDialog.str(m, "old")
            val pw = FormDialog.str(m, "pw")
            if (old.isBlank()) { requireContext().toast("वर्तमान पासवर्ड डालें"); return@show }
            if (pw.length < 6) { requireContext().toast("नया पासवर्ड कम से कम 6 अक्षर"); return@show }
            val user = Repo.auth.currentUser
            val email = user?.email
            if (user == null || email == null) { requireContext().toast("लॉगिन नहीं है"); return@show }
            val cred = com.google.firebase.auth.EmailAuthProvider.getCredential(email, old)
            user.reauthenticate(cred)
                .addOnSuccessListener {
                    user.updatePassword(pw)
                        .addOnSuccessListener { requireContext().toast("✅ पासवर्ड बदल गया") }
                        .addOnFailureListener { requireContext().toast("⚠️ पासवर्ड नहीं बदला") }
                }
                .addOnFailureListener { requireContext().toast("❌ वर्तमान पासवर्ड गलत है") }
        }
    }

    private fun pickLang(u: User) {
        val opts = listOf("hi" to "हिंदी", "en" to "English", "both" to "हिंदी + English")
        FormDialog.show(requireContext(), "🌐 भाषा", listOf(Field("lang", "भाषा चुनें", FType.SELECT, opts)),
            mapOf("lang" to u.lang)
        ) { m ->
            val l = FormDialog.str(m, "lang").ifBlank { "en" }
            vm.saveProfile(u.copy(lang = l))
            Lang.save(requireContext(), l)
            requireContext().toast(if (l == "en") "✅ Language: English" else "✅ भाषा: हिंदी")
            requireActivity().recreate()
        }
    }

    private fun logout() {
        Repo.auth.signOut()
        startActivity(Intent(requireContext(), AuthActivity::class.java))
        requireActivity().finish()
    }

    // ---------- Backup / Restore ----------

    private fun exportJson() {
        val uid = vm.uid
        if (uid.isBlank()) { requireContext().toast("लॉगिन नहीं है"); return }
        requireContext().toast("⏳ बैकअप तैयार हो रहा है…")
        val db = Repo.db
        val root = JSONObject()
        db.collection("users").document(uid).get().addOnSuccessListener { ud ->
            root.put("user", toJson(ud.data ?: emptyMap<String, Any>()))
            db.collection("weddings").document(uid).get().addOnSuccessListener { wd ->
                root.put("wedding", toJson(wd.data ?: emptyMap<String, Any>()))
                val subs = listOf("guests", "items", "expenses", "dwardari", "vehicles", "family")
                var remaining = subs.size
                subs.forEach { name ->
                    db.collection("weddings").document(uid).collection(name).get()
                        .addOnSuccessListener { q ->
                            val arr = JSONArray()
                            q.documents.forEach { d ->
                                val o = toJson(d.data ?: emptyMap<String, Any>())
                                if (o is JSONObject) o.put("__id", d.id)
                                arr.put(o)
                            }
                            root.put(name, arr)
                            if (--remaining == 0) finishExport(root)
                        }
                        .addOnFailureListener { if (--remaining == 0) finishExport(root) }
                }
            }.addOnFailureListener { requireContext().toast("⚠️ बैकअप नहीं बन सका") }
        }.addOnFailureListener { requireContext().toast("⚠️ बैकअप नहीं बन सका") }
    }

    private fun finishExport(root: JSONObject) {
        if (!isAdded) return
        pendingExport = root.toString(2)
        createDoc.launch("shubh-vivah-backup.json")
    }

    private fun importJson(uri: Uri) {
        val uid = vm.uid
        if (uid.isBlank()) { requireContext().toast("लॉगिन नहीं है"); return }
        try {
            val text = requireContext().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: return
            val root = JSONObject(text)
            val db = Repo.db
            root.optJSONObject("wedding")?.let { w ->
                db.collection("weddings").document(uid).set(toMap(w))
            }
            listOf("guests", "items", "expenses", "dwardari", "vehicles", "family").forEach { name ->
                val arr = root.optJSONArray(name) ?: return@forEach
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val map = toMap(o).toMutableMap()
                    val id = (map.remove("__id") as? String).orEmpty()
                    val docId = id.ifBlank { db.collection("weddings").document(uid).collection(name).document().id }
                    db.collection("weddings").document(uid).collection(name).document(docId).set(map)
                }
            }
            requireContext().toast("✅ बैकअप रीस्टोर हो गया")
        } catch (e: Exception) {
            requireContext().toast("⚠️ फ़ाइल पढ़ी नहीं जा सकी")
        }
    }

    private fun toJson(v: Any?): Any {
        return when (v) {
            null -> JSONObject.NULL
            is Map<*, *> -> JSONObject().also { o -> v.forEach { (k, value) -> o.put(k.toString(), toJson(value)) } }
            is List<*> -> JSONArray().also { a -> v.forEach { item -> a.put(toJson(item)) } }
            is String, is Number, is Boolean -> v
            else -> v.toString()
        }
    }

    private fun toMap(o: JSONObject): Map<String, Any> {
        val m = HashMap<String, Any>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val value = fromJson(o.get(k))
            if (value != null) m[k] = value
        }
        return m
    }

    private fun fromJson(v: Any?): Any? = when (v) {
        null, JSONObject.NULL -> null
        is JSONObject -> toMap(v)
        is JSONArray -> (0 until v.length()).mapNotNull { fromJson(v.get(it)) }
        else -> v
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
