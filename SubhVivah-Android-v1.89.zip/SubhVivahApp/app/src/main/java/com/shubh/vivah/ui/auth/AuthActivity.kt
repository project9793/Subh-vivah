package com.shubh.vivah.ui.auth

import com.shubh.vivah.util.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.shubh.vivah.App
import com.shubh.vivah.util.Net
import com.shubh.vivah.util.Themes

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.User
import com.shubh.vivah.data.Wedding
import com.shubh.vivah.databinding.ActivityAuthBinding
import com.shubh.vivah.ui.MainActivity
import com.shubh.vivah.util.toast

class AuthActivity : AppCompatActivity() {

    private lateinit var b: ActivityAuthBinding
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(Themes.currentStyle(this))
        super.onCreate(savedInstanceState)
        try {
            setup()
            applyLangHints()
        } catch (t: Throwable) {
            fatal(t)
        }
    }

    /** Koi bhi startup error ho to crash dialog ki jagah error text dikhao. */
    private fun fatal(t: Throwable) {
        val text = android.util.Log.getStackTraceString(t)
        try { java.io.File(filesDir, "last_crash.txt").writeText(text) } catch (ignored: Exception) { }
        try {
            val tv = android.widget.TextView(this).apply {
                this.text = text
                textSize = 11f
                setPadding(24, 70, 24, 24)
                setTextIsSelectable(true)
                setTextColor(android.graphics.Color.parseColor("#3B2B52"))
            }
            val scroll = android.widget.ScrollView(this).apply { addView(tv) }
            setContentView(scroll)
        } catch (ignored: Exception) { }
    }

    private fun setup() {
        showLastCrash()
        if (auth.currentUser != null) { goMain(); return }
        b = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(b.root)
        try {
            WindowCompat.getInsetsController(window, b.root).isAppearanceLightStatusBars = false
        } catch (ignored: Exception) { }
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        b.tabs.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab?) {
                val login = b.tabs.selectedTabPosition == 0
                b.formLogin.visibility = if (login) android.view.View.VISIBLE else android.view.View.GONE
                b.formReg.visibility = if (login) android.view.View.GONE else android.view.View.VISIBLE
                b.formForgot.visibility = android.view.View.GONE
            }
            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
        })

        b.tvForgot.setOnClickListener {
            b.formLogin.visibility = android.view.View.GONE
            b.formForgot.visibility = android.view.View.VISIBLE
        }
        b.tvBackLogin.setOnClickListener {
            b.formForgot.visibility = android.view.View.GONE
            b.formLogin.visibility = android.view.View.VISIBLE
        }
        b.btnLogin.setOnClickListener { doLogin() }
        b.btnReg.setOnClickListener { doRegister() }
        b.btnReset.setOnClickListener { doReset() }
    }


    /** Login/Register ke saare hint bhasha ke hisaab se */
    private fun applyLangHints() {
        fun h(id: Int, hi: String, en: String) {
            try { findViewById<android.widget.EditText>(id).hint = Lang.t(hi, en) } catch (ignored: Exception) { }
        }
        h(R.id.etLiId, "मोबाइल नंबर / ईमेल", "Mobile number / Email")
        h(R.id.etLiPw, "पासवर्ड", "Password")
        h(R.id.etRegName, "पूरा नाम *", "Full name *")
        h(R.id.etRegMob, "मोबाइल नंबर *", "Mobile number *")
        h(R.id.etRegMail, "ईमेल *", "Email *")
        h(R.id.etRegAddr, "पूरा पता *", "Full address *")
        h(R.id.etRegCity, "शहर *", "City *")
        h(R.id.etRegDist, "जिला *", "District *")
        h(R.id.etRegState, "राज्य *", "State *")
        h(R.id.etRegPin, "PIN कोड *", "PIN code *")
        h(R.id.etRegPw, "पासवर्ड * (कम से कम 6 अक्षर)", "Password * (min 6 characters)")
        h(R.id.etFpMob, "पंजीकृत मोबाइल नंबर", "Registered mobile number")
        h(R.id.etFpMail, "पंजीकृत ईमेल", "Registered email")
        try {
            findViewById<android.widget.TextView>(R.id.tvVer).text =
                "Version " + com.shubh.vivah.BuildConfig.VERSION_NAME + " • Firebase"
        } catch (ignored: Exception) { }
    }

    private fun doLogin() {
        if (!Net.isOnline(this)) { Net.msgOffline(this); return }

        val id = b.etLiId.text?.toString()?.trim() ?: ""
        val pw = b.etLiPw.text?.toString() ?: ""
        if (id.isBlank() || pw.isBlank()) { toast("मोबाइल/ईमेल और पासवर्ड भरें"); return }
        if (id.contains("@")) { signIn(id, pw); return }
        db.collection("users").whereEqualTo("mobile", id).limit(1).get()
            .addOnSuccessListener { q ->
                val doc = q.documents.firstOrNull()
                if (doc == null) { toast("❌ यह मोबाइल रजिस्टर्ड नहीं है"); return@addOnSuccessListener }
                if (doc.getBoolean("blocked") == true) { toast("🚫 आपका खाता ब्लॉक किया गया है — admin से संपर्क करें"); return@addOnSuccessListener }
                signIn(doc.getString("email") ?: "", pw)
            }
            .addOnFailureListener { toast("⚠️ " + (it.message ?: "नेटवर्क त्रुटि")) }
    }

    private fun signIn(email: String, pw: String) {
        auth.signInWithEmailAndPassword(email.trim(), pw)
            .addOnSuccessListener {
                val uid = auth.currentUser?.uid ?: return@addOnSuccessListener
                db.collection("users").document(uid).get().addOnSuccessListener { d ->
                    if (d.getBoolean("blocked") == true) {
                        auth.signOut(); toast("🚫 आपका खाता ब्लॉक किया गया है")
                    } else goMain()
                }.addOnFailureListener { goMain() }
            }
            .addOnFailureListener { toast("❌ गलत ईमेल/पासवर्ड") }
    }

    private fun doRegister() {
        if (!Net.isOnline(this)) { Net.msgOffline(this); return }

        val name = b.etRegName.text?.toString()?.trim() ?: ""
        val mob = b.etRegMob.text?.toString()?.trim() ?: ""
        val mail = b.etRegMail.text?.toString()?.trim() ?: ""
        val addr = b.etRegAddr.text?.toString()?.trim() ?: ""
        val city = b.etRegCity.text?.toString()?.trim() ?: ""
        val dist = b.etRegDist.text?.toString()?.trim() ?: ""
        val state = b.etRegState.text?.toString()?.trim() ?: ""
        val pin = b.etRegPin.text?.toString()?.trim() ?: ""
        val pw = b.etRegPw.text?.toString() ?: ""
        val pw2 = b.etRegPw2.text?.toString() ?: ""

        if (listOf(name, mob, mail, addr, city, dist, state, pin).any { it.isBlank() }) { toast("सभी जानकारी भरें"); return }
        if (mob.length != 10) { toast("मोबाइल नंबर 10 अंकों का होना चाहिए"); return }
        if (pin.length != 6) { toast("PIN कोड 6 अंकों का होना चाहिए"); return }
        if (pw.length < 6) { toast("पासवर्ड कम से कम 6 अक्षर"); return }
        if (pw != pw2) { toast("दोनों पासवर्ड एक जैसे नहीं हैं"); return }

        auth.createUserWithEmailAndPassword(mail, pw)
            .addOnSuccessListener {
                val uid = auth.currentUser?.uid ?: return@addOnSuccessListener
                val u = User(id = uid, fullName = name, mobile = mob, email = mail, addr = addr,
                    city = city, dist = dist, state = state, pin = pin)
                db.collection("users").document(uid).set(u)
                db.collection("weddings").document(uid).set(Wedding())
                goMain()
            }
            .addOnFailureListener { toast("❌ " + (it.message ?: "रजिस्टर नहीं हो सका")) }
    }

    private fun doReset() {
        if (!Net.isOnline(this)) { Net.msgOffline(this); return }

        val mob = b.etFpMob.text?.toString()?.trim() ?: ""
        val mail = b.etFpMail.text?.toString()?.trim() ?: ""
        if (mob.isBlank() || mail.isBlank()) { toast("मोबाइल और ईमेल दोनों भरें"); return }
        db.collection("users").whereEqualTo("mobile", mob).whereEqualTo("email", mail).limit(1).get()
            .addOnSuccessListener { q ->
                if (q.isEmpty) { toast("❌ मोबाइल/ईमेल मेल नहीं खाते"); return@addOnSuccessListener }
                auth.sendPasswordResetEmail(mail)
                    .addOnSuccessListener { toast("✅ रीसेट लिंक ईमेल पर भेजा गया") }
                    .addOnFailureListener { toast("❌ " + (it.message ?: "नहीं भेजा जा सका")) }
            }
            .addOnFailureListener { toast("⚠️ " + (it.message ?: "नेटवर्क त्रुटि")) }
    }

    private fun showLastCrash() {
        try {
            val f = App.crashFile(application)
            if (!f.exists()) return
            val text = f.readText()
            f.delete()
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("⚠️ पिछली बार ऐप बंद हो गया था")
                .setMessage(text.take(1200))
                .setPositiveButton("ठीक है", null)
                .setNeutralButton("कॉपी") { _, _ ->
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", text))
                    toast("कॉपी हो गया")
                }
                .show()
        } catch (ignored: Exception) { }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
