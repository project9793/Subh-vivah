package com.shubh.vivah.data

/** All money maths for the wedding lives here — one source of truth. */
object Calc {

    data class Totals(
        val guestTotal: Int = 0, val guestSent: Int = 0, val guestPend: Int = 0,
        val guestConf: Int = 0, val guestNo: Int = 0,
        val peopleTotal: Int = 0, val peopleSent: Int = 0,
        val guestCame: Int = 0, val guestNotCame: Int = 0,
        val itemsCount: Int = 0, val itemsPend: Int = 0, val itemsTotal: Double = 0.0, val itemsPaid: Double = 0.0,
        val expTotal: Double = 0.0,
        val dwrTotal: Double = 0.0, val dwrPanv: Double = 0.0, val dwrAangan: Double = 0.0, val dwrDwar: Double = 0.0,
        val dwrDahej: Double = 0.0,
        val halwaiTotal: Double = 0.0, val halwaiAdv: Double = 0.0, val halwaiRem: Double = 0.0,
        val decorTotal: Double = 0.0, val decorAdv: Double = 0.0, val decorRem: Double = 0.0,
        val vehiCount: Int = 0, val vehiTotal: Double = 0.0, val vehiAdv: Double = 0.0, val vehiRem: Double = 0.0,
        val exp: Double = 0.0, val paid: Double = 0.0, val budget: Double = 0.0, val rem: Double = 0.0
    )

    private fun norm(t: String) = t.trim().lowercase().replace(Regex("\\s+"), " ")

    /** द्वारदारी / पाँवपूजा / आँगन ki entry se mel — naam + गाँव (गाँव khaali ho to sirf naam). */
    /** same naam + gaon wale mehmaan ek hi gine jayein (purane duplicate hatane ke liye) */
    fun uniqueGuests(list: List<Guest>): List<Guest> {
        val seen = HashMap<String, Guest>()
        list.forEach { g ->
            val k = norm(g.name) + "|" + norm(g.addr)
            val old = seen[k]
            if (old == null) seen[k] = g
            else if (old.mob.isBlank() && g.mob.isNotBlank()) seen[k] = g
        }
        return seen.values.toList()
    }

    /** har mehmaan ka ek hi serial number — dono screens par same dikhe */
    fun serialMap(guests: List<Guest>): Map<String, Int> {
        val uniq = uniqueGuests(guests)
        val maxNo = uniq.maxOfOrNull { it.no } ?: 0
        val out = HashMap<String, Int>()
        uniq.sortedBy { norm(it.name) }.forEachIndexed { i, g ->
            out[norm(g.name) + "|" + norm(g.addr)] = if (g.no > 0) g.no else maxNo + i + 1
        }
        return out
    }

    fun keyOf(name: String, vill: String) = norm(name) + "|" + norm(vill)

    fun cameNames(s: AppState): Set<String> {
        val out = HashSet<String>()
        s.guests.forEach { g ->
            val gn = norm(g.name); val gv = norm(g.addr)
            val hit = s.dwr.any { d ->
                norm(d.name) == gn && (gv.isBlank() || norm(d.village).isBlank() || norm(d.village) == gv)
            }
            if (hit) out.add(gn)
        }
        return out
    }

    fun of(s: AppState): Totals {
        val gs = uniqueGuests(s.guests)
        val itemsTotal = s.items.sumOf { it.total }
        val itemsPaid = s.items.filter { it.pay == "paid" }.sumOf { it.total }
        val expTotal = s.exps.sumOf { it.amt }
        val dwrTotal = s.dwr.sumOf { it.cash }
        val dwrPanv = s.dwr.filter { it.prog == "panv" }.sumOf { it.cash }
        val dwrDahej = s.dwr.filter { it.prog == "dahej" }.sumOf { it.cash }
        val dwrAangan = s.dwr.filter { it.prog == "aangan" }.sumOf { it.cash }
        val dwrDwar = s.dwr.filter { it.prog == "dwar" }.sumOf { it.cash }
        val hTotal = s.w.halwai.total
        val hAdv = s.w.halwai.adv
        val dTotal = s.w.decor.total
        val dAdv = s.w.decor.adv
        val vTotal = s.vehi.sumOf { it.rate }
        val vAdv = s.vehi.sumOf { it.adv }
        val exp = itemsTotal + expTotal + hTotal + dTotal + vTotal
        val paid = itemsPaid + expTotal + hAdv + dAdv + vAdv
        return Totals(
            guestTotal = gs.size,
            guestSent = gs.count { it.sent },
            guestPend = gs.count { !it.sent },
            peopleTotal = gs.sumOf { it.members.toInt() },
            peopleSent = gs.filter { it.sent }.sumOf { it.members.toInt() },
            guestCame = gs.count { g ->
                val gn = norm(g.name); val gv = norm(g.addr)
                s.dwr.any { d ->
                    norm(d.name) == gn && (gv.isBlank() || norm(d.village).isBlank() || norm(d.village) == gv)
                }
            },
            guestNotCame = gs.count { g ->
                if (!g.sent) false
                else {
                    val gn = norm(g.name); val gv = norm(g.addr)
                    s.dwr.none { d ->
                        norm(d.name) == gn && (gv.isBlank() || norm(d.village).isBlank() || norm(d.village) == gv)
                    }
                }
            },
            guestConf = gs.count { it.rsvp == "yes" || it.rsvp == "fam" },
            guestNo = gs.count { it.rsvp == "no" },
            itemsCount = s.items.size,
            itemsPend = s.items.count { it.status == "pend" },
            itemsTotal = itemsTotal,
            itemsPaid = itemsPaid,
            expTotal = expTotal,
            dwrTotal = dwrTotal, dwrPanv = dwrPanv, dwrAangan = dwrAangan, dwrDwar = dwrDwar, dwrDahej = dwrDahej,
            halwaiTotal = hTotal, halwaiAdv = hAdv, halwaiRem = hTotal - hAdv,
            decorTotal = dTotal, decorAdv = dAdv, decorRem = dTotal - dAdv,
            vehiCount = s.vehi.size, vehiTotal = vTotal, vehiAdv = vAdv, vehiRem = vTotal - vAdv,
            exp = exp, paid = paid, budget = s.w.budget, rem = s.w.budget - exp
        )
    }

    fun daysLeft(wdate: String): Int {
        if (wdate.isBlank()) return 0
        return try {
            val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            val d = fmt.parse(wdate) ?: return 0
            val diff = d.time - System.currentTimeMillis()
            Math.ceil(diff / 86_400_000.0).toInt()
        } catch (e: Exception) { 0 }
    }
}
