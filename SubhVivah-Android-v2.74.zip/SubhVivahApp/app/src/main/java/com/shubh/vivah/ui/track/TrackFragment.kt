package com.shubh.vivah.ui.track

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentTrackBinding
import com.shubh.vivah.databinding.ItemSettingBinding
import com.shubh.vivah.util.Share
import com.shubh.vivah.util.toast
import kotlin.random.Random

class TrackFragment : Fragment() {

    private var _b: FragmentTrackBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private var type = "BARAAT"
    private var lastLat: Double? = null
    private var lastLng: Double? = null

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) startLive()
        else requireContext().toast(Lang.t("GPS अनुमति ज़रूरी है — सेटिंग्स से दें", "GPS permission needed — enable in settings"))
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentTrackBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        type = arguments?.getString("type") ?: "BARAAT"
        b.btnBack.setOnClickListener { goBack() }
        b.tvTitle.text = if (type == "BARAAT") Lang.t("🚗 बारात Live Location","🚗 Baraat live location") else Lang.t("🏠 घरात Live Location","🏠 Gharat live location")
        b.tvOrganizer.text = Lang.t("मैं Organizer हूँ", "I am the Organizer")
        b.tvOrganizerSub.text = Lang.t(
            "GPS चालू करके अपनी Live Location साझा करें — मेहमान ID से आपको देख सकेंगे",
            "Turn on GPS and share your live location — guests can follow you with the ID")
        b.btnStart.text = Lang.t("▶️ Live Location शुरू करें", "▶️ Start Live Location")
        b.btnMyLoc.text = Lang.t("📍 मेरी वर्तमान लोकेशन", "📍 My current location")
        b.btnShareLoc.text = Lang.t("📤 मेरी लोकेशन शेयर करें", "📤 Share my location")
        b.tvGuestTitle.text = Lang.t("👀 मेहमान हूँ — ID से देखें", "👀 I am a guest — view by ID")
        b.btnView.text = Lang.t("देखें", "View")
        b.tvMyTracking.text = Lang.t("मेरी ट्रैकिंग", "My tracking")
        b.tvEmpty.text = Lang.t("अभी कोई ट्रैकिंग नहीं", "No tracking yet")
        // khulte hi apni location dikhao — baraat aur gharat dono me ek jaisa
        val autoShowLoc = true
        try {
            val ok = androidx.core.content.ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (autoShowLoc && ok) showMyLocation()
        } catch (ignored: Exception) { }
        // Tracking ID khaane ka hint bhi bhasha ke hisaab se
        try {
            val til = b.etId.parent?.parent
            if (til is com.google.android.material.textfield.TextInputLayout)
                til.hint = Lang.t("Tracking ID (जैसे VM7K3Q)", "Tracking ID (e.g. VM7K3Q)")
        } catch (ignored: Exception) { }

        b.btnStart.setOnClickListener {
            val fine = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            if (fine == PackageManager.PERMISSION_GRANTED) startLive()
            else perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        b.btnMyLoc.setOnClickListener { showMyLocation() }
        b.btnShareLoc.setOnClickListener { shareMyLocation() }
        b.tvMyLoc.setOnClickListener {
            val txt = b.tvMyLoc.text?.toString().orEmpty()
            if (txt.contains(",")) {
                val parts = txt.replace("📍", "").trim().split(",")
                if (parts.size == 2) {
                    val lat = parts[0].trim(); val lng = parts[1].trim()
                    startActivity(android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("geo:$lat,$lng?q=$lat,$lng")
                    ))
                }
            }
        }
        b.btnView.setOnClickListener {
            val id = b.etId.text?.toString()?.trim().orEmpty()
            if (id.isBlank()) { requireContext().toast(Lang.t("Tracking ID डालें", "Enter Tracking ID")); return@setOnClickListener }
            val args = Bundle().apply { putString("id", id) }
            findNavController().navigate(com.shubh.vivah.R.id.trackViewFragment, args)
        }

        watchTracks()
    }

    private fun newId(): String {
        val pfx = if (type == "BARAAT") "VM" else "GHR"
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return pfx + (1..5).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    }

    private fun startLive() {
        val id = newId()
        val w = vm.state.value.w
        val dest = if (type == "BARAAT") w.locs.bdest else w.locs.gharati
        TrackService.start(requireContext(), id, type, dest)
        requireContext().toast(Lang.t("▶️ Live शुरू — ID: ", "▶️ Live started — ID: ") + id)
    }

    /** GPS se apni abhi ki location dikhata hai (live share karne ki zaroorat nahi). */
    private fun showMyLocation() {
        val fine = androidx.core.content.ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (fine != PackageManager.PERMISSION_GRANTED) {
            perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            return
        }
        b.tvMyLoc.text = Lang.t("⏳ लोकेशन खोजी जा रही है…", "⏳ Finding location…")
        try {
            val fused = com.google.android.gms.location.LocationServices
                .getFusedLocationProviderClient(requireActivity())
            fused.getCurrentLocation(com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc ->
                    if (!isAdded) return@addOnSuccessListener
                    if (loc != null) {
                        lastLat = loc.latitude
                        lastLng = loc.longitude
                        b.tvMyLoc.text = "📍 " + String.format("%.5f", loc.latitude) + ", " + String.format("%.5f", loc.longitude)
                    } else {
                        b.tvMyLoc.text = Lang.t("❌ लोकेशन नहीं मिली — GPS चालू करें", "❌ Location not found — turn on GPS")
                    }
                }
                .addOnFailureListener {
                    if (isAdded) b.tvMyLoc.text = Lang.t("❌ लोकेशन नहीं मिली — GPS चालू करें", "❌ Location not found — turn on GPS")
                }
        } catch (e: Exception) {
            b.tvMyLoc.text = Lang.t("❌ लोकेशन नहीं मिली", "❌ Location not found")
        }
    }

    /** मेरी वर्तमान लोकेशन का Google Maps link WhatsApp se bhejta hai. */
    private fun shareMyLocation() {
        val lat = lastLat
        val lng = lastLng
        if (lat == null || lng == null) {
            // pehle location lo, phir share karo
            val fine = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            if (fine != PackageManager.PERMISSION_GRANTED) {
                perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                return
            }
            requireContext().toast(Lang.t("लोकेशन ले रहे हैं…", "Getting location…"))
            try {
                val fused = com.google.android.gms.location.LocationServices
                    .getFusedLocationProviderClient(requireActivity())
                fused.getCurrentLocation(com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, null)
                    .addOnSuccessListener { loc ->
                        if (loc != null) {
                            lastLat = loc.latitude
                            lastLng = loc.longitude
                            b.tvMyLoc.text = "📍 " + String.format("%.5f", loc.latitude) + ", " + String.format("%.5f", loc.longitude)
                                shareMyLocation()
                        } else if (isAdded) {
                            requireContext().toast(Lang.t("लोकेशन नहीं मिली — GPS चालू करें", "Location not found — turn on GPS"))
                        }
                    }
                    .addOnFailureListener { if (isAdded) requireContext().toast(Lang.t("लोकेशन नहीं मिली", "Location not found")) }
            } catch (e: Exception) {
                requireContext().toast(Lang.t("लोकेशन नहीं मिली", "Location not found"))
            }
            return
        }
        val link = "https://maps.google.com/?q=" + lat + "," + lng
        val msg = "📍 " + Lang.t("मेरी वर्तमान लोकेशन", "My current location") + "\n" + link +
            "\n— " + Lang.t("शुभ विवाह", "Shubh Vivah")
        Share.whatsapp(requireContext(), msg)
    }

    private fun watchTracks() {
        Repo.tracks().addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                if (!isAdded) return
                val uid = Repo.auth.currentUser?.uid
                b.box.removeAllViews()
                var n = 0
                snap.children.forEach { c ->
                    if (c.child("ownerUid").getValue(String::class.java) != uid) return@forEach
                    if (c.child("type").getValue(String::class.java) != type) return@forEach
                    n++
                    val id = c.key ?: return@forEach
                    val active = c.child("active").getValue(Boolean::class.java) == true
                    val dest = c.child("destName").getValue(String::class.java).orEmpty()
                    val lat = c.child("lat").getValue(Double::class.java)
                    val lng = c.child("lng").getValue(Double::class.java)
                    val ts = c.child("ts").getValue(Long::class.java) ?: 0L
                    b.box.addView(trackRow(id, active, dest, lat, lng, ts))
                }
                b.tvEmpty.visibility = if (n == 0) View.VISIBLE else View.GONE
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    /** Ek tracking card: ID, live pill, position, last update + शेयर / बंद-हटाएँ buttons. */
    private fun trackRow(
        id: String, active: Boolean, dest: String,
        lat: Double?, lng: Double?, ts: Long
    ): View {
        val ctx = requireContext()
        val dp = resources.displayMetrics.density

        val card = com.google.android.material.card.MaterialCardView(ctx).apply {
            radius = 18 * dp
            cardElevation = 1 * dp
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (8 * dp).toInt() }
        }
        val col = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding((14 * dp).toInt(), (12 * dp).toInt(), (14 * dp).toInt(), (10 * dp).toInt())
        }

        val head = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        head.addView(android.widget.TextView(ctx).apply {
            text = if (active) "🟢" else "⚪"
            textSize = 16f
            setPadding(0, 0, (8 * dp).toInt(), 0)
        })
        head.addView(android.widget.TextView(ctx).apply {
            text = "ID: " + id
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFF3B2B52.toInt())
            layoutParams = android.widget.LinearLayout.LayoutParams(0, -2, 1f)
        })
        head.addView(android.widget.TextView(ctx).apply {
            text = if (active) Lang.t("लाइव", "Live") else Lang.t("बंद", "Off")
            textSize = 11f
            setTextColor(if (active) 0xFF16A34A.toInt() else 0xFF8B7AA6.toInt())
        })
        col.addView(head)

        if (dest.isNotBlank()) {
            col.addView(android.widget.TextView(ctx).apply {
                text = "🎯 " + Lang.t("गंतव्य", "Destination") + ": " + dest
                textSize = 11.5f
                setTextColor(0xFF8B7AA6.toInt())
                setPadding(0, (4 * dp).toInt(), 0, 0)
            })
        }
        if (ts > 0L) {
            val age = ((System.currentTimeMillis() - ts) / 1000).coerceAtLeast(0)
            val coords = if (lat != null && lng != null)
                "📍 " + String.format("%.5f", lat) + ", " + String.format("%.5f", lng) + "  •  "
            else "📍 " + Lang.t("लोकेशन का इंतज़ार", "waiting for location") + "  •  "
            col.addView(android.widget.TextView(ctx).apply {
                text = coords + Lang.t("अंतिम अपडेट", "Updated") + " " + age + "s"
                textSize = 11.5f
                setTextColor(0xFF7C3AED.toInt())
                setPadding(0, (2 * dp).toInt(), 0, 0)
            })
        }

        val actions = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.END
            setPadding(0, (8 * dp).toInt(), 0, 0)
        }
        fun btn(label: String, color: Int, bg: Int, onClick: () -> Unit) {
            actions.addView(com.google.android.material.button.MaterialButton(ctx).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                minWidth = 0
                setPadding((10 * dp).toInt(), 0, (10 * dp).toInt(), 0)
                setTextColor(color)
                backgroundTintList = android.content.res.ColorStateList.valueOf(bg)
                cornerRadius = (14 * dp).toInt()
                layoutParams = android.widget.LinearLayout.LayoutParams(-2, (36 * dp).toInt())
                    .apply { marginStart = (6 * dp).toInt() }
                setOnClickListener { onClick() }
            })
        }

        if (lat != null && lng != null) {
            btn(Lang.t("🧭 मैप", "🧭 Map"), 0xFF7C3AED.toInt(), 0xFFEDE9FE.toInt()) {
                startActivity(android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng)
                ))
            }
        }
        btn(Lang.t("🟢 शेयर", "🟢 Share"), 0xFF15803D.toInt(), 0xFFDCFCE8.toInt()) {
            Share.whatsapp(
                requireContext(),
                "📍 " + (if (type == "BARAAT") Lang.t("बारात", "Baraat") else Lang.t("घरात", "Gharat")) +
                    " Live Location\nID: " + id + Lang.t("\nशुभ विवाह ऐप → Live → ID से देखें", "\nShubh Vivah app → Live → view by ID")
            )
        }
        if (active) {
            btn(Lang.t("⏹ बंद", "⏹ Stop"), 0xFFE11D48.toInt(), 0xFFFFE4E6.toInt()) {
                TrackService.stop(requireContext(), id)
                requireContext().toast(Lang.t("⏹ बंद कर दिया", "⏹ Stopped"))
            }
        } else {
            btn(Lang.t("🗑 हटाएँ", "🗑 Remove"), 0xFFE11D48.toInt(), 0xFFFFE4E6.toInt()) {
                Repo.tracks().child(id).removeValue()
                requireContext().toast(Lang.t("🗑 हटा दिया", "🗑 Removed"))
            }
        }
        col.addView(actions)

        card.addView(col)
        return card
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
