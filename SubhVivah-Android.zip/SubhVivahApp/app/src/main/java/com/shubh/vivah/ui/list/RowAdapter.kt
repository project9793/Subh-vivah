package com.shubh.vivah.ui.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.shubh.vivah.databinding.ItemRowBinding

data class Row(
    val icon: String,
    val title: String,
    val chip: String = "",
    val meta: String = "",
    val showWa: Boolean = false,
    val showPay: Boolean = false
)

class RowAdapter(
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit,
    private val onWa: (Int) -> Unit = {},
    private val onChip: (Int) -> Unit = {},
    private val onPay: (Int) -> Unit = {}
) : RecyclerView.Adapter<RowAdapter.VH>() {

    private val items = ArrayList<Row>()

    fun setItems(list: List<Row>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemRowBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        h.b.tvIcon.text = r.icon
        h.b.tvTitle.text = r.title
        h.b.tvChip.text = r.chip
        h.b.tvChip.visibility = if (r.chip.isBlank()) View.GONE else View.VISIBLE
        h.b.tvMeta.text = r.meta
        h.b.tvMeta.visibility = if (r.meta.isBlank()) View.GONE else View.VISIBLE
        h.b.btnWa.visibility = if (r.showWa) View.VISIBLE else View.GONE
        h.b.btnPay.visibility = if (r.showPay) View.VISIBLE else View.GONE
        h.b.btnPay.setOnClickListener { onPay(h.bindingAdapterPosition) }
        h.b.btnEdit.setOnClickListener { onEdit(h.bindingAdapterPosition) }
        h.b.btnDel.setOnClickListener { onDelete(h.bindingAdapterPosition) }
        h.b.btnWa.setOnClickListener { onWa(h.bindingAdapterPosition) }
        h.b.tvChip.setOnClickListener { onChip(h.bindingAdapterPosition) }
    }
}
