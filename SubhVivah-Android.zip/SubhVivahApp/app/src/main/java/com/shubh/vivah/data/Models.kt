package com.shubh.vivah.data

import com.google.firebase.firestore.Exclude

data class User(
    val id: String = "",
    val fullName: String = "",
    val mobile: String = "",
    val email: String = "",
    val addr: String = "",
    val city: String = "",
    val dist: String = "",
    val state: String = "",
    val pin: String = "",
    val admin: Boolean = false,
    val blocked: Boolean = false,
    val lang: String = "both",
    val fcmToken: String = ""
)

data class Guest(
    val id: String = "",
    val name: String = "",
    val mob: String = "",
    val members: Long = 1,
    val side: String = "var",
    val addr: String = "",
    val rsvp: String = "",
    val sent: Boolean = false
)

data class Item(
    val id: String = "",
    val name: String = "",
    val qty: Double = 0.0,
    val rate: Double = 0.0,
    val vendor: String = "",
    val status: String = "pend",
    val pay: String = "pend"
) {
    @get:Exclude val total: Double get() = qty * rate
}

data class Expense(
    val id: String = "",
    val name: String = "",
    val amt: Double = 0.0,
    val date: String = "",
    val notes: String = ""
)

data class Dwardari(
    val id: String = "",
    val name: String = "",
    val village: String = "",
    val prog: String = "panv",
    val cash: Double = 0.0,
    val gift: String = ""
)

data class Vehicle(
    val id: String = "",
    val name: String = "",
    val driver: String = "",
    val mob: String = "",
    val rate: Double = 0.0,
    val adv: Double = 0.0,
    val from: String = "",
    val to: String = ""
)

data class FamilyMember(
    val id: String = "",
    val side: String = "var",
    val name: String = "",
    val rel: String = "",
    val mob: String = "",
    val addr: String = ""
)

data class VendorItem(
    val id: String = "",
    val name: String = "",
    val qty: Double = 1.0,
    val rate: Double = 0.0
) {
    @get:Exclude val total: Double get() = qty * rate
}

data class Vendor(
    val name: String = "",
    val mob: String = "",
    val adv: Double = 0.0,
    val items: List<VendorItem> = emptyList()
) {
    @get:Exclude val total: Double get() = items.sumOf { it.total }
    @get:Exclude val rem: Double get() = total - adv
}

data class EvEvent(
    val name: String = "",
    val icon: String = "",
    val date: String = "",
    val time: String = "",
    val venue: String = "",
    val addr: String = "",
    val desc: String = ""
)

data class Locs(
    val venue: String = "",
    val bride: String = "",
    val groom: String = "",
    val bstart: String = "",
    val bdest: String = "",
    val gharati: String = ""
)

data class CardData(
    val tpl: Int = 4,
    val lang: String = "hi",
    val groom: String = "",
    val bride: String = "",
    val groomPre: String = "चि.",
    val bridePre: String = "सौ.कां.",
    val groomF: String = "",
    val brideF: String = "",
    val groomGF: String = "",
    val brideGF: String = "",
    val groomVill: String = "",
    val groomDist: String = "",
    val brideVill: String = "",
    val brideDist: String = "",
    val fam: String = "",
    val sender: String = "",
    val village: String = "",
    val dist: String = "",
    val contact: String = "",
    val date: String = "",
    val time: String = "",
    val venue: String = "",
    val addr: String = "",
    val evStart: String = "2",
    val msg: String = "आपका शुभ हाथ अवश्य दें।",
    val listShubh: String = "",
    val listNihati: String = "",
    val listDarshan: String = "",
    val listSwagat: String = "",
    val listVinit: String = ""
)

data class Wedding(
    val groom: String = "",
    val bride: String = "",
    val wdate: String = "",
    val budget: Double = 0.0,
    val halwai: Vendor = Vendor(),
    val decor: Vendor = Vendor(),
    val locs: Locs = Locs(),
    val card: CardData = CardData(),
    val cardCount: Long = 0,
    val events: List<EvEvent> = Companion.defaultEvents()
) {
    companion object {
        val DEF = listOf(
            "हल्दी" to "💛", "मेहंदी" to "🌿", "तिलक" to "📿", "संगीत" to "🎵",
            "बारात" to "🐎", "जयमाला" to "💐", "विवाह" to "🔥", "विदाई" to "😢",
            "रिसेप्शन" to "🥂"
        )
        fun defaultEvents(): List<EvEvent> = DEF.map { EvEvent(name = it.first, icon = it.second) }
    }
}

data class AppState(
    val user: User = User(),
    val w: Wedding = Wedding(),
    val guests: List<Guest> = emptyList(),
    val items: List<Item> = emptyList(),
    val exps: List<Expense> = emptyList(),
    val dwr: List<Dwardari> = emptyList(),
    val vehi: List<Vehicle> = emptyList(),
    val family: List<FamilyMember> = emptyList()
)
