package com.shubh.vivah.ui.family

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.R
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.FamilyMember
import com.shubh.vivah.databinding.FragmentListPageBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.ui.list.Row
import com.shubh.vivah.ui.list.RowAdapter
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class FamilyFragment : Fragment() {

    private var _b: FragmentListPageBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var side = "var"
    private var data: List<FamilyMember> = emptyList()

    private val rels = listOf("पिता", "माता", "भाई", "बहन", "दादा", "दादी", "चाचा", "चाची",
        "मामा", "मामी", "फूफा", "बुआ", "जीजा", "दीदी", "अन्य")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentListPageBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        side = arguments?.getString("side") ?: "var"
        b.btnBack.setOnClickListener { goBack() }
        b.fab.setOnClickListener { edit(null) }
        b.btnExtra.visibility = View.GONE

        adapter = RowAdapter(
            onEdit = { i -> edit(data.getOrNull(i)) },
            onDelete = { i -> data.getOrNull(i)?.let { m ->
                requireContext().confirm("हटाएँ?", m.name) { vm.delFamily(m.id) } } }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        data = s.family.filter { it.side == side }
        b.tvTitle.text = if (side == "var") Lang.t("👨‍👩‍👦 वर पक्ष", "👨‍👩‍👦 Groom side") else Lang.t("👰 कन्या पक्ष", "👰 Bride side")
        b.t1.text = data.size.toString(); b.k1.text = "कुल सदस्य"
        b.t2.text = data.count { it.rel == "भाई" || it.rel == "बहन" }.toString(); b.k2.text = "भाई-बहन"
        b.t3.text = data.count { it.rel == "पिता" || it.rel == "माता" }.toString(); b.k3.text = "माता-पिता"
        b.t4.visibility = View.GONE; b.k4.visibility = View.GONE
        adapter.setItems(data.map { m ->
            Row(
                icon = when {
                    m.rel == "पिता" -> "👨"; m.rel == "माता" -> "👩"
                    m.rel == "भाई" -> "👦"; m.rel == "बहन" -> "👧"; else -> "🧑"
                },
                title = m.name, chip = m.rel,
                meta = "📱 " + m.mob.ifBlank { "—" } + (if (m.addr.isNotBlank()) "\n📍 " + m.addr else "")
            )
        })
    }

    private fun edit(m: FamilyMember?) {
        val f = listOf(
            Field("name", "नाम *"),
            Field("rel", "रिश्ता", FType.SELECT, rels.map { it to it }),
            Field("mob", "मोबाइल"),
            Field("addr", "पता", FType.MULTI)
        )
        FormDialog.show(requireContext(), if (side == "var") "वर पक्ष सदस्य" else "कन्या पक्ष सदस्य", f,
            mapOf("name" to (m?.name ?: ""), "rel" to (m?.rel ?: "अन्य"),
                "mob" to (m?.mob ?: ""), "addr" to (m?.addr ?: ""))
        ) { mm ->
            val n = FormDialog.str(mm, "name")
            if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
            vm.saveFamily(FamilyMember(m?.id ?: "", side, n, FormDialog.str(mm, "rel"),
                FormDialog.str(mm, "mob"), FormDialog.str(mm, "addr")))
            requireContext().toast("✅ सेव हो गया")
        }
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
