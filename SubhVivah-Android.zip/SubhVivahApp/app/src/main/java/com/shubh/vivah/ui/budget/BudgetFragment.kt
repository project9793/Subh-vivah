package com.shubh.vivah.ui.budget

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Calc
import com.shubh.vivah.databinding.FragmentBudgetBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.util.money
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class BudgetFragment : Fragment() {

    private var _b: FragmentBudgetBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentBudgetBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { findNavController().navigateUp() }
        b.btnBudget.setOnClickListener {
            val w = vm.state.value.w
            FormDialog.show(requireContext(), "💼 बजट बदलें",
                listOf(Field("budget", "कुल बजट (₹)", FType.NUM)),
                mapOf("budget" to w.budget.toString())
            ) { m ->
                vm.saveWedding(w.copy(budget = FormDialog.num(m, "budget")))
                requireContext().toast("✅ बजट सेव हो गया")
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        b.chart.setBars(listOf(
            BarChartView.Bar("सामान", c.itemsTotal),
            BarChartView.Bar("खर्च", c.expTotal),
            BarChartView.Bar("हलवाई", c.halwaiTotal),
            BarChartView.Bar("सजावट", c.decorTotal),
            BarChartView.Bar("वाहन", c.vehiTotal)
        ))
        b.tvBudget.text = c.budget.money()
        b.tvExp.text = c.exp.money()
        b.tvPaid.text = c.paid.money()
        b.tvRem.text = Math.abs(c.rem).money() + if (c.rem < 0) " (बजट पार)" else ""
        b.tvRem.setTextColor(
            if (c.rem < 0) 0xFFE11D48.toInt() else 0xFFC99A2E.toInt()
        )
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
