package com.shubh.vivah.util

import android.content.Context
import android.text.TextUtils
import android.view.View
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Double.money(): String {
    val nf = NumberFormat.getInstance(Locale("en", "IN"))
    nf.maximumFractionDigits = 0
    return "₹" + nf.format(this)
}

fun Double.moneyShort(): String =
    if (this >= 100000) String.format(Locale.US, "%.1fL", this / 100000.0) else money()

fun String.dmy(): String {
    if (this.isBlank()) return "—"
    return try {
        val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outFmt = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        outFmt.format(inFmt.parse(this) ?: Date())
    } catch (e: Exception) { this }
}

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

fun Context.confirm(title: String, msg: String, onYes: () -> Unit) {
    MaterialAlertDialogBuilder(this)
        .setTitle(title)
        .setMessage(msg)
        .setNegativeButton("रद्द करें", null)
        .setPositiveButton("हाँ") { _, _ -> onYes() }
        .show()
}

fun View.showIf(cond: Boolean) { visibility = if (cond) View.VISIBLE else View.GONE }

fun String.orDash(): String = if (TextUtils.isEmpty(this)) "—" else this

fun Long.toRupees(): String = this.toDouble().money()
