package com.shubh.vivah.ui

import android.app.DatePickerDialog
import android.content.Context
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

enum class FType { TEXT, NUM, DATE, SELECT, MULTI }

data class Field(
    val key: String,
    val label: String,
    val type: FType = FType.TEXT,
    val options: List<Pair<String, String>> = emptyList()
)

/** One programmatic form used by every add/edit screen in the app. */
object FormDialog {

    fun show(
        ctx: Context,
        title: String,
        fields: List<Field>,
        values: Map<String, String> = emptyMap(),
        onSave: (Map<String, String>) -> Unit
    ) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 8)
        }
        val scroll = ScrollView(ctx).apply {
            addView(root)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val texts = HashMap<String, TextInputEditText>()
        val selects = HashMap<String, String>()

        fields.forEach { f ->
            val til = TextInputLayout(ctx).apply {
                hint = f.label
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 18 }
            }
            when (f.type) {
                FType.SELECT -> {
                    val act = MaterialAutoCompleteTextView(ctx).apply {
                        inputType = InputType.TYPE_NULL
                        setAdapter(ArrayAdapter(ctx, android.R.layout.simple_list_item_1, f.options.map { it.second }))
                        val cur = values[f.key]
                        val label = f.options.firstOrNull { it.first == cur }?.second ?: f.options.firstOrNull()?.second ?: ""
                        setText(label, false)
                        selects[f.key] = cur ?: f.options.firstOrNull()?.first ?: ""
                        setOnItemClickListener { _, _, pos, _ -> selects[f.key] = f.options[pos].first }
                    }
                    til.addView(act)
                }
                FType.DATE -> {
                    val et = TextInputEditText(ctx).apply {
                        isFocusable = false
                        isClickable = true
                        setText(values[f.key] ?: "")
                        hint = "yyyy-mm-dd"
                        setOnClickListener {
                            val c = Calendar.getInstance()
                            DatePickerDialog(ctx, { _, y, m, d ->
                                val s = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                                setText(s)
                            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                        }
                    }
                    til.addView(et)
                    texts[f.key] = et
                }
                else -> {
                    val et = TextInputEditText(ctx).apply {
                        setText(values[f.key] ?: "")
                        if (f.type == FType.NUM) inputType =
                            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        if (f.type == FType.MULTI) {
                            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                            minLines = 3
                            gravity = android.view.Gravity.TOP
                        }
                    }
                    til.addView(et)
                    texts[f.key] = et
                }
            }
            root.addView(til)
        }

        MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(scroll)
            .setNegativeButton("रद्द करें", null)
            .setPositiveButton("सेव करें") { _, _ ->
                val out = HashMap<String, String>()
                fields.forEach { f ->
                    out[f.key] = when (f.type) {
                        FType.SELECT -> selects[f.key] ?: ""
                        else -> texts[f.key]?.text?.toString()?.trim() ?: ""
                    }
                }
                onSave(out)
            }
            .show()
    }

    fun num(m: Map<String, String>, k: String): Double = m[k]?.toDoubleOrNull() ?: 0.0
    fun long(m: Map<String, String>, k: String): Long = m[k]?.toLongOrNull() ?: 0L
    fun str(m: Map<String, String>, k: String): String = m[k] ?: ""
}
