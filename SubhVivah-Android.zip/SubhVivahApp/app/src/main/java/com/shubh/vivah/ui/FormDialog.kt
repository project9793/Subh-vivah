package com.shubh.vivah.ui

import android.app.DatePickerDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.shubh.vivah.R
import java.util.Calendar

enum class FType { TEXT, NUM, DATE, SELECT, MULTI }

data class Field(
    val key: String,
    val label: String,
    val type: FType = FType.TEXT,
    val options: List<Pair<String, String>> = emptyList()
)

/** One styled bottom-sheet form used by every add/edit screen in the app. */
object FormDialog {

    fun show(
        ctx: Context,
        title: String,
        fields: List<Field>,
        values: Map<String, String> = emptyMap(),
        fullHeight: Boolean = false,
        onSave: (Map<String, String>) -> Unit
    ) {
        try {
            showInternal(ctx, title, fields, values, fullHeight, onSave)
        } catch (t: Throwable) {
            showError(ctx, t)
        }
    }

    private fun showError(ctx: Context, t: Throwable) {
        try {
            val text = android.util.Log.getStackTraceString(t)
            MaterialAlertDialogBuilder(ctx)
                .setTitle("⚠️ फ़ॉर्म खुल नहीं सका")
                .setMessage(text.take(1500))
                .setPositiveButton("ठीक है", null)
                .show()
        } catch (ignored: Throwable) { }
    }

    private fun showInternal(
        ctx: Context,
        title: String,
        fields: List<Field>,
        values: Map<String, String>,
        fullHeight: Boolean,
        onSave: (Map<String, String>) -> Unit
    ) {
        val layoutId = if (fullHeight) R.layout.sheet_form_tall else R.layout.sheet_form
        val root = LayoutInflater.from(ctx).inflate(layoutId, null)
        val tvIcon = root.findViewById<TextView>(R.id.tvSheetIcon)
        val tvTitleV = root.findViewById<TextView>(R.id.tvSheetTitle)
        val btnClose = root.findViewById<TextView>(R.id.btnSheetClose)
        val formBox = root.findViewById<android.widget.LinearLayout>(R.id.formBox)
        val btnCancel = root.findViewById<MaterialButton>(R.id.btnSheetCancel)
        val btnSave = root.findViewById<MaterialButton>(R.id.btnSheetSave)
        val sheet = android.app.Dialog(ctx)
        sheet.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        sheet.setContentView(root)
        sheet.window?.let { win ->
            win.setBackgroundDrawableResource(android.R.color.transparent)
            // form lamba hone par bhi Save/रद्द buttons screen par dikhein
            val h = if (fullHeight) (ctx.resources.displayMetrics.heightPixels * 0.88f).toInt()
                    else android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            win.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, h)
            win.setGravity(android.view.Gravity.BOTTOM)
            win.setDimAmount(0.5f)
            win.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }

        val parts = title.trim().split(" ", limit = 2)
        val firstIsEmoji = parts.size == 2 && parts[0].codePoints().anyMatch { it > 0x2000 }
        tvIcon.text = if (firstIsEmoji) parts[0] else "📝"
        tvTitleV.text = if (firstIsEmoji) parts[1] else title
        btnClose.setOnClickListener { sheet.dismiss() }
        btnCancel.setOnClickListener { sheet.dismiss() }

        val texts = HashMap<String, TextInputEditText>()
        val selects = HashMap<String, String>()

        fields.forEach { f ->
            val til = TextInputLayout(ctx).apply {
                hint = f.label
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 14 }
            }
            when (f.type) {
                FType.SELECT -> {
                    val cur = values[f.key]
                    selects[f.key] = cur ?: f.options.firstOrNull()?.first ?: ""
                    val et = TextInputEditText(ctx).apply {
                        isFocusable = false
                        isClickable = true
                        inputType = InputType.TYPE_NULL
                        setText(f.options.firstOrNull { it.first == selects[f.key] }?.second ?: "")
                    }
                    // NOTE: END_ICON_DROPDOWN_MENU sirf AutoCompleteTextView ke saath chalta hai,
                    // isliye custom end icon use kar rahe hain (dialog khud khulta hai).
                    til.setEndIconMode(TextInputLayout.END_ICON_CUSTOM)
                    til.setEndIconDrawable(android.R.drawable.arrow_down_float)
                    val pick: () -> Unit = {
                        val labels = f.options.map { it.second }.toTypedArray()
                        val idx = f.options.indexOfFirst { it.first == selects[f.key] }
                        MaterialAlertDialogBuilder(ctx)
                            .setTitle(f.label)
                            .setSingleChoiceItems(labels, idx) { d, which ->
                                selects[f.key] = f.options[which].first
                                et.setText(f.options[which].second)
                                d.dismiss()
                            }
                            .show()
                    }
                    et.setOnClickListener { pick() }
                    til.setEndIconOnClickListener { pick() }
                    til.addView(et)
                }
                FType.DATE -> {
                    val et = TextInputEditText(ctx).apply {
                        isFocusable = false
                        isClickable = true
                        setText(values[f.key] ?: "")
                        hint = "yyyy-mm-dd"
                        setOnClickListener {
                            val c = Calendar.getInstance()
                            DatePickerDialog(ctx, { _, y, mo, d ->
                                setText(String.format(java.util.Locale.US, "%04d-%02d-%02d", y, mo + 1, d))
                            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                        }
                    }
                    til.addView(et)
                    texts[f.key] = et
                }
                else -> {
                    val shown = values[f.key].let { if (f.type == FType.NUM && (it == "0.0" || it == null)) "" else it }
                    val et = TextInputEditText(ctx).apply {
                        setText(shown)
                        if (f.type == FType.NUM) inputType =
                            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        if (f.type == FType.MULTI) {
                            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                            minLines = 3
                            gravity = android.view.Gravity.TOP
                        }
                    }
                    til.addView(et)
                    texts[f.key] = et
                }
            }
            formBox.addView(til)
        }

        btnSave.setOnClickListener {
            val out = HashMap<String, String>()
            fields.forEach { f ->
                out[f.key] = when (f.type) {
                    FType.SELECT -> selects[f.key] ?: ""
                    else -> texts[f.key]?.text?.toString()?.trim() ?: ""
                }
            }
            sheet.dismiss()
            onSave(out)
        }
        sheet.show()
    }

    fun num(m: Map<String, String>, k: String): Double = m[k]?.toDoubleOrNull() ?: 0.0
    fun long(m: Map<String, String>, k: String): Long = m[k]?.toLongOrNull() ?: 0L
    fun str(m: Map<String, String>, k: String): String = m[k] ?: ""

    /** small helper for the coloured category chips on the द्वारदारी screen */
    fun chipColor(hex: String): ColorStateList = ColorStateList.valueOf(Color.parseColor(hex))
}
