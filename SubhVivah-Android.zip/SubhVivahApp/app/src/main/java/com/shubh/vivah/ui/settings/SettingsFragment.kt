package com.shubh.vivah.ui.settings

import com.shubh.vivah.util.*

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.User
import com.shubh.vivah.databinding.FragmentSettingsBinding
import com.shubh.vivah.databinding.ItemSettingBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class SettingsFragment : Fragment() {

    private var _b: FragmentSettingsBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSettingsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun row(icon: String, title: String, sub: String, arrow: String = "→", click: () -> Unit) {
        val r = ItemSettingBinding.inflate(layoutInflater, b.box, false)
        r.tvIcon.text = icon
        r.tvTitle.text = title
        r.tvSub.text = sub
        r.tvArrow.text = arrow
        r.root.setOnClickListener { click() }
        b.box.addView(r.root)
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        b.box.removeAllViews()
        val u = s.user

        row("👤", u.fullName.ifBlank { "प्रोफ़ाइल" }, "${u.mobile} • ${u.email}", "✏️") { editProfile(u) }
        row("💍", "विवाह डिटेल",
            "${s.w.groom.ifBlank { "—" }} ❤ ${s.w.bride.ifBlank { "—" }} • ${s.w.wdate.dmy()}", "✏️") { editWedding(s) }
        row("🔐", "पासवर्ड बदलें", "Change Password") { changePw() }
        row("🌐", "भाषा / Language", langLabel(u.lang)) { pickLang(u) }
        row("📖", "उपयोग गाइड", "User Guide") { findNavController().navigate(com.shubh.vivah.R.id.guideFragment) }
        if (u.isAdmin) row("🛡️", "Admin Panel", "यूज़र्स व आँकड़े देखें") {
            findNavController().navigate(com.shubh.vivah.R.id.adminFragment)
        }
        row("☁️", "Firebase", if (Repo.auth.currentUser != null) "कनेक्टेड • ${Repo.auth.currentUser?.email}" else "कनेक्ट नहीं") { requireContext().toast("डेटा क्लाउड में सिंक हो रहा है") }
        row("🚪", "लॉगआउट", "Logout") {
            requireContext().confirm("लॉगआउट?", "आप लॉगआउट हो जाएँगे।") { logout() }
        }
        b.tvVersion.text = "Version 1.0 • Firebase"
    }

    private fun langLabel(l: String) = when (l) {
        "hi" -> "हिंदी"; "en" -> "English"; else -> "हिंदी + English"
    }

    private fun editProfile(u: User) {
        val f = listOf(
            Field("fullName", "पूरा नाम *"), Field("mobile", "मोबाइल नंबर *"),
            Field("email", "ईमेल *"), Field("addr", "पूरा पता", FType.MULTI),
            Field("city", "शहर"), Field("dist", "जिला"), Field("state", "राज्य"), Field("pin", "PIN कोड")
        )
        FormDialog.show(requireContext(), "👤 प्रोफ़ाइल", f, mapOf(
            "fullName" to u.fullName, "mobile" to u.mobile, "email" to u.email, "addr" to u.addr,
            "city" to u.city, "dist" to u.dist, "state" to u.state, "pin" to u.pin
        )) { m ->
            vm.saveProfile(u.copy(
                fullName = FormDialog.str(m, "fullName"), mobile = FormDialog.str(m, "mobile"),
                email = FormDialog.str(m, "email"), addr = FormDialog.str(m, "addr"),
                city = FormDialog.str(m, "city"), dist = FormDialog.str(m, "dist"),
                state = FormDialog.str(m, "state"), pin = FormDialog.str(m, "pin")
            ))
            requireContext().toast("✅ प्रोफ़ाइल सेव हो गई")
        }
    }

    private fun editWedding(s: AppState) {
        val f = listOf(
            Field("groom", "वर (दूल्हा) का नाम"), Field("bride", "कन्या (दुल्हन) का नाम"),
            Field("wdate", "विवाह तारीख", FType.DATE), Field("budget", "कुल बजट (₹)", FType.NUM)
        )
        FormDialog.show(requireContext(), "💍 विवाह डिटेल", f, mapOf(
            "groom" to s.w.groom, "bride" to s.w.bride, "wdate" to s.w.wdate, "budget" to s.w.budget.toString()
        )) { m ->
            vm.saveWedding(s.w.copy(
                groom = FormDialog.str(m, "groom"), bride = FormDialog.str(m, "bride"),
                wdate = FormDialog.str(m, "wdate"), budget = FormDialog.num(m, "budget")
            ))
            requireContext().toast("✅ सेव हो गया")
        }
    }

    private fun changePw() {
        FormDialog.show(requireContext(), "🔐 पासवर्ड बदलें",
            listOf(Field("pw", "नया पासवर्ड (कम से कम 6 अक्षर)"))
        ) { m ->
            val pw = FormDialog.str(m, "pw")
            if (pw.length < 6) { requireContext().toast("पासवर्ड कम से कम 6 अक्षर"); return@show }
            val user = Repo.auth.currentUser
            if (user == null) { requireContext().toast("लॉगिन नहीं है"); return@show }
            user.updatePassword(pw)
                .addOnSuccessListener { requireContext().toast("✅ पासवर्ड बदल गया") }
                .addOnFailureListener { requireContext().toast("पहले लॉगआउट करके दोबारा लॉगिन करें, फिर बदलें") }
        }
    }

    private fun pickLang(u: User) {
        val opts = listOf("hi" to "हिंदी", "en" to "English", "both" to "हिंदी + English")
        FormDialog.show(requireContext(), "🌐 भाषा", listOf(Field("lang", "भाषा चुनें", FType.SELECT, opts)),
            mapOf("lang" to u.lang)
        ) { m ->
            val l = FormDialog.str(m, "lang")
            vm.saveProfile(u.copy(lang = l))
            val tag = if (l == "en") "en" else "hi"
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
            requireContext().toast("✅ भाषा बदल गई")
        }
    }

    private fun logout() {
        Repo.auth.signOut()
        startActivity(Intent(requireContext(), AuthActivity::class.java))
        requireActivity().finish()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
