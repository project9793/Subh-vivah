package com.shubh.vivah.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object Repo {
    val auth: FirebaseAuth = FirebaseAuth.getInstance()
    val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    // google-services.json me firebase_url na ho to getInstance() crash karta hai — fallback URL.
    val rtdb: FirebaseDatabase by lazy {
        try {
            FirebaseDatabase.getInstance()
        } catch (e: Exception) {
            FirebaseDatabase.getInstance("https://subh-vivah-a3875-default-rtdb.firebaseio.com")
        }
    }

    fun userDoc(uid: String): DocumentReference = db.collection("users").document(uid)
    fun weddingDoc(uid: String): DocumentReference = db.collection("weddings").document(uid)
    fun col(uid: String, name: String): CollectionReference = weddingDoc(uid).collection(name)
    fun tracks(): DatabaseReference = rtdb.reference.child("tracks")

    fun userFlow(uid: String): Flow<User> = callbackFlow {
        val reg = userDoc(uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                val u = try {
                    val parsed = snap.toObject(User::class.java)?.copy(id = uid) ?: User(id = uid)
                    // dono field naam support karo: "admin" aur purana "isAdmin"
                    val legacyAdmin = snap.getBoolean("isAdmin") ?: false
                    if (legacyAdmin && !parsed.admin) parsed.copy(admin = true) else parsed
                } catch (e: Exception) { User(id = uid) }
                trySend(u)
            }
        }
        awaitClose { reg.remove() }
    }

    private val lastGood = HashMap<String, Wedding>()

    fun weddingFlow(uid: String): Flow<Wedding> = callbackFlow {
        val reg = weddingDoc(uid).addSnapshotListener { snap, _ ->
            if (snap != null) {
                val w = try {
                    snap.toObject(Wedding::class.java) ?: Wedding()
                } catch (e: Exception) {
                    // purana document parse na ho to khaali wedding na dikhao — aakhri accha data rakho
                    lastGood[uid] ?: Wedding()
                }
                trySend(w)
            }
        }
        awaitClose { reg.remove() }
    }

    /**
     * Har record ke andar uska asli Firestore document id bhar kar dete hain.
     * Isse edit "update" karta hai (naya record nahi banta) aur delete bhi kaam karta hai —
     * purane records me id khaali thi, isi wajah se duplicate ban rahe the.
     */
    fun <T> listFlow(uid: String, name: String, clazz: Class<T>): Flow<List<T>> = callbackFlow {
        val reg = col(uid, name).addSnapshotListener { snap, _ ->
            if (snap != null) {
                val list: List<T> = try {
                    snap.documents.mapNotNull { d ->
                        when {
                            clazz == Guest::class.java -> d.toObject(Guest::class.java)?.copy(id = d.id)
                            clazz == Item::class.java -> d.toObject(Item::class.java)?.copy(id = d.id)
                            clazz == Expense::class.java -> d.toObject(Expense::class.java)?.copy(id = d.id)
                            clazz == Dwardari::class.java -> d.toObject(Dwardari::class.java)?.copy(id = d.id)
                            clazz == Vehicle::class.java -> d.toObject(Vehicle::class.java)?.copy(id = d.id)
                            clazz == FamilyMember::class.java -> d.toObject(FamilyMember::class.java)?.copy(id = d.id)
                            else -> d.toObject(clazz)
                        } as T?
                    }
                } catch (e: Exception) { emptyList() }
                trySend(list)
            }
        }
        awaitClose { reg.remove() }
    }
}
