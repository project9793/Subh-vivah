package com.shubh.vivah.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object Repo {
    val auth: FirebaseAuth = FirebaseAuth.getInstance()
    val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    val rtdb: FirebaseDatabase = FirebaseDatabase.getInstance()

    fun userDoc(uid: String): DocumentReference = db.collection("users").document(uid)
    fun weddingDoc(uid: String): DocumentReference = db.collection("weddings").document(uid)
    fun col(uid: String, name: String): CollectionReference = weddingDoc(uid).collection(name)
    fun tracks(): DatabaseReference = rtdb.reference.child("tracks")

    fun userFlow(uid: String): Flow<User> = callbackFlow {
        val reg = userDoc(uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                trySend(snap.toObject(User::class.java)?.copy(id = uid) ?: User(id = uid))
            }
        }
        awaitClose { reg.remove() }
    }

    fun weddingFlow(uid: String): Flow<Wedding> = callbackFlow {
        val reg = weddingDoc(uid).addSnapshotListener { snap, _ ->
            if (snap != null) {
                trySend(snap.toObject(Wedding::class.java) ?: Wedding())
            }
        }
        awaitClose { reg.remove() }
    }

    fun <T> listFlow(uid: String, name: String, clazz: Class<T>): Flow<List<T>> = callbackFlow {
        val reg = col(uid, name).addSnapshotListener { snap, _ ->
            if (snap != null) trySend(snap.toObjects(clazz))
        }
        awaitClose { reg.remove() }
    }
}
