package com.shubh.vivah.ui.budget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Simple horizontal bar chart — सामान / खर्च / हलवाई / सजावट / वाहन */
class BarChartView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    data class Bar(val label: String, val value: Double)

    private var bars: List<Bar> = emptyList()

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3B2B52"); textSize = 30f
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C3AED"); textSize = 28f; textAlign = Paint.Align.RIGHT
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#A855F7") }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#EEE6F7") }

    fun setBars(list: List<Bar>) { bars = list; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val height = (bars.size.coerceAtLeast(1) * 90 + 20)
        setMeasuredDimension(MeasureSpec.getSize(w), height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (bars.isEmpty()) return
        val max = bars.maxOf { it.value }.coerceAtLeast(1.0)
        val labelW = 150f
        val valueW = 190f
        val barLeft = labelW
        val barRight = width - valueW
        var y = 10f
        bars.forEach { b ->
            canvas.drawText(b.label, 0f, y + 34f, labelPaint)
            val r = RectF(barLeft, y + 12f, barRight, y + 42f)
            canvas.drawRoundRect(r, 15f, 15f, trackPaint)
            val w = ((barRight - barLeft) * (b.value / max)).toFloat()
            if (w > 0) canvas.drawRoundRect(RectF(barLeft, y + 12f, barLeft + w, y + 42f), 15f, 15f, barPaint)
            canvas.drawText(fmt(b.value), width.toFloat(), y + 34f, valuePaint)
            y += 90f
        }
    }

    private fun fmt(v: Double): String {
        val nf = java.text.NumberFormat.getInstance(java.util.Locale("en", "IN"))
        nf.maximumFractionDigits = 0
        return "₹" + nf.format(v)
    }
}
