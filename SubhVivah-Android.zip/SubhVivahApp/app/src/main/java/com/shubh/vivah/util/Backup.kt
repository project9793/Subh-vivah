package com.shubh.vivah.util

import com.shubh.vivah.data.Repo
import org.json.JSONArray
import org.json.JSONObject

/** JSON backup / restore of the whole wedding, used from Settings and Budget. */
object Backup {

    val SUBCOLLECTIONS = listOf("guests", "items", "expenses", "dwardari", "vehicles", "family")

    fun build(uid: String, onReady: (String?) -> Unit) {
        if (uid.isBlank()) { onReady(null); return }
        val db = Repo.db
        val root = JSONObject()
        db.collection("users").document(uid).get().addOnSuccessListener { ud ->
            root.put("user", toJson(ud.data ?: emptyMap<String, Any>()))
            db.collection("weddings").document(uid).get().addOnSuccessListener { wd ->
                root.put("wedding", toJson(wd.data ?: emptyMap<String, Any>()))
                var remaining = SUBCOLLECTIONS.size
                SUBCOLLECTIONS.forEach { name ->
                    db.collection("weddings").document(uid).collection(name).get()
                        .addOnSuccessListener { q ->
                            val arr = JSONArray()
                            q.documents.forEach { d ->
                                val o = toJson(d.data ?: emptyMap<String, Any>())
                                if (o is JSONObject) o.put("__id", d.id)
                                arr.put(o)
                            }
                            root.put(name, arr)
                            if (--remaining == 0) onReady(root.toString(2))
                        }
                        .addOnFailureListener { if (--remaining == 0) onReady(root.toString(2)) }
                }
            }.addOnFailureListener { onReady(null) }
        }.addOnFailureListener { onReady(null) }
    }

    fun restore(uid: String, text: String, onDone: (Boolean) -> Unit) {
        if (uid.isBlank()) { onDone(false); return }
        try {
            val root = JSONObject(text)
            val db = Repo.db
            root.optJSONObject("wedding")?.let { w ->
                db.collection("weddings").document(uid).set(toMap(w))
            }
            SUBCOLLECTIONS.forEach { name ->
                val arr = root.optJSONArray(name) ?: return@forEach
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val map = toMap(o).toMutableMap()
                    val id = (map.remove("__id") as? String).orEmpty()
                    val docId = id.ifBlank {
                        db.collection("weddings").document(uid).collection(name).document().id
                    }
                    db.collection("weddings").document(uid).collection(name).document(docId).set(map)
                }
            }
            onDone(true)
        } catch (e: Exception) {
            onDone(false)
        }
    }

    fun toJson(v: Any?): Any = when (v) {
        null -> JSONObject.NULL
        is Map<*, *> -> JSONObject().also { o -> v.forEach { (k, value) -> o.put(k.toString(), toJson(value)) } }
        is List<*> -> JSONArray().also { a -> v.forEach { item -> a.put(toJson(item)) } }
        is String, is Number, is Boolean -> v
        else -> v.toString()
    }

    fun toMap(o: JSONObject): Map<String, Any> {
        val m = HashMap<String, Any>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val value = fromJson(o.get(k))
            if (value != null) m[k] = value
        }
        return m
    }

    private fun fromJson(v: Any?): Any? = when (v) {
        null, JSONObject.NULL -> null
        is JSONObject -> toMap(v)
        is JSONArray -> (0 until v.length()).mapNotNull { fromJson(v.get(it)) }
        else -> v
    }
}
