package com.shubh.vivah.util

import android.content.Context
import android.content.Intent
import android.net.Uri

object Share {
    fun text(ctx: Context, body: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, body)
        }
        ctx.startActivity(Intent.createChooser(i, "साझा करें"))
    }

    fun whatsapp(ctx: Context, body: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(body)))
            ctx.startActivity(i)
        } catch (e: Exception) { text(ctx, body) }
    }

    fun image(ctx: Context, uri: Uri, body: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "कार्ड साझा करें"))
    }

    fun maps(ctx: Context, address: String) {
        val q = Uri.encode(address)
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
        } catch (e: Exception) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps?q=$q")))
        }
    }
}
