package com.shubh.vivah.ui.card

import com.shubh.vivah.util.*

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.print.PrintHelper
import com.google.firebase.storage.FirebaseStorage
import com.shubh.vivah.R
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.CardData
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentCardBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.util.Share
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.toast
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.launch

class CardFragment : Fragment() {

    private var _b: FragmentCardBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private var lastTpl = -1

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentCardBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { findNavController().navigateUp() }
        b.tpl1.setOnClickListener { setTpl(1) }
        b.tpl2.setOnClickListener { setTpl(2) }
        b.tpl3.setOnClickListener { setTpl(3) }
        b.tpl4.setOnClickListener { setTpl(4) }
        b.btnSample.setOnClickListener { fillSample() }
        b.btnEdit.setOnClickListener { editCard() }
        b.btnJpg.setOnClickListener { shareJpg() }
        b.btnPdf.setOnClickListener { savePdf() }
        b.btnPrint.setOnClickListener { printCard() }
        b.btnWa.setOnClickListener { Share.whatsapp(requireContext(), waText()) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val cd = s.w.card
        if (lastTpl != cd.tpl || b.cardHost.childCount == 0) {
            inflateTemplate(cd.tpl)
            lastTpl = cd.tpl
        }
        highlight(cd.tpl)
        bind(cd, s)
    }

    private fun highlight(tpl: Int) {
        listOf(b.tpl1, b.tpl2, b.tpl3, b.tpl4).forEachIndexed { i, tv ->
            val on = (i + 1) == tpl
            tv.setBackgroundResource(if (on) R.drawable.bg_chip_info else R.drawable.bg_round_white)
            tv.alpha = if (on) 1f else 0.7f
        }
    }

    private fun inflateTemplate(tpl: Int) {
        b.cardHost.removeAllViews()
        val layout = when (tpl) {
            1 -> R.layout.card_tpl_1
            2 -> R.layout.card_tpl_2
            3 -> R.layout.card_tpl_3
            else -> R.layout.card_tpl_4
        }
        LayoutInflater.from(requireContext()).inflate(layout, b.cardHost, false).also { b.cardHost.addView(it) }
    }

    private fun resId(name: String): Int =
        resources.getIdentifier(name, "id", requireContext().packageName)

    private fun bind(cd: CardData, s: AppState) {
        val root = b.cardHost.getChildAt(0) as? ViewGroup ?: return
        fun set(name: String, text: String) {
            root.findViewById<TextView>(resId(name))?.text = text
        }
        set("tvGanesh", "॥ श्री गणेशाय नमः ॥")
        set("tvGroomName", (cd.groomPre + " " + cd.groom).trim())
        set("tvBrideName", (cd.bridePre + " " + cd.bride).trim())
        set("tvGroomFamily", "सुपुत्र " + cd.groomF + (if (cd.groomGF.isNotBlank()) "\nपौत्र " + cd.groomGF else ""))
        set("tvBrideFamily", "सुपुत्री " + cd.brideF + (if (cd.brideGF.isNotBlank()) "\nपौत्री " + cd.brideGF else ""))
        set("tvGroomVill", listOf(cd.groomVill, cd.groomDist).filter { it.isNotBlank() }.joinToString(", "))
        set("tvBrideVill", listOf(cd.brideVill, cd.brideDist).filter { it.isNotBlank() }.joinToString(", "))
        set("tvFam", if (cd.fam.isNotBlank()) "श्री " + cd.fam + " परिवार की ओर से" else "")
        set("tvDate", cd.date.dmy())
        set("tvTime", cd.time)
        set("tvVenue", cd.venue)
        set("tvAddr", cd.addr)
        set("tvMsg", cd.msg)
        set("tvSender", if (cd.sender.isNotBlank()) "निवेदक — " + cd.sender + "\n" + cd.village + " " + cd.dist else "")
        set("tvContact", if (cd.contact.isNotBlank()) "📞 " + cd.contact else "")
        set("tvListShubh", cd.listShubh)
        set("tvListNihati", cd.listNihati)
        set("tvListDarshan", cd.listDarshan)
        set("tvListSwagat", cd.listSwagat)
        set("tvListVinit", cd.listVinit)

        val ev = s.w.events.filter { it.name.isNotBlank() }.joinToString("\n") { e ->
            e.icon + " " + e.name + (if (e.date.isNotBlank()) " — " + e.date.dmy() + " " + e.time else "")
        }
        set("tvEvents", ev)
    }

    private fun setTpl(tpl: Int) {
        vm.saveWedding(vm.state.value.w.copy(card = vm.state.value.w.card.copy(tpl = tpl)))
    }

    private fun fillSample() {
        vm.saveWedding(vm.state.value.w.copy(card = sample()))
        requireContext().toast("✨ नमूना भर दिया — अब अपने हिसाब से बदलें")
    }

    private fun editCard() {
        val cd = vm.state.value.w.card
        val f = listOf(
            Field("groom", "वर का नाम"), Field("bride", "कन्या का नाम"),
            Field("groomPre", "वर उपाधि (चि.)"), Field("bridePre", "कन्या उपाधि (सौ.कां.)"),
            Field("groomF", "वर के पिता"), Field("brideF", "कन्या के पिता"),
            Field("groomGF", "वर के दादा"), Field("brideGF", "कन्या के दादा"),
            Field("groomVill", "वर का गाँव"), Field("groomDist", "वर का जिला"),
            Field("brideVill", "कन्या का गाँव"), Field("brideDist", "कन्या का जिला"),
            Field("fam", "परिवार / उपनाम"), Field("sender", "निवेदक"),
            Field("village", "निवेदक गाँव"), Field("dist", "निवेदक जिला"),
            Field("contact", "संपर्क नंबर"), Field("date", "तारीख", FType.DATE),
            Field("time", "समय (जैसे: रात 8:00 बजे)"), Field("venue", "स्थान"),
            Field("addr", "पता"), Field("msg", "संदेश"),
            Field("listShubh", "शुभचिंतक सूची", FType.MULTI),
            Field("listNihati", "निहाती सूची", FType.MULTI),
            Field("listDarshan", "दर्शनार्थी सूची (रिश्ते सहित)", FType.MULTI),
            Field("listSwagat", "स्वागताधिकारी सूची", FType.MULTI),
            Field("listVinit", "विनीत सूची", FType.MULTI)
        )
        val vals = mapOf(
            "groom" to cd.groom, "bride" to cd.bride, "groomPre" to cd.groomPre, "bridePre" to cd.bridePre,
            "groomF" to cd.groomF, "brideF" to cd.brideF, "groomGF" to cd.groomGF, "brideGF" to cd.brideGF,
            "groomVill" to cd.groomVill, "groomDist" to cd.groomDist,
            "brideVill" to cd.brideVill, "brideDist" to cd.brideDist,
            "fam" to cd.fam, "sender" to cd.sender, "village" to cd.village, "dist" to cd.dist,
            "contact" to cd.contact, "date" to cd.date, "time" to cd.time, "venue" to cd.venue,
            "addr" to cd.addr, "msg" to cd.msg, "listShubh" to cd.listShubh, "listNihati" to cd.listNihati,
            "listDarshan" to cd.listDarshan, "listSwagat" to cd.listSwagat, "listVinit" to cd.listVinit
        )
        FormDialog.show(requireContext(), "💌 कार्ड की जानकारी", f, vals) { m ->
            vm.saveWedding(vm.state.value.w.copy(card = cd.copy(
                groom = FormDialog.str(m, "groom"), bride = FormDialog.str(m, "bride"),
                groomPre = FormDialog.str(m, "groomPre"), bridePre = FormDialog.str(m, "bridePre"),
                groomF = FormDialog.str(m, "groomF"), brideF = FormDialog.str(m, "brideF"),
                groomGF = FormDialog.str(m, "groomGF"), brideGF = FormDialog.str(m, "brideGF"),
                groomVill = FormDialog.str(m, "groomVill"), groomDist = FormDialog.str(m, "groomDist"),
                brideVill = FormDialog.str(m, "brideVill"), brideDist = FormDialog.str(m, "brideDist"),
                fam = FormDialog.str(m, "fam"), sender = FormDialog.str(m, "sender"),
                village = FormDialog.str(m, "village"), dist = FormDialog.str(m, "dist"),
                contact = FormDialog.str(m, "contact"), date = FormDialog.str(m, "date"),
                time = FormDialog.str(m, "time"), venue = FormDialog.str(m, "venue"),
                addr = FormDialog.str(m, "addr"), msg = FormDialog.str(m, "msg"),
                listShubh = FormDialog.str(m, "listShubh"), listNihati = FormDialog.str(m, "listNihati"),
                listDarshan = FormDialog.str(m, "listDarshan"), listSwagat = FormDialog.str(m, "listSwagat"),
                listVinit = FormDialog.str(m, "listVinit")
            )))
            requireContext().toast("✅ कार्ड सेव हो गया")
        }
    }

    private fun bitmap(): Bitmap {
        val v = b.cardHost.getChildAt(0) ?: return Bitmap.createBitmap(10, 10, Bitmap.Config.ARGB_8888)
        val w = if (v.width > 0) v.width else 900
        val h = if (v.height > 0) v.height else 1300
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        v.draw(c)
        return bmp
    }

    private fun shareJpg() {
        try {
            val bmp = bitmap()
            val f = File(requireContext().cacheDir, "shubh_card.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            val uri: Uri = FileProvider.getUriForFile(requireContext(), requireContext().packageName + ".fileprovider", f)
            Share.image(requireContext(), uri, waText())
            upload(bmp)
        } catch (e: Exception) {
            requireContext().toast("⚠️ " + (e.message ?: "कार्ड नहीं बना"))
        }
    }

    private fun savePdf() {
        try {
            val bmp = bitmap()
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
            val c = page.canvas
            c.drawColor(Color.WHITE)
            val scale = Math.min(555f / bmp.width, 800f / bmp.height)
            val w = (bmp.width * scale).toInt()
            val h = (bmp.height * scale).toInt()
            val left = (595 - w) / 2f
            val top = (842 - h) / 2f
            c.drawBitmap(bmp, null, android.graphics.RectF(left, top, left + w, top + h), null)
            doc.finishPage(page)
            val f = File(requireContext().cacheDir, "shubh_card.pdf")
            FileOutputStream(f).use { doc.writeTo(it) }
            doc.close()
            val uri = FileProvider.getUriForFile(requireContext(), requireContext().packageName + ".fileprovider", f)
            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(i, "PDF साझा करें"))
            requireContext().toast("✅ PDF बन गया")
        } catch (e: Exception) {
            requireContext().toast("⚠️ " + (e.message ?: "PDF नहीं बना"))
        }
    }

    private fun printCard() {
        try {
            PrintHelper(requireContext()).apply { scaleMode = PrintHelper.SCALE_MODE_FIT }
                .printBitmap("शुभ विवाह कार्ड", bitmap())
        } catch (e: Exception) {
            requireContext().toast("⚠️ प्रिंट नहीं हो सका")
        }
    }

    private fun upload(bmp: Bitmap) {
        val uid = Repo.auth.currentUser?.uid ?: return
        val ref = FirebaseStorage.getInstance().reference.child("cards").child(uid).child("card_" + System.currentTimeMillis() + ".jpg")
        val out = java.io.ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        ref.putBytes(out.toByteArray())
        vm.saveWedding(vm.state.value.w.copy(cardCount = vm.state.value.w.cardCount + 1))
    }

    private fun waText(): String {
        val w = vm.state.value.w
        val cd = w.card
        return "🙏 " + (cd.sender.ifBlank { w.groom }) + " की ओर से\n" +
            "💍 " + cd.groom + " ❤ " + cd.bride + "\n" +
            "📅 " + cd.date.dmy() + " " + cd.time + "\n" +
            "📍 " + cd.venue + " " + cd.addr + "\n" +
            "📞 " + cd.contact + "\n" + cd.msg
    }

    private fun sample() = CardData(
        tpl = vm.state.value.w.card.tpl,
        groom = "गुंधेलाल", bride = "शिवकुमारी",
        groomF = "ललक प्रजापति", brideF = "राम दुलारे चक्रधारी",
        groomGF = "गुलपत प्रजापति", brideGF = "सुकलाल चक्रधारी",
        groomVill = "अछोली", groomDist = "बालोद",
        brideVill = "अछोटा", brideDist = "धमतरी",
        fam = "प्रजापति", sender = "गुलपत प्रजापति",
        village = "अछोली", dist = "बालोद (छ.ग.)",
        contact = "1234567890, 1234567890",
        date = vm.state.value.w.wdate, time = "रात 8:00 बजे",
        venue = "ग्राम-अछोली", addr = "जिला-बालोद (छ.ग.)",
        msg = "आपका शुभ हाथ अवश्य दें।",
        listShubh = "शलेन्द्र, अनिल, जगदीस,\nमालेन्द्र, राजेन्द्र, राज बिहारी",
        listNihati = "कुणाल, भावेश, उत्तम,\nखुसील, लक्ष, पुष्पा, रिंकी",
        listDarshan = "शिवकुमार- चौरसिया (फूफा-बुआ)\nमुन्ना- फूली (फूफा-बुआ)\nराजकुमार- रेखा (मामा-मामी)\nछोटेलाल- लीलाबती (मामा-मामी)\nगजेन्द्र- शिवबती (जीजा-दीदी)",
        listSwagat = "राम सजीवन- रजनी (बड़ेपापा-मां)\nबिसुनाथ- बुधानी (बड़ेपापा-मां)\nअरविन्द- उर्मिला (भैया-भाभी)\nराजकुमार- गीता (भैया-भाभी)",
        listVinit = "ललऊराम - पार्वती (दादा-दादी)\nगुलपत - कुसुम (पिताजी-मां)"
    )

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
