package com.shubh.vivah.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {

    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    val uid: String get() = Repo.auth.currentUser?.uid ?: ""
    private var started = false

    fun start() {
        val u = uid
        if (u.isBlank() || started) return
        started = true
        ensureWedding(u)
        viewModelScope.launch {
            val base = combine(Repo.userFlow(u), Repo.weddingFlow(u)) { user, w -> user to w }
            val lists = combine(
                Repo.listFlow(u, "guests", Guest::class.java),
                Repo.listFlow(u, "items", Item::class.java),
                Repo.listFlow(u, "expenses", Expense::class.java)
            ) { g, i, e -> Triple(g, i, e) }
            val more = combine(
                Repo.listFlow(u, "dwardari", Dwardari::class.java),
                Repo.listFlow(u, "vehicles", Vehicle::class.java),
                Repo.listFlow(u, "family", FamilyMember::class.java)
            ) { d, v, f -> Triple(d, v, f) }
            combine(base, lists, more) { b, l, m ->
                AppState(b.first, b.second, l.first, l.second, l.third, m.first, m.second, m.third)
            }.collect { _state.value = it }
        }
    }

    private fun ensureWedding(u: String) {
        Repo.weddingDoc(u).get().addOnSuccessListener { snap ->
            if (!snap.exists()) Repo.weddingDoc(u).set(Wedding())
        }
    }

    fun saveWedding(w: Wedding) { if (uid.isNotBlank()) Repo.weddingDoc(uid).set(w) }

    private fun save(col: String, id: String, build: (String) -> Any) {
        if (uid.isBlank()) return
        val c = Repo.col(uid, col)
        val docId = id.ifBlank { c.document().id }
        c.document(docId).set(build(docId))
    }

    fun saveGuest(g: Guest) = save("guests", g.id) { g.copy(id = it) }
    fun delGuest(id: String) = delete("guests", id)

    fun saveItem(i: Item) = save("items", i.id) { i.copy(id = it) }
    fun delItem(id: String) = delete("items", id)

    fun saveExpense(e: Expense) = save("expenses", e.id) { e.copy(id = it) }
    fun delExpense(id: String) = delete("expenses", id)

    fun saveDwardari(d: Dwardari) = save("dwardari", d.id) { d.copy(id = it) }
    fun delDwardari(id: String) = delete("dwardari", id)

    fun saveVehicle(v: Vehicle) = save("vehicles", v.id) { v.copy(id = it) }
    fun delVehicle(id: String) = delete("vehicles", id)

    fun saveFamily(f: FamilyMember) = save("family", f.id) { f.copy(id = it) }
    fun delFamily(id: String) = delete("family", id)

    fun saveProfile(u: User) { if (uid.isNotBlank()) Repo.userDoc(uid).set(u.copy(id = uid)) }

    private fun delete(col: String, id: String) {
        if (uid.isBlank() || id.isBlank()) return
        Repo.col(uid, col).document(id).delete()
    }
}
