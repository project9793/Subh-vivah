package com.shubh.vivah.ui.track

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.shubh.vivah.R
import com.shubh.vivah.data.Repo

class TrackService : Service() {

    companion object {
        const val ACTION_START = "com.shubh.vivah.TRACK_START"
        const val ACTION_STOP = "com.shubh.vivah.TRACK_STOP"
        const val EXTRA_ID = "track_id"
        const val EXTRA_TYPE = "track_type"
        const val EXTRA_DEST = "track_dest"
        private const val CH = "sv_live"
        private const val NOTIF_ID = 41

        fun start(ctx: Context, id: String, type: String, dest: String) {
            val i = Intent(ctx, TrackService::class.java).setAction(ACTION_START)
                .putExtra(EXTRA_ID, id).putExtra(EXTRA_TYPE, type).putExtra(EXTRA_DEST, dest)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context, id: String) {
            val i = Intent(ctx, TrackService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_ID, id)
            try {
                ctx.startService(i)
            } catch (e: Exception) {
                Repo.tracks().child(id).child("active").setValue(false)
            }
        }
    }

    private lateinit var fused: FusedLocationProviderClient
    private var trackId = ""
    private var lastWrite = 0L

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc: Location = result.lastLocation ?: return
            val now = System.currentTimeMillis()
            if (now - lastWrite < 2500) return
            lastWrite = now
            val map = mapOf(
                "lat" to loc.latitude,
                "lng" to loc.longitude,
                "ts" to now,
                "active" to true
            )
            Repo.tracks().child(trackId).updateChildren(map)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID).orEmpty()
        when (intent?.action) {
            ACTION_STOP -> {
                if (id.isNotBlank()) {
                    Repo.tracks().child(id).child("active").setValue(false)
                    Repo.tracks().child(id).child("lat").setValue(null)
                }
                stopUpdates()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                if (id.isBlank()) { stopSelf(); return START_NOT_STICKY }
                trackId = id
                startForegroundSafe()
                startUpdates(intent.getStringExtra(EXTRA_TYPE).orEmpty(), intent.getStringExtra(EXTRA_DEST).orEmpty())
            }
        }
        return START_STICKY
    }

    private fun startForegroundSafe() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CH, "Live Location", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setContentTitle("शुभ विवाह — Live Location चालू")
            .setContentText("ID: " + trackId + " • मेहमान इस ID से आपको देख सकते हैं")
            .setSmallIcon(R.drawable.ic_pin)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun startUpdates(type: String, dest: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return
        }
        val uid = Repo.auth.currentUser?.uid.orEmpty()
        val base = mapOf(
            "type" to type.ifBlank { "BARAAT" },
            "ownerUid" to uid,
            "destName" to dest,
            "active" to true,
            "ts" to System.currentTimeMillis()
        )
        Repo.tracks().child(trackId).updateChildren(base)

        fused = LocationServices.getFusedLocationProviderClient(this)
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000L)
            .setMinUpdateDistanceMeters(5f)
            .build()
        try {
            fused.requestLocationUpdates(req, callback, Looper.getMainLooper())
        } catch (e: SecurityException) {
            stopSelf()
        }
    }

    private fun stopUpdates() {
        try { if (::fused.isInitialized) fused.removeLocationUpdates(callback) } catch (e: Exception) {}
    }

    override fun onDestroy() {
        stopUpdates()
        super.onDestroy()
    }
}
