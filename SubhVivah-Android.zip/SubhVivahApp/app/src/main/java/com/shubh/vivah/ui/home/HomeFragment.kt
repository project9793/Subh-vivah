package com.shubh.vivah.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.shubh.vivah.R
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Calc
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentHomeBinding
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.money
import com.shubh.vivah.util.moneyShort
import com.shubh.vivah.util.showIf
import kotlinx.coroutines.launch
import androidx.core.os.bundleOf

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: HomeCardAdapter
    private var liveCount = 0
    private var liveListener: ValueEventListener? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        adapter = HomeCardAdapter { card ->
            val args = Bundle()
            when (card.route) {
                R.id.listFragment -> args.putString("mode", card.tag)
                R.id.vendorFragment -> args.putString("kind", card.tag)
                R.id.familyFragment -> args.putString("side", card.tag)
                R.id.trackFragment -> args.putString("type", card.tag)
            }
            findNavController().navigate(card.route, args)
        }
        b.rvCards.layoutManager = GridLayoutManager(requireContext(), 2)
        b.rvCards.adapter = adapter

        b.btnProfile.setOnClickListener {
            findNavController().navigate(R.id.settingsFragment)
        }
        b.btnNotif.setOnClickListener { showNotifs() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
        watchLive()
    }

    private fun watchLive() {
        liveListener?.let { Repo.tracks().removeEventListener(it) }
        liveListener = object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                val uid = Repo.auth.currentUser?.uid ?: return
                liveCount = snap.children.count { c ->
                    c.child("ownerUid").getValue(String::class.java) == uid &&
                        c.child("active").getValue(Boolean::class.java) == true
                }
                vm.state.value.let { render(it) }
            }
            override fun onCancelled(error: DatabaseError) {}
        }.also { Repo.tracks().addValueEventListener(it) }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        val days = Calc.daysLeft(s.w.wdate)

        b.tvAva.text = s.user.fullName.trim().take(1).ifBlank { "?" }.uppercase()
        b.tvName.text = s.user.fullName.ifBlank { "—" }
        b.tvSub.text = "🏙 " + listOf(s.user.city, s.user.state).filter { it.isNotBlank() }.joinToString(", ").ifBlank { "पता जोड़ें" }
        b.tvCouple.text = if (s.w.groom.isNotBlank() || s.w.bride.isNotBlank())
            "💍 " + s.w.groom.ifBlank { "—" } + " ❤ " + s.w.bride.ifBlank { "—" }
        else getString(R.string.set_wedding)

        b.tvNames.text = when {
            s.w.groom.isNotBlank() && s.w.bride.isNotBlank() -> s.w.groom + " ❤ " + s.w.bride
            s.w.groom.isNotBlank() || s.w.bride.isNotBlank() -> s.w.groom.ifBlank { s.w.bride }
            else -> "अपनी शादी सेट करें"
        }
        b.tvDate.text = s.w.wdate.dmy()
        b.tvDays.text = if (days < 0) "हो गई ❤" else days.toString()
        b.tvGuests.text = c.guestTotal.toString()
        b.tvExp.text = if (c.exp >= 100000) c.exp.moneyShort() else c.exp.money()

        val list = listOf(
            HomeCard("💌", "निमंत्रण", "मेहमान व निमंत्रण प्रबंधन", "${c.guestSent}/${c.guestTotal}", "#FCE7F3", false, R.id.guestsFragment, ""),
            HomeCard("📦", "सामान", "खरीदारी व वेंडर ट्रैकिंग", c.itemsCount.toString(), "#E0F2FE", false, R.id.listFragment, "items"),
            HomeCard("💰", "द्वारदारी", "मेहमानों से मिली द्वारदारी", c.dwrTotal.money(), "#FEF3C7", false, R.id.listFragment, "dwardari"),
            HomeCard("🍽️", "हलवाई", "खानपान व मेन्यू", c.halwaiTotal.money(), "#DCFCE7", false, R.id.vendorFragment, "halwai"),
            HomeCard("✨", "सजावट", "टेंट, लाइट, स्टेज, फूल", c.decorTotal.money(), "#EDE9FE", false, R.id.vendorFragment, "decor"),
            HomeCard("💵", "कुल राशि", "पूरा बजट व चार्ट", c.exp.money(), "#FFE4E6", false, R.id.budgetFragment, ""),
            HomeCard("👨‍👩‍👦", "वर पक्ष", "परिवार व मेहमान सूची", s.family.count { it.side == "var" }.toString(), "#E0F2FE", false, R.id.familyFragment, "var"),
            HomeCard("👰", "कन्या पक्ष", "परिवार व मेहमान सूची", s.family.count { it.side == "kanya" }.toString(), "#FCE7F3", false, R.id.familyFragment, "kanya"),
            HomeCard("🚗", "बारात Live", "रियल-टाइम लोकेशन", "$liveCount लाइव", "#DCFCE7", liveCount > 0, R.id.trackFragment, "BARAAT"),
            HomeCard("🏠", "घरात/घराती Live", "रियल-टाइम लोकेशन", "$liveCount लाइव", "#FEF3C7", liveCount > 0, R.id.trackFragment, "GHARATI"),
            HomeCard("💌", "डिजिटल कार्ड", "न्योता पत्र बनाएँ व भेजें", s.w.cardCount.toString(), "#EDE9FE", false, R.id.cardFragment, ""),
            HomeCard("🚗", "वाहन बुकिंग", "शादी की गाड़ियों का हिसाब", c.vehiCount.toString(), "#E0F2FE", false, R.id.listFragment, "vehicles")
        )
        adapter.setItems(list)
        b.dot.visibility = if (notifCount(s, c) > 0) View.VISIBLE else View.GONE
    }

    private fun notifCount(s: AppState, c: com.shubh.vivah.data.Calc.Totals): Int {
        var n = 0
        val d = Calc.daysLeft(s.w.wdate)
        if (s.w.wdate.isNotBlank() && d in 0..30) n++
        n += s.w.events.count { e -> e.date.isNotBlank() && Calc.daysLeft(e.date) in 0..15 }
        if (c.guestPend > 0) n++
        if (c.guestTotal - c.guestConf - c.guestNo > 0) n++
        if (c.budget > 0 && c.exp > c.budget) n++
        return n
    }

    private fun showNotifs() {
        val s = vm.state.value
        val c = Calc.of(s)
        val lines = ArrayList<String>()
        val d = Calc.daysLeft(s.w.wdate)
        if (s.w.wdate.isNotBlank() && d in 0..30) lines.add("⏳ विवाह में $d दिन बाकी! तैयारियाँ जोरों पर रखें")
        s.w.events.forEach { e ->
            if (e.date.isNotBlank()) {
                val dd = Calc.daysLeft(e.date)
                if (dd in 0..15) lines.add("${e.icon} ${e.name} — $dd दिन बाकी (${e.date.dmy()} ${e.time})")
            }
        }
        if (c.guestPend > 0) lines.add("💌 ${c.guestPend} निमंत्रण अभी नहीं भेजे गए")
        if (c.guestTotal - c.guestConf - c.guestNo > 0) lines.add("👥 ${c.guestTotal - c.guestConf - c.guestNo} मेहमानों का RSVP बाकी")
        if (c.budget > 0 && c.exp > c.budget) lines.add("⚠️ बजट पार हो गया! खर्च ${c.exp.money()} / बजट ${c.budget.money()}")
        if (lines.isEmpty()) lines.add("अभी कोई सूचना नहीं 🌸")

        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("🔔 सूचनाएँ")
            .setMessage(lines.joinToString("\n\n"))
            .setPositiveButton("ठीक है", null)
            .show()
    }

    override fun onDestroyView() {
        liveListener?.let { Repo.tracks().removeEventListener(it) }
        liveListener = null
        super.onDestroyView()
        _b = null
    }
}
