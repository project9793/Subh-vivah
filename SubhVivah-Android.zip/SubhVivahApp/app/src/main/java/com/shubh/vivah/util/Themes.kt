package com.shubh.vivah.util

import android.content.Context
import androidx.annotation.StyleRes
import com.shubh.vivah.R

/** App ke rang-birange themes. Settings se chunne par poore app par lag jata hai. */
object Themes {

    data class Item(val key: String, val hi: String, val en: String, @StyleRes val style: Int)

    val ALL = listOf(
        Item("royal", "रॉयल पर्पल", "Royal Purple", R.style.Theme_SubhVivah_Royal),
        Item("maroon", "रॉयल मैरून", "Royal Maroon", R.style.Theme_SubhVivah_Maroon),
        Item("emerald", "एमराल्ड गोल्ड", "Emerald Gold", R.style.Theme_SubhVivah_Emerald),
        Item("midnight", "मिडनाइट ब्लू", "Midnight Blue", R.style.Theme_SubhVivah_Midnight),
        Item("rose", "रोज़ गोल्ड", "Rose Gold", R.style.Theme_SubhVivah_Rose)
    )

    fun currentKey(ctx: Context): String =
        ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).getString("theme", "royal") ?: "royal"

    fun save(ctx: Context, key: String) {
        ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).edit().putString("theme", key).apply()
    }

    @StyleRes
    fun currentStyle(ctx: Context): Int =
        ALL.firstOrNull { it.key == currentKey(ctx) }?.style ?: R.style.Theme_SubhVivah_Royal

    fun label(ctx: Context, key: String): String {
        val t = ALL.firstOrNull { it.key == key } ?: ALL.first()
        return Lang.t(t.hi, t.en)
    }
}
