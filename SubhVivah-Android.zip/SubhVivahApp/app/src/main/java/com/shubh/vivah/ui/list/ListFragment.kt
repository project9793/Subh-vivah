package com.shubh.vivah.ui.list

import com.shubh.vivah.util.*

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.R
import com.shubh.vivah.data.*
import com.shubh.vivah.databinding.FragmentListPageBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.money
import com.shubh.vivah.util.showIf
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class ListFragment : Fragment() {

    private var _b: FragmentListPageBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var mode = "items"
    private var idx: List<String> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentListPageBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        mode = arguments?.getString("mode") ?: "items"
        b.btnBack.setOnClickListener { findNavController().navigateUp() }
        b.fab.setOnClickListener { edit(null) }
        b.btnExtra.showIf(mode == "dwardari")
        b.btnExtra.setOnClickListener {
            findNavController().navigate(R.id.listFragment, bundleOf("mode" to "expenses"))
        }
        b.strip.showIf(mode != "none")

        adapter = RowAdapter(
            onEdit = { i -> edit(idx.getOrNull(i)) },
            onDelete = { i -> idx.getOrNull(i)?.let { id -> askDelete(id) } }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        when (mode) {
            "items" -> {
                b.tvTitle.text = getString(R.string.items_title)
                setStrip(listOf(
                    c.itemsCount.toString() to "कुल सामान",
                    c.itemsPend.toString() to "बाकी खरीद",
                    c.itemsTotal.money() to "कुल राशि"
                ))
                idx = s.items.map { it.id }
                adapter.setItems(s.items.map { i ->
                    Row("📦", i.name,
                        if (i.status == "done") "खरीदा" else "बाकी",
                        "${i.qty} × ${i.rate.money()} = ${i.total.money()}" +
                            (if (i.pay == "paid") " • ✅ भुगतान" else " • ⏳ भुगतान बाकी") +
                            (if (i.vendor.isNotBlank()) "\n🏬 ${i.vendor}" else ""))
                })
            }
            "expenses" -> {
                b.tvTitle.text = getString(R.string.expenses_title)
                setStrip(listOf(
                    c.expTotal.money() to "कुल खर्च",
                    s.exps.size.toString() to "एंट्रीज"
                ))
                idx = s.exps.map { it.id }
                adapter.setItems(s.exps.map { e ->
                    Row("💰", e.name, e.date.dmy(), e.notes.ifBlank { e.amt.money() })
                })
            }
            "dwardari" -> {
                b.tvTitle.text = getString(R.string.dwardari_title)
                setStrip(listOf(
                    c.dwrTotal.money() to "कुल द्वारदारी",
                    c.dwrPanv.money() to "पाँवपूजा",
                    c.dwrAangan.money() to "आँगन",
                    c.dwrDwar.money() to "द्वारदारी"
                ))
                idx = s.dwr.map { it.id }
                adapter.setItems(s.dwr.map { d ->
                    Row("🎁", d.name, progLabel(d.prog), "📍 ${d.village.orDash()} • ${d.cash.money()}" +
                        (if (d.gift.isNotBlank()) "\n🎁 ${d.gift}" else ""))
                })
            }
            "vehicles" -> {
                b.tvTitle.text = getString(R.string.vehicles_title)
                setStrip(listOf(
                    c.vehiCount.toString() to "गाड़ियाँ",
                    c.vehiTotal.money() to "कुल किराया",
                    c.vehiAdv.money() to "एडवांस"
                ))
                idx = s.vehi.map { it.id }
                adapter.setItems(s.vehi.map { v ->
                    Row("🚗", v.name,
                        v.rate.money(),
                        "🧑‍✈️ ${v.driver.orDash()} • 📱 ${v.mob.orDash()}\nएडवांस ${v.adv.money()} • ${v.from.orDash()} → ${v.to.orDash()}")
                })
            }
        }
    }

    private fun progLabel(p: String) = when (p) {
        "panv" -> "पाँवपूजा"; "aangan" -> "आँगन"; else -> "द्वारदारी"
    }

    private fun setStrip(tiles: List<Pair<String, String>>) {
        val views = listOf(b.t1 to b.k1, b.t2 to b.k2, b.t3 to b.k3, b.t4 to b.k4)
        views.forEachIndexed { i, (tv, kt) ->
            val item = tiles.getOrNull(i)
            tv.showIf(item != null); kt.showIf(item != null)
            if (item != null) { tv.text = item.first; kt.text = item.second }
        }
    }

    private fun askDelete(id: String) {
        requireContext().confirm("हटाएँ?", "यह एंट्री हट जाएगी।") {
            when (mode) {
                "items" -> vm.delItem(id)
                "expenses" -> vm.delExpense(id)
                "dwardari" -> vm.delDwardari(id)
                "vehicles" -> vm.delVehicle(id)
            }
        }
    }

    private fun edit(id: String?) {
        val s = vm.state.value
        when (mode) {
            "items" -> {
                val e = s.items.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "सामान का नाम *"), Field("qty", "मात्रा *", FType.NUM),
                    Field("rate", "दर (₹) *", FType.NUM), Field("vendor", "वेंडर का नाम"),
                    Field("status", "स्थिति", FType.SELECT, listOf("pend" to "⏳ बाकी", "done" to "✅ खरीदा गया")),
                    Field("pay", "भुगतान", FType.SELECT, listOf("pend" to "⏳ बाकी", "paid" to "✅ भुगतान हो गया"))
                )
                FormDialog.show(requireContext(), "📦 सामान", f, mapOf(
                    "name" to (e?.name ?: ""), "qty" to (e?.qty ?: 1.0).toString(),
                    "rate" to (e?.rate ?: 0.0).toString(), "vendor" to (e?.vendor ?: ""),
                    "status" to (e?.status ?: "pend"), "pay" to (e?.pay ?: "pend")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    vm.saveItem(Item(id ?: "", n, FormDialog.num(m, "qty"), FormDialog.num(m, "rate"),
                        FormDialog.str(m, "vendor"), FormDialog.str(m, "status"), FormDialog.str(m, "pay")))
                    requireContext().toast("✅ सेव हो गया")
                }
            }
            "expenses" -> {
                val e = s.exps.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "खर्च का नाम *"), Field("amt", "राशि (₹) *", FType.NUM),
                    Field("date", "तारीख", FType.DATE), Field("notes", "नोट्स", FType.MULTI)
                )
                FormDialog.show(requireContext(), "🧾 खर्च", f, mapOf(
                    "name" to (e?.name ?: ""), "amt" to (e?.amt ?: 0.0).toString(),
                    "date" to (e?.date ?: ""), "notes" to (e?.notes ?: "")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    vm.saveExpense(Expense(id ?: "", n, FormDialog.num(m, "amt"),
                        FormDialog.str(m, "date"), FormDialog.str(m, "notes")))
                    requireContext().toast("✅ सेव हो गया")
                }
            }
            "dwardari" -> {
                val e = s.dwr.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "मेहमान का नाम *"), Field("village", "गाँव / पता"),
                    Field("prog", "कार्यक्रम", FType.SELECT, listOf("panv" to "पाँवपूजा", "aangan" to "आँगन", "dwar" to "द्वारदारी")),
                    Field("cash", "नगद राशि (₹)", FType.NUM), Field("gift", "उपहार (विवरण)")
                )
                FormDialog.show(requireContext(), "💰 द्वारदारी", f, mapOf(
                    "name" to (e?.name ?: ""), "village" to (e?.village ?: ""),
                    "prog" to (e?.prog ?: "panv"), "cash" to (e?.cash ?: 0.0).toString(),
                    "gift" to (e?.gift ?: "")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    vm.saveDwardari(Dwardari(id ?: "", n, FormDialog.str(m, "village"),
                        FormDialog.str(m, "prog"), FormDialog.num(m, "cash"), FormDialog.str(m, "gift")))
                    requireContext().toast("✅ सेव हो गया")
                }
            }
            "vehicles" -> {
                val e = s.vehi.firstOrNull { it.id == id }
                val f = listOf(
                    Field("name", "गाड़ी / नाम *"), Field("driver", "ड्राइवर"),
                    Field("mob", "मोबाइल"), Field("rate", "किराया (₹)", FType.NUM),
                    Field("adv", "एडवांस (₹)", FType.NUM), Field("from", "कहाँ से"), Field("to", "कहाँ तक")
                )
                FormDialog.show(requireContext(), "🚗 वाहन", f, mapOf(
                    "name" to (e?.name ?: ""), "driver" to (e?.driver ?: ""), "mob" to (e?.mob ?: ""),
                    "rate" to (e?.rate ?: 0.0).toString(), "adv" to (e?.adv ?: 0.0).toString(),
                    "from" to (e?.from ?: ""), "to" to (e?.to ?: "")
                )) { m ->
                    val n = FormDialog.str(m, "name")
                    if (n.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
                    vm.saveVehicle(Vehicle(id ?: "", n, FormDialog.str(m, "driver"), FormDialog.str(m, "mob"),
                        FormDialog.num(m, "rate"), FormDialog.num(m, "adv"),
                        FormDialog.str(m, "from"), FormDialog.str(m, "to")))
                    requireContext().toast("✅ सेव हो गया")
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
