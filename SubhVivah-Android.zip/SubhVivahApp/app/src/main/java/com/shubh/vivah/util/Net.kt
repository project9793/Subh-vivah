package com.shubh.vivah.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object Net {

    /** Internet available hai ya nahi. */
    fun isOnline(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val net = cm?.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Exception) {
        true   // pata na chale to block na karo
    }

    fun msgOffline(ctx: Context) {
        ctx.toast("📶 इंटरनेट बंद है — मोबाइल डेटा या Wi-Fi चालू करें")
    }
}
