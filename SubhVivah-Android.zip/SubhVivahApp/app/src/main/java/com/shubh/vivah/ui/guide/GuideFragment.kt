package com.shubh.vivah.ui.guide

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.shubh.vivah.databinding.FragmentGuideBinding

class GuideFragment : Fragment() {

    private var _b: FragmentGuideBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentGuideBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { findNavController().navigateUp() }
        b.tvGuide.text = GUIDE
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }

    companion object {
        val GUIDE = """
1. शादी की जानकारी भरें
• सेटिंग्स → विवाह डिटेल में वर-कन्या के नाम, तारीख और बजट भरें।
• यही जानकारी होम स्क्रीन और कार्ड दोनों में दिखती है।
• कार्यक्रम में हल्दी, मेहंदी, तिलक, बारात, विवाह की तारीखें भरें — कार्ड के "मांगलिक कार्यक्रम" में अपने आप आ जाएँगी।

2. मेहमान (निमंत्रण)
• निमंत्रण खोलें → नीचे + बटन।
• नाम, मोबाइल, सदस्य संख्या, पक्ष, पता भरें → सेव।
• हर मेहमान के आगे हरा WhatsApp बटन — न्योता सीधे भेजें।
• RSVP चिप दबाकर "आ रहे / नहीं / पूरा परिवार" बदलें।

3. द्वारदारी (नगद व उपहार)
• द्वारदारी → + द्वारदारी एंट्री।
• मेहमान का नाम, गाँव, कार्यक्रम (पाँवपूजा / आँगन / द्वारदारी), नगद राशि, उपहार।
• ऊपर तीनों कार्यक्रमों की कुल राशि दिखती है।
• "खर्च देखें / जोड़ें" से अलग खर्च भी दर्ज करें।

4. सामान • हलवाई • सजावट • वाहन
• हर सेक्शन में + से नई एंट्री, पेंसिल से बदलें, कूड़ेदान से हटाएँ।
• सामान: नाम, मात्रा, दर — कुल अपने आप।
• हलवाई/सजावट: वेंडर का नाम, मोबाइल, एडवांस और आइटम।

5. डिजिटल कार्ड
• 4 टेम्पलेट में से चुनें → "नमूना भरें" से पूरा कार्ड दिखेगा।
• "जानकारी भरें" में नाम, तारीख, पता, निहाती/शुभचिंतक/दर्शनार्थी/स्वागताधिकारी सूची भरें।
• प्रिंट, JPG, PDF या WhatsApp से भेजें।

6. बारात / घरात Live
• Live Location शुरू करें → GPS चालू रहेगा और मेहमान ID से आपको देख सकेंगे।
• ID WhatsApp पर भेजें। दूसरे फोन पर "ID से देखें" में डालें।
• डेमो ट्रैकिंग से बिना GPS भी दिखा सकते हैं।

7. बैकअप
• सारा डेटा Firebase क्लाउड में सुरक्षित रहता है — दूसरे फोन पर उसी ईमेल से लॉगिन करें।
        """.trimIndent()
    }
}
