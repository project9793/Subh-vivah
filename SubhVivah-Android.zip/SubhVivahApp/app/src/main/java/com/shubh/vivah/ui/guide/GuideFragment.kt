package com.shubh.vivah.ui.guide

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.shubh.vivah.databinding.FragmentGuideBinding

class GuideFragment : Fragment() {

    private var _b: FragmentGuideBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentGuideBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        try { b.tvTitle.text = Lang.t("📖 उपयोग गाइड", "📖 User guide") } catch (e: Exception) { }
        b.btnBack.setOnClickListener { goBack() }
        b.tvGuide.text = GUIDE
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }

    companion object {
        val GUIDE = """
1. शादी की जानकारी भरें
• सेटिंग्स → विवाह डिटेल में वर-कन्या के नाम, तारीख और बजट भरें।
• यही जानकारी होम स्क्रीन और कार्ड दोनों में दिखती है।

2. कार्यक्रम (हल्दी से रिसेप्शन)
• कार्यक्रम में हर रस्म की तारीख, समय और जगह भरें।
• ये कार्ड के "मांगलिक कार्यक्रम" में अपने आप आ जाते हैं।

3. मेहमान (निमंत्रण)
• निमंत्रण खोलें → नीचे + बटन।
• नाम, मोबाइल, सदस्य संख्या, पक्ष, पता भरें → सेव।
• हर मेहमान के आगे हरा WhatsApp बटन — न्योता सीधे भेजें।
• RSVP चिप दबाकर "आ रहे / नहीं / पूरा परिवार" बदलें।

4. द्वारदारी (नगद व उपहार)
• द्वारदारी → + द्वारदारी एंट्री।
• मेहमान का नाम, गाँव, कार्यक्रम (पाँवपूजा / आँगन / द्वारदारी), नगद राशि, उपहार।
• ऊपर तीन रंगीन बटन — हर कार्यक्रम की कुल राशि; दबाने पर वही एंट्री दिखेंगी।
• "खर्च देखें / जोड़ें" से अलग खर्च भी दर्ज करें।

5. सामान (खरीदारी)
• नाम, मात्रा, दर, वेंडर, स्थिति (बाकी/खरीदा), भुगतान (बाकी/हो गया)।
• कुल राशि अपने आप बनती है।

6. हलवाई और सजावट
• वेंडर का नाम, मोबाइल, एडवांस भरें।
• फिर मेन्यू/सामान की लिस्ट जोड़ें — कुल, एडवांस और बाकी दिखेगा।

7. वाहन बुकिंग
• गाड़ी, ड्राइवर, मोबाइल, किराया, एडवांस, कहाँ से कहाँ तक।

8. वर पक्ष / कन्या पक्ष
• परिवार के सदस्य जोड़ें — नाम, रिश्ता, मोबाइल, पता।

9. डिजिटल कार्ड
• 4 टेम्पलेट में से चुनें → "नमूना भरें" से पूरा कार्ड दिखेगा।
• "जानकारी भरें" में नाम, तारीख, पता, निहाती/शुभचिंतक/दर्शनार्थी/स्वागताधिकारी सूची भरें।
• प्रिंट, JPG, PDF या WhatsApp से भेजें।

10. बारात / घरात Live और बैकअप
• Live Location शुरू करें → ID WhatsApp पर भेजें; दूसरे फोन पर "ID से देखें" में डालें।
• डेमो ट्रैकिंग से बिना GPS भी दिखा सकते हैं।
• डेटा Firestore में सुरक्षित रहता है; सेटिंग्स → Export/Import से बैकअप ले सकते हैं।
""".trimIndent()
    }
}
