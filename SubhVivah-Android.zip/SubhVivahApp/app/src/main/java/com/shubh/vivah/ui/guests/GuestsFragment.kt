package com.shubh.vivah.ui.guests

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Calc
import com.shubh.vivah.data.Guest
import com.shubh.vivah.databinding.FragmentGuestsBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.ui.list.Row
import com.shubh.vivah.ui.list.RowAdapter
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class GuestsFragment : Fragment() {

    private var _b: FragmentGuestsBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var data: List<Guest> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentGuestsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { goBack() }
        adapter = RowAdapter(
            onEdit = { i -> edit(data.getOrNull(i)) },
            onDelete = { i ->
                data.getOrNull(i)?.let { g ->
                    requireContext().confirm("हटाएँ?", g.name) { vm.delGuest(g.id) }
                }
            },
            onWa = { i -> data.getOrNull(i)?.let { shareInvite(it) } },
            onChip = { i -> data.getOrNull(i)?.let { cycle(it) } }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter
        b.fab.setOnClickListener { edit(null) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        val c = Calc.of(s)
        data = s.guests
        b.tvTotal.text = c.guestTotal.toString()
        b.tvTitle.text = Lang.t("💌 निमंत्रण", "💌 Invitations")
        b.tvLTotal.text = Lang.t("कुल", "Total")
        b.tvLSent.text = Lang.t("भेजे", "Sent")
        b.tvLBaki.text = Lang.t("भेजना बाकी", "To send")
        b.tvSent.text = c.guestSent.toString()
        b.tvBaki.text = c.guestPend.toString()
        adapter.setItems(data.map { g ->
            Row(
                icon = "👤",
                title = g.name,
                chip = rsvpLabel(g.rsvp),
                meta = buildString {
                    append("📱 "); append(g.mob.orDash())
                    append(" • "); append(if (g.side == "var") "वर पक्ष" else "कन्या पक्ष")
                    if (g.members > 1) { append(" • 👥 "); append(g.members) }
                    // गाँव/पता — ek hi naam ke do mehmaan alag pehchane jayein
                    if (g.addr.isNotBlank()) { append("\n📍 "); append(g.addr) }
                    if (g.sent) append(" • भेजा ✓")
                },
                showWa = true
            )
        })
        b.tvEmpty.visibility = if (data.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun rsvpLabel(r: String) = when (r) {
        "yes" -> "✅ आ रहे"
        "no" -> "❌ नहीं"
        "fam" -> "👨‍👩‍👦 परिवार"
        else -> "❔ बाकी"
    }

    private fun cycle(g: Guest) {
        val next = when (g.rsvp) {
            "" -> "yes"; "yes" -> "no"; "no" -> "fam"; else -> ""
        }
        vm.saveGuest(g.copy(rsvp = next))
    }

    private fun edit(g: Guest?) {
        val fields = listOf(
            Field("name", "मेहमान का नाम *"),
            Field("mob", "मोबाइल नंबर"),
            Field("members", "सदस्य संख्या", FType.NUM),
            Field("side", "पक्ष", FType.SELECT, listOf("var" to "वर पक्ष", "kanya" to "कन्या पक्ष")),
            Field("addr", "पता", FType.MULTI),
            Field("rsvp", "RSVP", FType.SELECT, listOf("" to "बाकी", "yes" to "आ रहे", "no" to "नहीं आ रहे", "fam" to "पूरा परिवार")),
            Field("sent", "निमंत्रण भेजा?", FType.SELECT, listOf("no" to "नहीं", "yes" to "हाँ"))
        )
        val vals = mapOf(
            "name" to (g?.name ?: ""), "mob" to (g?.mob ?: ""), "members" to (g?.members ?: 1L).toString(),
            "side" to (g?.side ?: "var"), "addr" to (g?.addr ?: ""), "rsvp" to (g?.rsvp ?: ""),
            "sent" to (if (g?.sent == true) "yes" else "no")
        )
        FormDialog.show(requireContext(), if (g == null) "मेहमान जोड़ें" else "मेहमान बदलें", fields, vals) { m ->
            val name = FormDialog.str(m, "name")
            if (name.isBlank()) { requireContext().toast("नाम ज़रूरी है"); return@show }
            vm.saveGuest(
                Guest(
                    id = g?.id ?: "",
                    name = name,
                    mob = FormDialog.str(m, "mob"),
                    members = FormDialog.long(m, "members").coerceAtLeast(1L),
                    side = FormDialog.str(m, "side").ifBlank { "var" },
                    addr = FormDialog.str(m, "addr"),
                    rsvp = FormDialog.str(m, "rsvp"),
                    sent = FormDialog.str(m, "sent") == "yes"
                )
            )
            requireContext().toast("✅ सेव हो गया")
        }
    }

    /** WhatsApp par card ka PDF bhejta hai (message nahi). */
    private fun shareInvite(g: Guest) {
        try {
            val st = vm.state.value
            com.shubh.vivah.util.CardPdf.share(requireContext(), st.w.card, st.w.events)
            if (!g.sent) vm.saveGuest(g.copy(sent = true))
        } catch (e: Exception) {
            requireContext().toast("PDF नहीं बन सका — पहले डिजिटल कार्ड में अपनी जानकारी भरें")
        }
    }

    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}

