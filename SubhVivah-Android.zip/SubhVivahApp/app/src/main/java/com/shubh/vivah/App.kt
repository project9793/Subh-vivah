package com.shubh.vivah

import android.app.Application
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.io.File

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        // Capture any crash into a file so the user can send us the real stack trace.
        try {
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                try {
                    File(filesDir, "last_crash.txt").writeText(
                        Log.getStackTraceString(error)
                    )
                } catch (ignored: Exception) { }
                previous?.uncaughtException(thread, error)
            }
        } catch (ignored: Exception) { }

        // Language: sirf tab lagao jab user ne khud chuni ho (startup me recreate na ho)
        try {
            val chosen = getSharedPreferences("sv", MODE_PRIVATE).getString("lang", null)
            if (chosen != null) {
                val tag = if (chosen == "en") "en" else "hi"
                if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != tag) {
                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
                }
            }
        } catch (ignored: Exception) { }
    }

    companion object {
        fun crashFile(app: Application): File = File(app.filesDir, "last_crash.txt")
    }
}
