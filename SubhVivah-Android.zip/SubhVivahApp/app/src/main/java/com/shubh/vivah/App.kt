package com.shubh.vivah

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences("sv", MODE_PRIVATE)
        val lang = prefs.getString("lang", "hi") ?: "hi"
        val tag = if (lang == "en") "en" else "hi"
        if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != tag) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        }
    }
}
