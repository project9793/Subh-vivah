package com.shubh.vivah

import android.app.Application
import android.util.Log
import java.io.File

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        // Capture any crash into a file so the user can send us the real stack trace.
        try {
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                try {
                    File(filesDir, "last_crash.txt").writeText(
                        Log.getStackTraceString(error)
                    )
                } catch (ignored: Exception) { }
                previous?.uncaughtException(thread, error)
            }
        } catch (ignored: Exception) { }
    }

    companion object {
        fun crashFile(app: Application): File = File(app.filesDir, "last_crash.txt")
    }
}
