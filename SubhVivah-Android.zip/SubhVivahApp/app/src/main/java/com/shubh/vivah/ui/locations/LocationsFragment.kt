package com.shubh.vivah.ui.locations

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.shubh.vivah.data.AppState
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Locs
import com.shubh.vivah.databinding.FragmentLocationsBinding
import com.shubh.vivah.databinding.ItemSettingBinding
import com.shubh.vivah.ui.FType
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.util.Share
import com.shubh.vivah.util.showIf
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class LocationsFragment : Fragment() {

    private var _b: FragmentLocationsBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()

    private data class Place(val key: String, val icon: String, val label: String)

    private val places = listOf(
        Place("venue", "🎪", "विवाह स्थल"),
        Place("bride", "👰", "कन्या का घर"),
        Place("groom", "🤵", "वर का घर"),
        Place("bstart", "🚩", "बारात शुरू"),
        Place("bdest", "🎯", "बारात गंतव्य"),
        Place("gharati", "🏠", "घरात/घराती")
    )

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentLocationsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { goBack() }
        try { b.tvTitle.text = Lang.t("📍 लोकेशन", "📍 Locations") } catch (e: Exception) { }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }
    }

    private fun addr(l: Locs, key: String): String = when (key) {
        "venue" -> l.venue; "bride" -> l.bride; "groom" -> l.groom
        "bstart" -> l.bstart; "bdest" -> l.bdest; else -> l.gharati
    }

    private fun withAddr(l: Locs, key: String, value: String): Locs = when (key) {
        "venue" -> l.copy(venue = value); "bride" -> l.copy(bride = value)
        "groom" -> l.copy(groom = value); "bstart" -> l.copy(bstart = value)
        "bdest" -> l.copy(bdest = value); else -> l.copy(gharati = value)
    }

    private fun render(s: AppState) {
        if (!isAdded) return
        b.box.removeAllViews()
        places.forEach { p ->
            val row = ItemSettingBinding.inflate(layoutInflater, b.box, false)
            val value = addr(s.w.locs, p.key)
            row.tvIcon.text = p.icon
            row.tvTitle.text = p.label
            row.tvSub.text = value.ifBlank { "पता जोड़ें" }
            row.tvArrow.text = if (value.isBlank()) "＋" else "🧭"
            row.root.setOnClickListener {
                if (value.isBlank()) edit(p.key, s.w.locs) else Share.maps(requireContext(), value)
            }
            row.root.setOnLongClickListener { edit(p.key, s.w.locs); true }
            b.box.addView(row.root)
        }
        b.tvNote.showIf(true)
    }

    private fun edit(key: String, l: Locs) {
        FormDialog.show(requireContext(), "पता / लोकेशन",
            listOf(Field("addr", "पूरा पता (Google Maps में खुलेगा)", FType.MULTI)),
            mapOf("addr" to addr(l, key))
        ) { m ->
            vm.saveWedding(vm.state.value.w.copy(locs = withAddr(l, key, FormDialog.str(m, "addr"))))
            requireContext().toast("✅ सेव हो गया")
        }
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
