package com.shubh.vivah.ui.track

import com.shubh.vivah.util.*

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentTrackBinding
import com.shubh.vivah.databinding.ItemSettingBinding
import com.shubh.vivah.util.Share
import com.shubh.vivah.util.toast
import kotlin.random.Random

class TrackFragment : Fragment() {

    private var _b: FragmentTrackBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private var type = "BARAAT"
    private var demoHandler: Handler? = null

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) startLive()
        else requireContext().toast("GPS अनुमति ज़रूरी है — सेटिंग्स से दें")
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentTrackBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        type = arguments?.getString("type") ?: "BARAAT"
        b.btnBack.setOnClickListener { findNavController().navigateUp() }
        b.tvTitle.text = if (type == "BARAAT") "🚗 बारात Live Location" else "🏠 घरात/घराती Live Location"

        b.btnStart.setOnClickListener {
            val fine = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            if (fine == PackageManager.PERMISSION_GRANTED) startLive()
            else perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        b.btnDemo.setOnClickListener { startDemo() }
        b.btnView.setOnClickListener {
            val id = b.etId.text?.toString()?.trim().orEmpty()
            if (id.isBlank()) { requireContext().toast("Tracking ID डालें"); return@setOnClickListener }
            val args = Bundle().apply { putString("id", id) }
            findNavController().navigate(com.shubh.vivah.R.id.trackViewFragment, args)
        }

        watchTracks()
    }

    private fun newId(): String {
        val pfx = if (type == "BARAAT") "VM" else "GHR"
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return pfx + (1..5).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    }

    private fun startLive() {
        val id = newId()
        val w = vm.state.value.w
        val dest = if (type == "BARAAT") w.locs.bdest else w.locs.gharati
        TrackService.start(requireContext(), id, type, dest)
        requireContext().toast("▶️ Live शुरू — ID: " + id)
    }

    private fun startDemo() {
        val id = newId()
        val w = vm.state.value.w
        val dest = if (type == "BARAAT") w.locs.bdest else w.locs.gharati
        Repo.tracks().child(id).updateChildren(mapOf(
            "type" to type, "ownerUid" to Repo.auth.currentUser?.uid.orEmpty(),
            "destName" to dest, "active" to true, "ts" to System.currentTimeMillis()
        ))
        val h = Handler(Looper.getMainLooper())
        demoHandler = h
        var step = 0
        val baseLat = 21.1938
        val baseLng = 81.3509
        val r = object : Runnable {
            override fun run() {
                step++
                val lat = baseLat + step * 0.0025
                val lng = baseLng + step * 0.0018
                Repo.tracks().child(id).updateChildren(mapOf(
                    "lat" to lat, "lng" to lng, "ts" to System.currentTimeMillis(), "active" to true
                ))
                if (step >= 12) {
                    Repo.tracks().child(id).child("active").setValue(false)
                    h.removeCallbacks(this)
                } else h.postDelayed(this, 2000)
            }
        }
        h.postDelayed(r, 500)
        requireContext().toast("🎮 डेमो ट्रैकिंग शुरू — ID: " + id)
    }

    private fun watchTracks() {
        Repo.tracks().addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                if (!isAdded) return
                val uid = Repo.auth.currentUser?.uid
                b.box.removeAllViews()
                var n = 0
                snap.children.forEach { c ->
                    if (c.child("ownerUid").getValue(String::class.java) != uid) return@forEach
                    if (c.child("type").getValue(String::class.java) != type) return@forEach
                    n++
                    val id = c.key ?: return@forEach
                    val active = c.child("active").getValue(Boolean::class.java) == true
                    val dest = c.child("destName").getValue(String::class.java).orEmpty()
                    val lat = c.child("lat").getValue(Double::class.java)
                    val lng = c.child("lng").getValue(Double::class.java)
                    val row = ItemSettingBinding.inflate(layoutInflater, b.box, false)
                    row.tvIcon.text = if (active) "🟢" else "⚪"
                    row.tvTitle.text = "ID: " + id
                    row.tvSub.text = (if (active) "लाइव" else "बंद") +
                        (if (dest.isNotBlank()) " • 🎯 " + dest else "") +
                        (if (lat != null && lng != null) "\n📍 " + String.format("%.4f, %.4f", lat, lng) else "")
                    row.tvArrow.text = if (active) "⏹" else "🗑"
                    row.root.setOnClickListener {
                        if (active) {
                            TrackService.stop(requireContext(), id)
                            requireContext().toast("⏹ बंद कर दिया")
                        } else {
                            Repo.tracks().child(id).removeValue()
                            requireContext().toast("🗑 हटा दिया")
                        }
                    }
                    row.root.setOnLongClickListener {
                        Share.whatsapp(requireContext(),
                            "📍 " + (if (type == "BARAAT") "बारात" else "घरात") + " Live Location देखें\n" +
                                "शुभ विवाह ऐप → बारात Live → ID: " + id)
                        true
                    }
                    b.box.addView(row.root)
                }
                b.tvEmpty.visibility = if (n == 0) View.VISIBLE else View.GONE
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    override fun onDestroyView() {
        demoHandler?.removeCallbacksAndMessages(null)
        super.onDestroyView()
        _b = null
    }
}
