package com.shubh.vivah.ui.track

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentTrackBinding
import com.shubh.vivah.databinding.ItemSettingBinding
import com.shubh.vivah.util.Share
import com.shubh.vivah.util.toast
import kotlin.random.Random

class TrackFragment : Fragment() {

    private var _b: FragmentTrackBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private var type = "BARAAT"

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) startLive()
        else requireContext().toast("GPS अनुमति ज़रूरी है — सेटिंग्स से दें")
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentTrackBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        type = arguments?.getString("type") ?: "BARAAT"
        b.btnBack.setOnClickListener { goBack() }
        b.tvTitle.text = if (type == "BARAAT") Lang.t("🚗 बारात Live Location","🚗 Baraat live location") else Lang.t("🏠 घरात/घराती Live Location","🏠 Gharati live location")

        b.btnStart.setOnClickListener {
            val fine = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            if (fine == PackageManager.PERMISSION_GRANTED) startLive()
            else perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        b.btnMyLoc.setOnClickListener { showMyLocation() }
        b.tvMyLoc.setOnClickListener {
            val txt = b.tvMyLoc.text?.toString().orEmpty()
            if (txt.contains(",")) {
                val parts = txt.replace("📍", "").trim().split(",")
                if (parts.size == 2) {
                    val lat = parts[0].trim(); val lng = parts[1].trim()
                    startActivity(android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("geo:$lat,$lng?q=$lat,$lng")
                    ))
                }
            }
        }
        b.btnView.setOnClickListener {
            val id = b.etId.text?.toString()?.trim().orEmpty()
            if (id.isBlank()) { requireContext().toast("Tracking ID डालें"); return@setOnClickListener }
            val args = Bundle().apply { putString("id", id) }
            findNavController().navigate(com.shubh.vivah.R.id.trackViewFragment, args)
        }

        watchTracks()
    }

    private fun newId(): String {
        val pfx = if (type == "BARAAT") "VM" else "GHR"
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return pfx + (1..5).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    }

    private fun startLive() {
        val id = newId()
        val w = vm.state.value.w
        val dest = if (type == "BARAAT") w.locs.bdest else w.locs.gharati
        TrackService.start(requireContext(), id, type, dest)
        requireContext().toast("▶️ Live शुरू — ID: " + id)
    }

    /** GPS se apni abhi ki location dikhata hai (live share karne ki zaroorat nahi). */
    private fun showMyLocation() {
        val fine = androidx.core.content.ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (fine != PackageManager.PERMISSION_GRANTED) {
            perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            return
        }
        b.tvMyLoc.text = "⏳ लोकेशन खोजी जा रही है…"
        try {
            val fused = com.google.android.gms.location.LocationServices
                .getFusedLocationProviderClient(requireActivity())
            fused.getCurrentLocation(com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc ->
                    if (!isAdded) return@addOnSuccessListener
                    if (loc != null) {
                        b.tvMyLoc.text = "📍 " + String.format("%.5f", loc.latitude) + ", " + String.format("%.5f", loc.longitude)
                    } else {
                        b.tvMyLoc.text = "❌ लोकेशन नहीं मिली — GPS चालू करें"
                    }
                }
                .addOnFailureListener {
                    if (isAdded) b.tvMyLoc.text = "❌ लोकेशन नहीं मिली — GPS चालू करें"
                }
        } catch (e: Exception) {
            b.tvMyLoc.text = "❌ लोकेशन नहीं मिली"
        }
    }

    private fun watchTracks() {
        Repo.tracks().addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                if (!isAdded) return
                val uid = Repo.auth.currentUser?.uid
                b.box.removeAllViews()
                var n = 0
                snap.children.forEach { c ->
                    if (c.child("ownerUid").getValue(String::class.java) != uid) return@forEach
                    if (c.child("type").getValue(String::class.java) != type) return@forEach
                    n++
                    val id = c.key ?: return@forEach
                    val active = c.child("active").getValue(Boolean::class.java) == true
                    val dest = c.child("destName").getValue(String::class.java).orEmpty()
                    val lat = c.child("lat").getValue(Double::class.java)
                    val lng = c.child("lng").getValue(Double::class.java)
                    val row = ItemSettingBinding.inflate(layoutInflater, b.box, false)
                    row.tvIcon.text = if (active) "🟢" else "⚪"
                    row.tvTitle.text = "ID: " + id
                    row.tvSub.text = (if (active) "लाइव" else "बंद") +
                        (if (dest.isNotBlank()) " • 🎯 " + dest else "") +
                        (if (lat != null && lng != null) "\n📍 " + String.format("%.4f, %.4f", lat, lng) else "")
                    row.tvArrow.text = if (active) "⏹" else "🗑"
                    row.root.setOnClickListener {
                        if (active) {
                            TrackService.stop(requireContext(), id)
                            requireContext().toast("⏹ बंद कर दिया")
                        } else {
                            Repo.tracks().child(id).removeValue()
                            requireContext().toast("🗑 हटा दिया")
                        }
                    }
                    row.root.setOnLongClickListener {
                        Share.whatsapp(requireContext(),
                            "📍 " + (if (type == "BARAAT") "बारात" else "घरात") + " Live Location देखें\n" +
                                "शुभ विवाह ऐप → बारात Live → ID: " + id)
                        true
                    }
                    b.box.addView(row.root)
                }
                b.tvEmpty.visibility = if (n == 0) View.VISIBLE else View.GONE
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
