package com.shubh.vivah.ui.track

import com.shubh.vivah.util.*

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.FragmentTrackViewBinding
import com.shubh.vivah.util.toast
import kotlin.math.*

class TrackViewFragment : Fragment() {

    private var _b: FragmentTrackViewBinding? = null
    private val b get() = _b!!
    private var currentId: String = ""

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentTrackViewBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { goBack() }
        b.btnGo.setOnClickListener {
            val id = b.etId.text?.toString()?.trim().orEmpty()
            if (id.isBlank()) { requireContext().toast("Tracking ID डालें"); return@setOnClickListener }
            listen(id)
        }
        val preset = arguments?.getString("id")
        if (!preset.isNullOrBlank()) { b.etId.setText(preset); listen(preset) }
    }

    private fun listen(id: String) {
        currentId = id
        Repo.tracks().child(id).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                if (!isAdded) return
                if (!snap.exists()) {
                    b.tvStatus.text = "❌ यह ID नहीं मिली"
                    return
                }
                val active = snap.child("active").getValue(Boolean::class.java) == true
                val type = snap.child("type").getValue(String::class.java).orEmpty()
                val dest = snap.child("destName").getValue(String::class.java).orEmpty()
                val lat = snap.child("lat").getValue(Double::class.java)
                val lng = snap.child("lng").getValue(Double::class.java)
                val ts = snap.child("ts").getValue(Long::class.java) ?: 0L

                b.tvStatus.text = (if (active) "🟢 लाइव" else "⚪ बंद") + " • " +
                    (if (type == "BARAAT") "बारात" else "घरात/घराती") + " • ID: " + id
                b.tvDest.text = if (dest.isBlank()) "🎯 गंतव्य तय नहीं" else "🎯 गंतव्य: " + dest
                if (lat != null && lng != null) {
                    b.tvPos.text = "📍 " + String.format("%.5f, %.5f", lat, lng)
                    val age = (System.currentTimeMillis() - ts) / 1000
                    b.tvAge.text = "अंतिम अपडेट: " + age + " सेकंड पहले"
                    b.btnMaps.setOnClickListener {
                        startActivity(
                            android.content.Intent(
                                android.content.Intent.ACTION_VIEW,
                                android.net.Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng)
                            )
                        )
                    }
                } else {
                    b.tvPos.text = "📍 स्थान अभी नहीं मिला"
                    b.tvAge.text = ""
                }
            }

            override fun onCancelled(error: DatabaseError) {
                b.tvStatus.text = "⚠️ " + (error.message ?: "कनेक्ट नहीं")
            }
        })
    }

    private fun haversine(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLng / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
