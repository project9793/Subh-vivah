package com.shubh.vivah.util

import android.content.Context

/**
 * Ek hi language switch poore app ke liye.
 * mode = "hi" (sab Hindi) | "en" (sab English) | "both" (Hindi + English)
 */
object Lang {

    @Volatile
    var mode: String = "hi"

    fun load(ctx: Context) {
        mode = ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).getString("lang", "hi") ?: "hi"
    }

    fun save(ctx: Context, m: String) {
        mode = m
        ctx.getSharedPreferences("sv", Context.MODE_PRIVATE).edit().putString("lang", m).apply()
    }

    /** hi / en / both ke hisaab se text chuno */
    fun t(hi: String, en: String): String = when (mode) {
        "en" -> en
        "both" -> if (en.isBlank()) hi else "$hi / $en"
        else -> hi
    }

    fun isEn(): Boolean = mode == "en"
}
