package com.shubh.vivah.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import com.shubh.vivah.R
import com.shubh.vivah.data.CardData
import com.shubh.vivah.data.EvEvent
import com.shubh.vivah.ui.card.TraditionalCard
import java.io.File
import java.io.FileOutputStream

/** Digital card ka PDF banata hai aur WhatsApp par bhejta hai (message nahi, file). */
object CardPdf {

    private const val W = 794   // A4 width in px @96dpi

    fun makeFile(ctx: Context, cd: CardData, events: List<EvEvent>): File {
        TraditionalCard.init(ctx)
        val dir = File(ctx.cacheDir, "card")
        dir.mkdirs()
        val f = File(dir, "shubh-vivah-nimantran.pdf")

        if (cd.tpl == 4) {
            TraditionalCard.pdf(f, cd, events)
            return f
        }
        val bmp = renderBitmap(ctx, cd, events)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, 1).create())
        page.canvas.drawBitmap(bmp, 0f, 0f, null)
        doc.finishPage(page)
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun share(ctx: Context, cd: CardData, events: List<EvEvent>) {
        val f = makeFile(ctx, cd, events)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val wa = Intent(base).setPackage("com.whatsapp")
        try {
            ctx.startActivity(wa)
        } catch (e: Exception) {
            ctx.startActivity(Intent.createChooser(base, "निमंत्रण PDF भेजें"))
        }
    }

    // ---------- templates 1-3 ke liye: layout ko bitmap me draw karo ----------

    private fun renderBitmap(ctx: Context, cd: CardData, events: List<EvEvent>): Bitmap {
        val layoutId = when (cd.tpl) {
            2 -> R.layout.card_tpl_2
            3 -> R.layout.card_tpl_3
            else -> R.layout.card_tpl_1
        }
        val host = FrameLayout(ctx)
        val view = LayoutInflater.from(ctx).inflate(layoutId, host, false)
        host.addView(view)
        bind(view, cd, events)

        val widthSpec = View.MeasureSpec.makeMeasureSpec(W, View.MeasureSpec.EXACTLY)
        val heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        host.measure(widthSpec, heightSpec)
        host.layout(0, 0, host.measuredWidth, host.measuredHeight)

        val bmp = Bitmap.createBitmap(
            host.measuredWidth.coerceAtLeast(W),
            host.measuredHeight.coerceAtLeast(W),
            Bitmap.Config.ARGB_8888
        )
        val c = Canvas(bmp)
        c.drawColor(0xFFFBE7DB.toInt())
        host.draw(c)
        return bmp
    }

    private fun bind(root: View, cd: CardData, events: List<EvEvent>) {
        fun set(name: String, text: String) {
            val id = root.resources.getIdentifier(name, "id", root.context.packageName)
            if (id != 0) root.findViewById<TextView>(id)?.text = text
        }
        set("tvGanesh", "॥ श्री गणेशाय नमः ॥")
        set("tvGroomName", (cd.groomPre + " " + cd.groom).trim())
        set("tvBrideName", (cd.bridePre + " " + cd.bride).trim())
        set("tvGroomFamily", "सुपुत्र " + cd.groomF + (if (cd.groomGF.isNotBlank()) "\nपौत्र " + cd.groomGF else ""))
        set("tvBrideFamily", "सुपुत्री " + cd.brideF + (if (cd.brideGF.isNotBlank()) "\nपौत्री " + cd.brideGF else ""))
        set("tvGroomVill", listOf(cd.groomVill, cd.groomDist).filter { it.isNotBlank() }.joinToString(", "))
        set("tvBrideVill", listOf(cd.brideVill, cd.brideDist).filter { it.isNotBlank() }.joinToString(", "))
        set("tvFam", if (cd.fam.isNotBlank()) "श्री " + cd.fam + " परिवार की ओर से" else "")
        set("tvDate", cd.date.dmy())
        set("tvTime", cd.time)
        set("tvVenue", cd.venue)
        set("tvAddr", cd.addr)
        set("tvMsg", cd.msg)
        set("tvSender", if (cd.sender.isNotBlank()) "निवेदक — " + cd.sender + "\n" + cd.village + " " + cd.dist else "")
        set("tvContact", if (cd.contact.isNotBlank()) "📞 " + cd.contact else "")
        set("tvListShubh", cd.listShubh)
        set("tvListNihati", cd.listNihati)
        set("tvListDarshan", cd.listDarshan)
        set("tvListSwagat", cd.listSwagat)
        set("tvListVinit", cd.listVinit)

        val en = cd.lang == "en"
        set("tvLblEvents", if (en) "— Wedding Ceremonies —" else "— मांगलिक कार्यक्रम —")
        set("tvLblShubh", if (en) "— Well-wishers —" else "— शुभचिंतक —")
        set("tvLblNihati", if (en) "— Relatives —" else "— निहाती —")
        set("tvLblDarshan", if (en) "— Blessings —" else "— दर्शनार्थी —")
        set("tvLblSwagat", if (en) "— Hosts —" else "— स्वागताधिकारी —")
        set("tvLblVinit", if (en) "— With regards —" else "— विनीत —")

        val ev = events.filter { it.name.isNotBlank() }.joinToString("\n") { e ->
            e.icon + " " + e.name + (if (e.date.isNotBlank()) " — " + e.date.dmy() + " " + e.time else "")
        }
        set("tvEvents", ev)
    }
}
