package com.shubh.vivah.ui

import com.shubh.vivah.util.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.shubh.vivah.R
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.ActivityMainBinding
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.showIf
import com.shubh.vivah.util.Lang
import com.shubh.vivah.util.Themes

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(Themes.currentStyle(this))
        super.onCreate(savedInstanceState)
        try {
            setup()
        } catch (t: Throwable) {
            fatal(t)
        }
    }

    private fun fatal(t: Throwable) {
        val text = android.util.Log.getStackTraceString(t)
        try { java.io.File(filesDir, "last_crash.txt").writeText(text) } catch (ignored: Exception) { }
        try {
            val tv = android.widget.TextView(this).apply {
                this.text = text
                textSize = 11f
                setPadding(24, 70, 24, 24)
                setTextIsSelectable(true)
            }
            setContentView(android.widget.ScrollView(this).apply { addView(tv) })
        } catch (ignored: Exception) { }
    }

    private var bottomInset = 0

    /** Bottom nav dikh raha ho to wo khud inset sambhalta hai; chhupa ho to screen ko jagah deni padti hai,
     *  warna FAB system navigation bar ke neeche chhup jata hai. */
    private fun applyBottomSpace() {
        try {
            val pad = if (b.bottomNav.visibility == View.VISIBLE) 0 else bottomInset
            b.navHost.setPadding(0, 0, 0, pad)
        } catch (ignored: Exception) { }
    }

    private fun setup() {
        if (Repo.auth.currentUser == null) {
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // Android 15 (targetSdk 35) edge-to-edge handling.
        // Root sirf status bar (top) ka padding leta hai; bottom ka hisaab bottom nav khud karta hai,
        // warna bottom nav double padding se bahut upar chala jata hai.
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            bottomInset = bars.bottom
            v.setPadding(bars.left, bars.top, bars.right, 0)
            applyBottomSpace()
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(b.bottomNav) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val host = supportFragmentManager.findFragmentById(R.id.navHost) as NavHostFragment
        val nav = host.navController
        b.bottomNav.setupWithNavController(nav)

        val menu = b.bottomNav.menu
        menu.findItem(R.id.homeFragment)?.title = Lang.t("होम", "Home")
        menu.findItem(R.id.eventsFragment)?.title = Lang.t("कार्यक्रम", "Events")
        menu.findItem(R.id.guestsFragment)?.title = Lang.t("निमंत्रण", "Invites")
        menu.findItem(R.id.locationsFragment)?.title = Lang.t("लोकेशन", "Location")
        menu.findItem(R.id.settingsFragment)?.title = Lang.t("सेटिंग्स", "Settings")

        val topLevel = setOf(
            R.id.homeFragment, R.id.eventsFragment, R.id.guestsFragment,
            R.id.locationsFragment, R.id.settingsFragment
        )
        nav.addOnDestinationChangedListener { _, dest, _ ->
            b.bottomNav.showIf(dest.id in topLevel)
            applyBottomSpace()
        }
        vm.start()
    }
}
