package com.shubh.vivah.ui

import com.shubh.vivah.util.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.shubh.vivah.R
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.ActivityMainBinding
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.showIf

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setup()
        } catch (t: Throwable) {
            fatal(t)
        }
    }

    private fun fatal(t: Throwable) {
        val text = android.util.Log.getStackTraceString(t)
        try { java.io.File(filesDir, "last_crash.txt").writeText(text) } catch (ignored: Exception) { }
        try {
            val tv = android.widget.TextView(this).apply {
                this.text = text
                textSize = 11f
                setPadding(24, 70, 24, 24)
                setTextIsSelectable(true)
            }
            setContentView(android.widget.ScrollView(this).apply { addView(tv) })
        } catch (ignored: Exception) { }
    }

    private fun setup() {
        if (Repo.auth.currentUser == null) {
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val host = supportFragmentManager.findFragmentById(R.id.navHost) as NavHostFragment
        val nav = host.navController
        b.bottomNav.setupWithNavController(nav)

        val topLevel = setOf(
            R.id.homeFragment, R.id.eventsFragment, R.id.guestsFragment,
            R.id.locationsFragment, R.id.settingsFragment
        )
        nav.addOnDestinationChangedListener { _, dest, _ ->
            b.bottomNav.showIf(dest.id in topLevel)
        }
        vm.start()
    }
}
