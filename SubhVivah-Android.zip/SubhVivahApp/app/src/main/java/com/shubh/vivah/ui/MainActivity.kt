package com.shubh.vivah.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.shubh.vivah.R
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.ActivityMainBinding
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.showIf

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Repo.auth.currentUser == null) {
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val host = supportFragmentManager.findFragmentById(R.id.navHost) as NavHostFragment
        val nav = host.navController
        b.bottomNav.setupWithNavController(nav)

        val topLevel = setOf(
            R.id.homeFragment, R.id.eventsFragment, R.id.guestsFragment,
            R.id.locationsFragment, R.id.settingsFragment
        )
        nav.addOnDestinationChangedListener { _, dest, _ ->
            b.bottomNav.showIf(dest.id in topLevel)
        }
        vm.start()
    }
}
