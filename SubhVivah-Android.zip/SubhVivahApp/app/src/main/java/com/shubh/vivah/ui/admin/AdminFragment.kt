package com.shubh.vivah.ui.admin

import com.shubh.vivah.util.*
import com.shubh.vivah.util.Lang
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.Wedding
import com.shubh.vivah.data.User
import com.shubh.vivah.databinding.FragmentAdminBinding
import com.shubh.vivah.ui.list.Row
import com.shubh.vivah.ui.list.RowAdapter
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class AdminFragment : Fragment() {

    private var _b: FragmentAdminBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var users: List<User> = emptyList()
    private var cards = 0L
    private var weddingsCount = 0
    private var liveTracks = 0

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentAdminBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        try { b.tvTitle.text = Lang.t("🛡️ Admin Panel", "🛡️ Admin panel") } catch (e: Exception) { }
        b.btnBack.setOnClickListener { goBack() }
        adapter = RowAdapter(
            onEdit = { i -> users.getOrNull(i)?.let { toggle(it) } },
            onDelete = { i -> users.getOrNull(i)?.let { u ->
                requireContext().confirm("हटाएँ?", u.fullName) {
                    Repo.userDoc(u.id).delete(); requireContext().toast("🗑 हटा दिया")
                } } }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter

        Repo.db.collection("weddings").addSnapshotListener { snap, _ ->
            if (snap != null) {
                val list = snap.toObjects(Wedding::class.java)
                weddingsCount = list.size
                cards = list.sumOf { it.cardCount }
                render()
            }
        }
        Repo.tracks().addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snap: DataSnapshot) {
                liveTracks = snap.children.count { it.child("active").getValue(Boolean::class.java) == true }
                render()
            }
            override fun onCancelled(error: DatabaseError) {}
        })
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                Repo.db.collection("users").addSnapshotListener { snap, _ ->
                    if (snap != null) {
                        users = snap.toObjects(User::class.java)
                        render()
                    }
                }
            }
        }
    }

    private fun render() {
        if (!isAdded) return
        b.t1.text = users.size.toString(); b.k1.text = "Users"
        b.t2.text = users.count { !it.blocked }.toString(); b.k2.text = "Active"
        b.t3.text = weddingsCount.toString(); b.k3.text = "Weddings"
        b.t4.text = cards.toString(); b.k4.text = "Digital Cards"
        b.t5.text = users.count { it.blocked }.toString(); b.k5.text = "Blocked"
        b.t6.text = liveTracks.toString(); b.k6.text = "Live Tracks"
        adapter.setItems(users.map { u ->
            Row(
                icon = if (u.blocked) "🚫" else "👤",
                title = u.fullName,
                chip = if (u.blocked) "Blocked" else "Active",
                meta = "📱 ${u.mobile} • 📧 ${u.email}" + (if (u.admin) " • 🛡️ Admin" else "")
            )
        })
    }

    private fun toggle(u: User) {
        Repo.userDoc(u.id).update("blocked", !u.blocked)
            .addOnSuccessListener { requireContext().toast(if (u.blocked) "✅ अनब्लॉक" else "🚫 ब्लॉक") }
    }


    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) {
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
        } catch (e: Exception) {
            try { requireActivity().onBackPressedDispatcher.onBackPressed() } catch (ignored: Exception) { }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
