package com.shubh.vivah.ui.admin

import com.shubh.vivah.util.*

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.data.User
import com.shubh.vivah.databinding.FragmentAdminBinding
import com.shubh.vivah.ui.list.Row
import com.shubh.vivah.ui.list.RowAdapter
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch

class AdminFragment : Fragment() {

    private var _b: FragmentAdminBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()
    private lateinit var adapter: RowAdapter
    private var users: List<User> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentAdminBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        b.btnBack.setOnClickListener { findNavController().navigateUp() }
        adapter = RowAdapter(
            onEdit = { i -> users.getOrNull(i)?.let { toggle(it) } },
            onDelete = { i -> users.getOrNull(i)?.let { u ->
                requireContext().confirm("हटाएँ?", u.fullName) {
                    Repo.userDoc(u.id).delete(); requireContext().toast("🗑 हटा दिया")
                } } }
        )
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                Repo.db.collection("users").addSnapshotListener { snap, _ ->
                    if (snap != null) {
                        users = snap.toObjects(User::class.java)
                        render()
                    }
                }
            }
        }
    }

    private fun render() {
        if (!isAdded) return
        b.t1.text = users.size.toString(); b.k1.text = "Total Users"
        b.t2.text = users.count { !it.blocked }.toString(); b.k2.text = "Active Users"
        b.t3.text = users.count { it.admin }.toString(); b.k3.text = "Admins"
        adapter.setItems(users.map { u ->
            Row(
                icon = if (u.blocked) "🚫" else "👤",
                title = u.fullName,
                chip = if (u.blocked) "Blocked" else "Active",
                meta = "📱 ${u.mobile} • 📧 ${u.email}" + (if (u.admin) " • 🛡️ Admin" else "")
            )
        })
    }

    private fun toggle(u: User) {
        Repo.userDoc(u.id).update("blocked", !u.blocked)
            .addOnSuccessListener { requireContext().toast(if (u.blocked) "✅ अनब्लॉक" else "🚫 ब्लॉक") }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
