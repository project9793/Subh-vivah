# शुभ विवाह — requirements / observations log

Har screenshot se jo point aaya, wo yahan likha ja raha hai taaki build ke saath rahe.

## द्वारदारी
- Category ka kram: **द्वारदारी → पाँवपूजा → आँगन** (dropdown me bhi, teen rangeen chips me bhi).
- Naya record ka default category: द्वारदारी.
- Top par "कुल द्वारदारी (नगद)" gradient card + 3 chips + "➕ द्वारदारी एंट्री जोड़ें" + "🧾 खर्च देखें / जोड़ें".

## Fixes done
- Edit par duplicate entry banti thi → ab document id record ke andar save hoti hai (update hota hai).
- Back (←) button har screen par kaam karta hai (48dp tap area + ripple).
- Android 15 edge-to-edge: status bar / nav bar ke neeche content nahi jata (insets padding).
- Form dialog: BottomSheet ki jagah simple bottom Dialog; dropdown field par radio-choice list.
- Language switch: `Lang` helper — Hindi/English poore app me (nav, titles, home cards, tiles, settings).
- Traditional 3-page card with artwork (ganesh, border strip, kalash, dholak, घोड़ा) + Yatra One font.
- Crash guard: startup error hone par error text screen par dikhta hai (copy karne layak).

## Pending (user ke batane par)
- Forms ke field labels ka English version.
- Baaki screens ka design parity (home cards, halwai/decor, family, location, budget polish).
- Har build me version number badhana (taaki pata chale kaunsa build installed hai).
