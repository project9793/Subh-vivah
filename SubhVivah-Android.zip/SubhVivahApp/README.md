# 🌸 शुभ विवाह (Shubh Vivah) — Android (Kotlin + XML + Firebase)

Native Android app for planning one Indian wedding end-to-end: guests & RSVP, shopping,
द्वारदारी, halwai, decoration, vehicles, both families, budget, live baraat tracking and a
printable digital invitation card (4 templates).

- **Package / applicationId:** `com.shubh.vivah` (already matches the uploaded `google-services.json`)
- **Firebase project:** `subh-vivah-a3875` (project number 260009711526)
- **Stack:** Kotlin · XML layouts + ViewBinding · Material 3 · MVVM · Navigation Component
- **Backend:** Firebase Auth, Cloud Firestore, Realtime Database (live location), Storage (card images)
- **SDK:** minSdk 24 · target/compileSdk 35 · Java 17

---

## 1. Open the project

1. Android Studio (Ladybug / 2024.2 or newer) → **Open** → select this folder.
2. The Gradle **wrapper JAR is not included** (binary). If Android Studio complains, either:
   - let it use its own Gradle (Settings → Build Tools → Gradle → *Use Gradle from: specified location*), or
   - run `gradle wrapper --gradle-version 8.9` once with a local Gradle, or
   - click *"Create wrapper"* / *"Use Gradle wrapper"* when prompted.
3. `app/google-services.json` is already in place. Sync → Run.

`gradle-wrapper.properties` points at Gradle 8.9 and AGP 8.7.3 / Kotlin 2.0.21.

---

## 2. Firebase console — one-time setup

In [console.firebase.google.com](https://console.firebase.google.com) → project **subh-vivah-a3875**:

| Step | What to do |
|---|---|
| Authentication | Enable **Email/Password**. (Phone OTP optional — add SHA‑1/SHA‑256 from `./gradlew signingReport`.) |
| Firestore | Create database → **production mode** → region `asia-south1` (Mumbai). |
| Realtime Database | Create database → region `asia-southeast1` (live location only). |
| Storage | Default bucket `subh-vivah-a3875.firebasestorage.app` — cards are uploaded to `cards/{uid}/`. |
| Crashlytics | Already wired via the Gradle plugin. |

### Firestore rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAdmin() {
      return request.auth != null &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
    match /users/{uid} {
      allow read: if request.auth != null;
      allow create: if request.auth.uid == uid;
      allow update: if request.auth.uid == uid || isAdmin();
      allow delete: if isAdmin();
    }
    match /weddings/{uid} {
      allow read, write: if request.auth.uid == uid || isAdmin();
      match /{sub}/{docId} {
        allow read, write: if request.auth.uid == uid || isAdmin();
      }
    }
  }
}
```

### Realtime Database rules
```
{
  "rules": {
    "tracks": {
      "$id": {
        ".read": true,
        ".write": "auth != null && (!data.exists() || data.ownerUid == auth.uid)"
      }
    }
  }
}
```
`.read: true` is what lets a guest open a tracking ID **without logging in**.

### Storage rules
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /cards/{uid}/{file} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

### Make yourself admin
After registering in the app, open Firestore → `users/{your uid}` → set `isAdmin` to `true`.
The 🛡️ Admin Panel row then appears in Settings.

---

## 3. Data model (Firestore)

```
users/{uid}                     fullName, mobile, email, addr, city, dist, state, pin,
                                isAdmin, blocked, lang, fcmToken
weddings/{uid}                  groom, bride, wdate, budget, halwai{}, decor{}, locs{},
                                card{}, cardCount, events[]
weddings/{uid}/guests/{id}      name, mob, members, side, addr, rsvp, sent
weddings/{uid}/items/{id}       name, qty, rate, vendor, status, pay
weddings/{uid}/expenses/{id}    name, amt, date, notes
weddings/{uid}/dwardari/{id}    name, village, prog(panv|aangan|dwar), cash, gift
weddings/{uid}/vehicles/{id}    name, driver, mob, rate, adv, from, to
weddings/{uid}/family/{id}      side(var|kanya), name, rel, mob, addr
```
Live location lives in Realtime Database: `tracks/{trackId}` →
`type, ownerUid, destName, lat, lng, ts, active`.

---

## 4. What is implemented

- **Auth** — register (नाम/मोबाइल/ईमेल/पता/शहर/जिला/राज्य/PIN/पासवर्ड), login by mobile **or** email,
  password reset link, blocked-account handling.
- **Home** — gradient header, विवाह सारांश (4 tiles), 12 feature cards with live counters, 🔔 notifications panel.
- **कार्यक्रम** — 9 default events (हल्दी…रिसेप्शन) with date/time/venue, add/edit/delete.
- **निमंत्रण** — guests with RSVP cycle chip, WhatsApp invite, "भेजा ✓" tracking, 5-stat strip.
- **सामान / खर्च / द्वारदारी / वाहन** — one generic list screen, per-mode forms and totals.
- **हलवाई / सजावट** — vendor details + advance + item list with totals.
- **वर पक्ष / कन्या पक्ष** — family members with relation chips.
- **कुल राशि** — custom `BarChartView` + budget / spent / paid / remaining.
- **बारात & घराती Live** — foreground location service, short shareable ID (`VM7K3Q`),
  demo mode without GPS, and a viewer screen that works without login.
- **डिजिटल कार्ड** — 4 XML templates, sample fill, JPG / PDF / Print / WhatsApp share,
  upload to Storage and card counter.
- **लोकेशन** — 6 saved places, tap = Google Maps, long-press = edit.
- **सेटिंग्स** — profile, wedding details, password, भाषा (हिंदी/English via `values-en`),
  guide, admin panel, logout. **हिंदी + English** data stays in the same doc.

## 5. Not included yet (next steps)

- Phone OTP login (UI hooks ready, needs SHA fingerprints + Blaze for SMS quota).
- Server-side FCM digest (a Cloud Function on a 09:00 IST schedule); in-app notifications work today.
- JSON backup/restore to a file (`ACTION_CREATE_DOCUMENT`).
- Unit tests for `Calc` (the class is pure Kotlin and testable as-is).

---

## 6. File map

```
app/src/main/java/com/shubh/vivah/
  data/     Models.kt  Calc.kt  Repo.kt  AppViewModel.kt
  ui/       MainActivity.kt  FormDialog.kt
    auth/ home/ events/ guests/ list/ vendor/ family/ budget/
    card/ track/ locations/ settings/ guide/ admin/
  util/     Ext.kt  Share.kt
app/src/main/res/
  layout/   activity_* · fragment_* · item_* · card_tpl_1..4
  navigation/nav_main.xml · menu/bottom_nav.xml
  values/   colors dimens themes strings  |  values-en/strings.xml
  drawable/ gradients, chips, card backgrounds, 6 vector icons
```
