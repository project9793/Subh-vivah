package com.shubh.vivah.ui

import com.shubh.vivah.util.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavOptions
import androidx.navigation.ui.setupWithNavController
import com.shubh.vivah.R
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Repo
import com.shubh.vivah.databinding.ActivityMainBinding
import com.shubh.vivah.ui.auth.AuthActivity
import com.shubh.vivah.util.showIf
import com.shubh.vivah.util.Lang
import com.shubh.vivah.util.Themes

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(Themes.currentStyle(this))
        super.onCreate(savedInstanceState)
        try {
            setup()
        } catch (t: Throwable) {
            fatal(t)
        }
        // account ki bhasha hi sach — phone me copy kar do (uninstall ke baad bhi wahi chale)
        try {
            lifecycleScope.launch {
                repeatOnLifecycle(Lifecycle.State.STARTED) {
                    vm.state.collect { s ->
                        if (!langSynced && s.loaded) {
                            langSynced = true
                            val l = s.user.lang
                            if (l.isNotBlank() && l != Lang.mode) {
                                Lang.save(this@MainActivity, l)
                                recreate()
                            }
                        }
                    }
                }
            }
        } catch (ignored: Exception) { }
    }

    private fun fatal(t: Throwable) {
        val text = android.util.Log.getStackTraceString(t)
        try { java.io.File(filesDir, "last_crash.txt").writeText(text) } catch (ignored: Exception) { }
        try {
            val tv = android.widget.TextView(this).apply {
                this.text = text
                textSize = 11f
                setPadding(24, 70, 24, 24)
                setTextIsSelectable(true)
            }
            setContentView(android.widget.ScrollView(this).apply { addView(tv) })
        } catch (ignored: Exception) { }
    }

    private var bottomInset = 0
    private var langSynced = false

    /** Bottom nav dikh raha ho to wo khud inset sambhalta hai; chhupa ho to screen ko jagah deni padti hai,
     *  warna FAB system navigation bar ke neeche chhup jata hai. */
    private fun applyBottomSpace() {
        try {
            val pad = if (b.bottomNav.visibility == View.VISIBLE) 0 else bottomInset
            b.navHost.setPadding(0, 0, 0, pad)
        } catch (ignored: Exception) { }
    }

    private fun setup() {
        if (Repo.auth.currentUser == null) {
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // Status bar ke icons (time, battery, signal) dikhne chahiye:
        // background halka hai, isliye icons dark rakhte hain.
        try {
            WindowCompat.getInsetsController(window, b.root).isAppearanceLightStatusBars = true
            WindowCompat.getInsetsController(window, b.root).isAppearanceLightNavigationBars = true
        } catch (ignored: Exception) { }

        // Android 15 (targetSdk 35) edge-to-edge handling.
        // Root sirf status bar (top) ka padding leta hai; bottom ka hisaab bottom nav khud karta hai,
        // warna bottom nav double padding se bahut upar chala jata hai.
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            bottomInset = bars.bottom
            v.setPadding(bars.left, bars.top, bars.right, 0)
            applyBottomSpace()
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(b.bottomNav) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val host = supportFragmentManager.findFragmentById(R.id.navHost) as NavHostFragment
        val nav = host.navController
        // Bottom bar: har tap par seedha usi screen par jao (purana saved state restore na ho,
        // warna Location ke baad Home dabane par koi aur screen khul jati thi).
        b.bottomNav.setOnItemSelectedListener { item ->
            if (nav.currentDestination?.id != item.itemId) {
                try {
                    val opts = NavOptions.Builder()
                        .setLaunchSingleTop(true)
                        .setPopUpTo(nav.graph.findStartDestination().id, false)
                        .build()
                    nav.navigate(item.itemId, null, opts)
                } catch (e: Exception) {
                    // agar destination na mile to chup-chaap ignore
                }
            }
            true
        }

        // beech ka utha hua sunehra tab — nimantran kholta hai
        b.centerTab.setOnClickListener {
            try {
                val opts = NavOptions.Builder()
                    .setLaunchSingleTop(true)
                    .setPopUpTo(nav.graph.findStartDestination().id, false)
                    .build()
                nav.navigate(R.id.guestsFragment, null, opts)
                b.bottomNav.menu.findItem(R.id.guestsFragment)?.isChecked = true
            } catch (e: Exception) { }
        }

        val menu = b.bottomNav.menu
        menu.findItem(R.id.homeFragment)?.title = Lang.t("होम", "Home")
        menu.findItem(R.id.eventsFragment)?.title = Lang.t("कार्यक्रम", "Events")
        menu.findItem(R.id.guestsFragment)?.title = Lang.t("निमंत्रण", "Invites")
        menu.findItem(R.id.locationsFragment)?.title = Lang.t("लोकेशन", "Location")
        menu.findItem(R.id.settingsFragment)?.title = Lang.t("सेटिंग्स", "Settings")

        val topLevel = setOf(
            R.id.homeFragment, R.id.eventsFragment, R.id.guestsFragment,
            R.id.locationsFragment, R.id.settingsFragment
        )
        nav.addOnDestinationChangedListener { _, dest, _ ->
            val isTop = dest.id in topLevel
            b.bottomNav.showIf(isTop)
            if (isTop) {
                try { b.bottomNav.menu.findItem(dest.id)?.isChecked = true } catch (ignored: Exception) { }
            }
            applyBottomSpace()
        }
        vm.start()
    }
}
