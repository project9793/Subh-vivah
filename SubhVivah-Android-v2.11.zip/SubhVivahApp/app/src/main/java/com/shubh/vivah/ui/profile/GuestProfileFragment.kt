package com.shubh.vivah.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.shubh.vivah.R
import com.shubh.vivah.data.AppViewModel
import com.shubh.vivah.data.Dwardari
import com.shubh.vivah.data.Gave
import com.shubh.vivah.databinding.FragmentGuestProfileBinding
import com.shubh.vivah.ui.Field
import com.shubh.vivah.ui.FormDialog
import com.shubh.vivah.ui.FType
import com.shubh.vivah.util.Lang
import com.shubh.vivah.util.dmy
import com.shubh.vivah.util.confirm
import com.shubh.vivah.util.toast
import kotlinx.coroutines.launch
import java.text.DecimalFormat

/** Ek mehmaan ka profile — mila / diya / baaki. */
class GuestProfileFragment : Fragment() {

    private var _b: FragmentGuestProfileBinding? = null
    private val b get() = _b!!
    private val vm: AppViewModel by activityViewModels()

    private var gName = ""
    private var gVill = ""

    private fun key(t: String) = t.trim().lowercase().replace(Regex("\\s+"), " ")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentGuestProfileBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        gName = arguments?.getString("gName").orEmpty()
        gVill = arguments?.getString("gVill").orEmpty()
        b.btnBack.setOnClickListener { goBack() }
        b.btnAddGave.setOnClickListener { addGave(null) }
        b.btnAddDwr.setOnClickListener { addDwr() }
        b.tvTitle.text = Lang.t("मेहमान प्रोफ़ाइल", "Guest profile")
        b.tvRibMila.text = "🎁  " + Lang.t("उसने मुझे दिया", "They gave me")
        b.tvRibDiya.text = "🍽  " + Lang.t("मैंने उसे दिया", "I gave them")

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render() }
            }
        }
    }

    private fun money(d: Double): String = "₹" + DecimalFormat("#,##0").format(d)

    private fun render() {
        val st = vm.state.value
        val gk = key(gName)
        val gv = key(gVill)

        fun same(name: String, vill: String): Boolean =
            key(name) == gk && (gv.isBlank() || key(vill).isBlank() || key(vill) == gv)

        // ---- identity ----
        val guest = st.guests.firstOrNull { same(it.name, it.addr) }
        b.tvName.text = gName.ifBlank { "—" }
        b.tvVill.text = gVill.ifBlank { "—" }
        b.tvSide.text = (if (guest?.side == "kanya") "कन्या पक्ष" else "वर पक्ष") +
            (if ((guest?.no ?: 0) > 0) "  •  क्रमांक " + String.format("%03d", guest!!.no) else "")

        val entries = st.dwr.filter { same(it.name, it.village) }
        val came = entries.isNotEmpty()
        when {
            came -> {
                b.tvCame.text = Lang.t("🟢 आए", "🟢 Came")
                b.tvCame.setTextColor(ContextCompat.getColor(requireContext(), R.color.ok))
                b.tvCame.setBackgroundResource(R.drawable.bg_chip_ok)
                b.tvCame.visibility = View.VISIBLE
            }
            guest?.sent == true -> {
                b.tvCame.text = Lang.t("🔴 नहीं आए", "🔴 Not came")
                b.tvCame.setTextColor(ContextCompat.getColor(requireContext(), R.color.bad))
                b.tvCame.setBackgroundResource(R.drawable.bg_chip_bad)
                b.tvCame.visibility = View.VISIBLE
            }
            else -> b.tvCame.visibility = View.GONE
        }

        // ---- mila ----
        val dwar = entries.filter { it.prog == "dwar" }.sumOf { it.cash }
        val panv = entries.filter { it.prog == "panv" }.sumOf { it.cash }
        val dahej = entries.filter { it.prog == "dahej" }.sumOf { it.cash }
        val aangan = entries.filter { it.prog == "aangan" }.sumOf { it.cash }
        val mila = dwar + panv + dahej + aangan
        b.tvMila.text = money(mila)
        b.tvDwr.text = "🙏  " + Lang.t("द्वारदारी", "Dwardari") + "  " + money(dwar)
        b.tvPanv.text = "🦶  " + Lang.t("पाँवपूजा", "Paw Puja") + "  " + money(panv)
        b.tvDahej.text = "💍  " + Lang.t("दहेज", "Dahej") + "  " + money(dahej)
        b.tvAangan.text = "🪔  " + Lang.t("आँगन", "Aangan") + "  " + money(aangan)

        b.boxDwr.removeAllViews()
        // sirf chaar line — har category ka jod, upahar numbered
        listOf("dwar", "panv", "dahej", "aangan").forEach { pr ->
            val list = entries.filter { it.prog == pr }
            b.boxDwr.addView(catRow(pr, list))
        }

        val gifts = entries.mapNotNull { it.gift.trim().ifBlank { null } }
        b.tvGifts.text = if (gifts.isEmpty()) "" else "🎁 उपहार: " + gifts.joinToString(", ")

        // ---- diya ----
        val myKey = gk + "|" + gv
        val gaves = st.gave.filter { it.guestKey == myKey || (it.guestKey.isBlank() && key(it.guestName) == gk) }
        val diya = gaves.sumOf { it.amount }
        b.tvDiya.text = money(diya)

        b.boxGave.removeAllViews()
        gaves.sortedByDescending { it.date }.forEach { g ->
            b.boxGave.addView(gaveRow(g))
        }

        // ---- baaki ----
        val baaki = mila - diya
        b.tvBaaki.text = money(if (baaki < 0) -baaki else baaki)
        b.tvBaaki.setTextColor(ContextCompat.getColor(requireContext(), if (baaki < 0) R.color.ok else R.color.bad))
        b.tvBaakiNote.text = "उन्होंने ${money(mila)} दिया, आपने ${money(diya)} दिया" +
            (if (baaki < 0) " — आपने ज़्यादा दिया" else "")
    }

    /** ek द्वारदारी entry — sudhaarne/hatane ke liye */

    /** kya ye entry isi mehmaan ki hai (naam + gaon) */
    private fun matchesGuest(name: String, vill: String): Boolean {
        fun nm(t: String) = t.trim().lowercase().replace(Regex("\\s+"), " ")
        return nm(name) == nm(gName) &&
            (nm(vill).isBlank() || nm(gVill).isBlank() || nm(vill) == nm(gVill))
    }

    private fun catColor(pr: String) = when (pr) {
        "panv" -> "#2563EB"
        "dahej" -> "#0D9488"
        "aangan" -> "#EA8C1B"
        else -> "#DB2777"
    }

    private fun catLabel(pr: String) = when (pr) {
        "panv" -> "🦶  " + Lang.t("पाँवपूजा", "Paw Puja")
        "dahej" -> "💍  " + Lang.t("दहेज", "Dahej")
        "aangan" -> "🪔  " + Lang.t("आँगन", "Aangan")
        else -> "🙏  " + Lang.t("द्वारदारी", "Dwardari")
    }

    /** ek category ki ek hi line — jod ke saath, upahar 1.2.3. kram me */
    private fun catRow(pr: String, list: List<Dwardari>): View {
        val ctx = requireContext()
        val sum = list.sumOf { it.cash }
        val gifts = list.mapNotNull { it.gift.trim().ifBlank { null } }
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        val col = android.graphics.Color.parseColor(catColor(pr))
        val info = TextView(ctx).apply {
            text = catLabel(pr)
            setTextColor(col)
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        // rashi ki chhoti rangeen patti
        val amt = TextView(ctx).apply {
            text = money(sum)
            setTextColor(android.graphics.Color.WHITE)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setBackgroundColor(col)
            setPadding(dp(10), dp(3), dp(10), dp(3))
        }
        row.addView(amt, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) })

        val edit = TextView(ctx).apply {
            text = "✏️"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.bg_gp_edit)
            val sz = dp(30)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = dp(6) }
            setOnClickListener { editCat(pr, list) }
        }
        val del = TextView(ctx).apply {
            text = "🗑"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.bg_gp_del)
            val sz = dp(30)
            layoutParams = LinearLayout.LayoutParams(sz, sz)
            setOnClickListener {
                if (list.isEmpty()) { ctx.toast(Lang.t("कुछ नहीं है", "Nothing to delete")); return@setOnClickListener }
                ctx.confirm(Lang.t("हटाएँ?", "Delete?"), catLabel(pr) + " " + money(sum)) {
                    list.forEach { vm.delDwardari(it.id) }
                }
            }
        }
        row.addView(edit); row.addView(del)
        box.addView(row)

        if (gifts.isNotEmpty()) {
            val g = TextView(ctx).apply {
                text = gifts.mapIndexed { i, t -> (i + 1).toString() + ". " + t }.joinToString("\n")
                setTextColor(ContextCompat.getColor(ctx, R.color.mut))
                textSize = 12f
                setPadding(dp(26), 0, 0, 0)
            }
            box.addView(g)
        }
        return box
    }

    /** category ki poori rashi badalna — ek hi entry rahegi */
    private fun editCat(pr: String, list: List<Dwardari>) {
        val cur = list.sumOf { it.cash }
        val curGift = list.mapNotNull { it.gift.trim().ifBlank { null } }.joinToString(", ")
        val fields = listOf(
            Field("cash", Lang.t("नगद राशि (₹)", "Cash (₹)"), FType.NUM),
            Field("gift", Lang.t("उपहार (विवरण)", "Gift (details)"))
        )
        FormDialog.show(requireContext(), catLabel(pr), fields,
            mapOf("cash" to (if (cur > 0) cur.toString() else ""), "gift" to curGift)
        ) { m ->
            val cash = FormDialog.num(m, "cash")
            val gift = FormDialog.str(m, "gift")
            if (list.isEmpty()) {
                vm.saveDwardari(Dwardari(id = "", name = gName, village = gVill, prog = pr, cash = cash, gift = gift))
            } else {
                val first = list.first()
                vm.saveDwardari(first.copy(cash = cash, gift = gift))
                list.drop(1).forEach { vm.delDwardari(it.id) }
            }
            requireContext().toast(Lang.t("✅ सेव हो गया", "✅ Saved"))
        }
    }

    private fun dwrRow(d: Dwardari): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
        val label = when (d.prog) {
            "panv" -> "🦶  " + Lang.t("पाँवपूजा", "Paw Puja")
            "dahej" -> "💍  " + Lang.t("दहेज", "Dahej")
            "aangan" -> "🪔  " + Lang.t("आँगन", "Aangan")
            else -> "🙏  " + Lang.t("द्वारदारी", "Dwardari")
        }
        val info = TextView(ctx).apply {
            text = label + "  " + money(d.cash) + (if (d.gift.isBlank()) "" else "  🎁 " + d.gift)
            setTextColor(ContextCompat.getColor(ctx, R.color.ink))
            textSize = 12f
        }
        row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val edit = TextView(ctx).apply {
            text = "✏️"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.bg_gp_edit)
            val sz = dp(30)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = dp(6) }
            setOnClickListener { editDwr(d) }
        }
        val del = TextView(ctx).apply {
            text = "🗑"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.bg_gp_del)
            val sz = dp(30)
            layoutParams = LinearLayout.LayoutParams(sz, sz)
            setOnClickListener { ctx.confirm(Lang.t("हटाएँ?", "Delete?"), label + " " + money(d.cash)) { vm.delDwardari(d.id) } }
        }
        row.addView(edit); row.addView(del)
        return row
    }

    private fun editDwr(d: Dwardari) {
        val fields = listOf(
            Field("prog", "कार्यक्रम", FType.SELECT, listOf(
                "dwar" to "द्वारदारी", "panv" to "पाँवपूजा", "dahej" to "दहेज", "aangan" to "आँगन"
            )),
            Field("cash", "नगद राशि (₹)", FType.NUM),
            Field("gift", "उपहार (विवरण)")
        )
        val vals = mapOf("prog" to d.prog, "cash" to d.cash.toString(), "gift" to d.gift)
        FormDialog.show(requireContext(), "द्वारदारी एंट्री बदलें", fields, vals) { m ->
            vm.saveDwardari(
                d.copy(
                    prog = FormDialog.str(m, "prog").ifBlank { d.prog },
                    cash = FormDialog.num(m, "cash"),
                    gift = FormDialog.str(m, "gift")
                )
            )
            requireContext().toast("✅ बदल गया")
        }
    }

    private fun gaveRow(g: Gave): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val info = TextView(ctx).apply {
            val d = if (g.date.isBlank()) "" else g.date.dmy() + "  "
            val gift = if (g.gift.isBlank()) "" else "  🎁 " + g.gift
            text = d + money(g.amount) + gift + (if (g.note.isBlank()) "" else "  (" + g.note + ")")
            setTextColor(ContextCompat.getColor(ctx, R.color.ink))
            textSize = 12f
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(info, lp)

        val edit = TextView(ctx).apply {
            text = "✏️"; textSize = 15f; setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { addGave(g) }
        }
        val del = TextView(ctx).apply {
            text = "🗑"; textSize = 15f; setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener {
                ctx.confirm("हटाएँ?", money(g.amount)) { vm.delGave(g.id) }
            }
        }
        row.addView(edit)
        row.addView(del)
        return row
    }

    /** Isi mehmaan ki द्वारदारी / पाँवपूजा / आँगन entry — naam-gaon dobara likhne ki zaroorat nahi */
    private fun addDwr() {
        val fields = listOf(
            Field("prog", "कार्यक्रम", FType.SELECT, listOf(
                "dwar" to "द्वारदारी", "panv" to "पाँवपूजा", "dahej" to "दहेज", "aangan" to "आँगन"
            )),
            Field("cash", "नगद राशि (₹)", FType.NUM),
            Field("gift", "उपहार (विवरण)")
        )
        FormDialog.show(requireContext(), "द्वारदारी एंट्री", fields, mapOf("prog" to "dwar")) { m ->
            val cash = FormDialog.num(m, "cash")
            val gift = FormDialog.str(m, "gift")
            if (cash <= 0.0 && gift.isBlank()) {
                requireContext().toast("राशि या उपहार में कुछ भरें"); return@show
            }
            val pr = FormDialog.str(m, "prog").ifBlank { "dwar" }
            // usi category ki entry pehle se ho to usme JOD do — nayi line na bane
            val existing = vm.state.value.dwr.firstOrNull { matchesGuest(it.name, it.village) && it.prog == pr }
            if (existing != null) {
                val g = listOf(existing.gift.trim(), gift.trim()).filter { it.isNotBlank() }.joinToString(", ")
                vm.saveDwardari(existing.copy(cash = existing.cash + cash, gift = g))
            } else {
                vm.saveDwardari(
                    Dwardari(id = "", name = gName, village = gVill, prog = pr, cash = cash, gift = gift)
                )
            }
            requireContext().toast("✅ एंट्री जुड़ गई")
        }
    }

    private fun addGave(existing: Gave?) {
        val fields = listOf(
            Field("amount", "राशि (₹) *", FType.NUM),
            Field("gift", "उपहार (जैसे थाली)"),
            Field("date", "तारीख", FType.DATE),
            Field("note", "नोट (जैसे बेटी की शादी)")
        )
        val vals = mapOf(
            "amount" to (existing?.amount ?: 0.0).toString(),
            "gift" to (existing?.gift ?: ""),
            "date" to (existing?.date ?: ""),
            "note" to (existing?.note ?: "")
        )
        FormDialog.show(requireContext(), if (existing == null) "मैंने दिया" else "दिया बदलें", fields, vals) { m ->
            val amt = FormDialog.num(m, "amount")
            if (amt <= 0.0) { requireContext().toast("राशि ज़रूरी है"); return@show }
            vm.saveGave(
                Gave(
                    id = existing?.id ?: "",
                    guestKey = key(gName) + "|" + key(gVill),
                    guestName = gName,
                    amount = amt,
                    gift = FormDialog.str(m, "gift"),
                    date = FormDialog.str(m, "date"),
                    note = FormDialog.str(m, "note")
                )
            )
            requireContext().toast("✅ सेव हो गया")
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun goBack() {
        try {
            if (!findNavController().navigateUp()) requireActivity().onBackPressedDispatcher.onBackPressed()
        } catch (e: Exception) {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
